# Eval harness — drop-in evaluation for a project that already works

You have a project. It summarises, classifies, extracts, answers — and it
works, mostly. What you do not have is a way to tell whether a change made it
better. You swap a model or edit a prompt, read a few outputs, and form an
impression.

This is the missing half. Pin it into your project, write **one function**
that calls your existing code, and you have a repeatable loop: frozen datasets,
runs that know what produced them, cost and speed alongside quality, and
comparisons that **refuse** to mislead you.

```bash
cd your-project
pip install "evaluation-harness @ git+https://github.com/chipi/eval-harness@v0.7.2#subdirectory=harness"
evh init --store files --tutorial   # the data folders, config.yaml, .gitignore, AGENTS.md, CLAUDE.md, data/project.yaml, prompts/judge_prompt_example.txt and the tutorial kit; --store sqlite is its equal
evh --help             # the verbs, in the order you need them
```

One install is everything: hosted-model clients, judges, the catalog, the inspector and `evh mcp`, the read
commands as tools for an agent ([INTEGRATION](docs/INTEGRATION.md#for-an-agent-evh-mcp)). Python 3.10 or later. It
imports nothing from your project until an arm names your adapter, and your project imports
nothing from it.

## The loop

Create a dataset, materialize it, run your arms, make a reference if you have none (often from
the best arm's run), compare, choose:

```bash
evh dataset-create --dataset-id my_v1 --source-dir data/sources/my_v1
evh dataset-materialize --dataset-id my_v1
evh run --system best_model_v1 --dataset my_v1          # the system that writes the reference
evh label-from-run --run <its run_id> --set best_v1                 # optional: its outputs as a model's labels
evh reference-promote --dataset-id my_v1 --labels best_v1 --tier silver \
    --reason "the best system we have ranks the rest" --by me          # ...promoted to silver
evh run --system <id> --dataset my_v1 --repeat 3        # + its own noise
evh leaderboard my_v1                                 # the ranking, and whether it is real
evh family-test my_v1 --a arm_a_v1 --against arm_     # is the winner significantly better?
evh run-promote --run <run_id> --reason "what the tests showed"    # the choice, with why
```

**[Getting started](../docs/GUIDE.md)** walks it once, offline, in about fifteen minutes; the
[tutorials](../docs/GUIDE.md#where-to-go-next) add a local model, a hosted LLM with your own
key, a frontier reference and judges, eval rounds and dataset versions, the catalog, datasets
from what your system did in production, the Workbench, and setting a model up before you test it.
In a checkout of this repository many `evh` commands are also `make` targets (`make demo` runs
the whole loop on bundled data, no API key, no network).

## Install it as a dependency

The package is code and schemas; your data stays in your project (`EVAL_HOME`, default the
nearest directory up from where you run with a `data/` folder; `EVAL_DATA_DIR`, default `data`). Already have runs scored by your own
code? `evh import-run` brings their per-item scores in, so the significance tests
can read them without re-running anything. Moving from a copied `harness/`:
[docs/UPGRADING.md](docs/UPGRADING.md).

## Why evaluation usually fails

Not for lack of a metric. It fails because the numbers turn out not to mean
what people thought:

| what goes wrong | what this does about it |
| --- | --- |
| two numbers measured on different data, compared anyway | `run-compare` **refuses** across `dataset_id`s |
| a delta smaller than the run-to-run jitter, called an improvement | `--repeat 3` reports the arm's own spread; deltas below it are marked noise |
| nobody knows which code produced a number | every run records `build.ref`; `validate` fails without it |
| a source file changed under a frozen dataset | every item is hashed; `materialize` re-verifies and fails loudly |
| model-generated references quoted as ground truth | gold and silver are distinct; every run records which it used |
| "model B is better" with no mention of 4× the cost | cost, tokens and latency recorded beside quality |
| a baseline nobody can justify | `promote` refuses a dirty build, an unknown build, or a reason under three words |

The refusals are the product. A tool that always yields a number teaches people
to trust numbers.

---

## How it works

Five directories and a contract between them:

```text
data/sources/        your raw inputs — IMMUTABLE, never edited in place
      ↓  evh dataset-create          freeze a selection + a sha256 per item
data/datasets/       the dataset_id — the thing that makes two numbers comparable
      ↓  evh dataset-materialize     rebuild run inputs, re-verify every hash
data/materialized/   derived, regenerable, disposable
      ↓  evh run          → scores + cost + speed + build provenance
data/runs/
      ↓  evh label-from-run / label-import / label-from-capture   labels: a model's, a person's, a rule's
data/labels/
      ↓  evh reference-promote       ground truth to score against: labels promoted (gold | silver), with a reason (--by or EVH_ACTOR is required, even at a terminal)
data/references/
      ↓  evh leaderboard / pair-test / family-test / run-compare
data/baselines/      evh run-promote — the number future work is judged against

optional, later, from the same frozen outputs (the originals are never touched):
  evh rescore        new reference or new code scorer, $0: a score under each run, read as 'rescored <scorer>'
  evh judge-score    a validated LLM judge, billed and capped: a score under each run, read as judged/<scorer>

beside them, also optional:
data/goals/          what each evaluation is for; a run names one with `evh run --goal`
data/rounds/         eval rounds of a goal: evh round-open / round-list / round-close
data/fields/         field sets: the typed facts a project's items carry (`--fieldset`)
data/profiles/       evh dataset-profile   what is inside a dataset, for its page (no text by default)
.build/catalog/      evh catalog / evh catalog-serve   pages over the runs, and the inspector
(an agent)           evh mcp            the read commands as MCP tools
```

`evh validate` checks the whole tree — twenty-eight integrity rules (V1–V28), exits non-zero,
so it can gate CI.

### The three inputs

Every run records three things, and is worthless without all of them:

- **system under test** — `build.ref`, set by `EVAL_BUILD_REF` or the git SHA
- **system** — `system_id` (the system's id), what you ran
- **data** — `dataset_id`, what it was measured on

Drop any one and a delta cannot be attributed to anything.

---

## Integrating your system

One function, `call_system()`, in `adapter.py` at your project's root. An arm whose
system names no `adapter:` uses it; a project with several tasks names one per arm
(`adapter: adapters/ner.py`):

```python
from evaluation_harness.adapter import Result

def call_system(text, params):
    from myproject.summarise import summarise        # your existing code
    out = summarise(text, model=params["model"])
    return Result(output=out.text,
                  tokens_in=out.usage.prompt_tokens,
                  tokens_out=out.usage.completion_tokens)
```

And one more, `score()`, for what "good" means in your domain. That is the
whole integration — no refactor, no wrapper, no base class.

Arms are **system files**, not code edits: four models to compare is four YAML
files, each run on the same dataset.

→ **[docs/INTEGRATION.md](docs/INTEGRATION.md)** — the first hour, concretely.

---

## Is the ranking real?

A table sorted by a mean always produces an ordering. Whether that ordering survives
re-running the eval is a different question, and `evh leaderboard` answers it
before it shows you anything else:

```
IS THE ORDERING REAL?   metric=coverage  k=24 arms  N=20 items
  global test (permutation on within-item ranks): p = 0.0054 -> an arm effect exists
  Nemenyi critical difference = 8.13 rank positions; observed span = 8.57
  pairs distinguishable: 1 of 276
```

Three readings, all computed over the whole table at once:

- **Global test** — rank every arm *within* each item, then ask whether the average ranks
  are further apart than chance. On a real dataset most variance is "some items are hard
  for everyone" (66% here, against 3% between arms), and ranking inside the item is what
  removes it. If this fails, no ordering is supported and the output says so.
- **Nemenyi critical difference** — from the number of arms and items alone, how far apart
  two average ranks must be before that *pair* is distinguishable. Applied to every pair
  simultaneously, so it accounts for the fact that 24 arms means 276 comparisons and ~14
  of them will look significant by luck.
- **Rank probabilities** — resample the items, re-rank everything from scratch, and report
  how often each arm lands 1st / in the top 5 / in the bottom 5. This replaced a 95% rank
  interval per arm: those were marginal, so two non-overlapping intervals read as "this
  pair differs significantly" — exactly the claim they cannot make. Context, never a pairwise
  verdict; the critical-difference line is the verdict.

What this deliberately does **not** do is walk down the table comparing each arm to a
running "leader". That is a sorting algorithm, not a comparison: walked bottom-up instead
of top-down it partitions the same arms differently.

## Re-measuring without re-running

Scores are arithmetic over outputs, and outputs are the expensive part. So a metric change
should not cost a sweep:

```
evh score-preview --goal my_goal                                 # what a scoring change would move; writes nothing
evh rescore --goal my_goal --round r2 --why "the rule I fixed"   # a round's arms, at $0, the why recorded
evh rescore --dataset-id my_v1 --match _v2                       # or any runs of a dataset
```

A re-score is a score under the run it re-read (`data/runs/<run_id>/scores/<scorer>@<reference>/`), read under
its own label (`rescored <scorer>`, or `--label`); the goals, the rounds and the catalog read an arm from its latest re-score, and a round records the
scorer it is judged by, so a scoring change is a step of its own, applied to a round or adopted by the next
(`round-open --scoring`; [RFC-022](../docs/rfc/RFC-022-scoring-that-evolves.md)). Each re-scored run records
`derived: {kind: rescore, from, at, with}`:
the source run, when, and the sha256 of the adapter (and its scorer) that rescored it, so a
recomputation can never be mistaken for a measurement. Latency, cost
and token counts are carried across untouched — they describe the call that happened, not
how it was later measured.

This exists so that fixing a scorer does not cost another paid sweep: the outputs are kept, and scored again for $0.

The same frozen outputs can be measured again in three ways, and none of them is required:

| kind | what changes | cost | command |
| --- | --- | --- | --- |
| new reference | what an output is scored against (gold a person adjudicated) | $0 | `evh rescore --reference-id gold/<id>` |
| new code scorer | the metric, as code | $0 | `evh rescore` |
| judge scorer | the metric, delivered by LLM judges validated against people | billed, capped | `evh judge-score` |

A **judge scorer** (`data/scorers/<id>.yaml`) names two or more judges from different vendor
families, the task they score, the prompt, and the runs that validated each judge against
human ratings. The command refuses a judge nobody validated (`--unvalidated` runs it with
every number labelled), freezes a blinded, shuffled judging set, stores every verdict so a
rerun costs $0, and writes scored runs that `leaderboard`, `pair-test` and `family-test`
read unchanged. The scorer's `mode` says what a judge is asked: `grade` each output (the default), `pick` the
best of an item's outputs, or `pairwise` the better of two; a judge is validated in the mode it is used, and pick
and pairwise report win rates and Bradley-Terry strengths. An eval's primary metric changes only by a recorded decision.
Walkthrough: [tutorial 3](../docs/tutorials/3-frontier-reference-and-judging.md#5-re-measure-with-an-llm-judge-optional);
reference: [RUNBOOK §12](docs/RUNBOOK.md#12-re-measure-with-a-validated-judge); why:
[ADR-0001](../docs/adr/ADR-0001-judge-scorers.md).

## Set a model up before you test it

A server chooses for whatever an arm leaves unset (whether the model reasons first, how long a reply may run,
which build a tag names), so two arms that leave them unset compare defaults as much as models. A model is set up
once, in a record (`data/models/<id>.yaml`) with a deployment per place it runs, and checked there before any
eval uses it:

```bash
evh model-onboard --model-id my-model --deployment laptop   # its build, whether it reasons, JSON, determinism, speed
evh arm-smoke --system my_system_v1 --dataset my_v1   # a few items with the system's own settings, before the full run
evh model-list                                       # which models are onboarded, vetted, and where they run
```

`model-onboard` and `arm-smoke` call the model (a few calls each, billed like any other); `model-list` and `model-show`
reads.

An arm names the record and deployment (`model_record:`, `deployment:`), and its run's fingerprint takes the
weights, server and machine from it. Walkthrough: [tutorial 7](../docs/tutorials/7-set-up-a-model.md); reference:
[RUNBOOK §16](docs/RUNBOOK.md#16-set-up-a-model-before-you-test-it); design:
[RFC-020](../docs/rfc/RFC-020-onboarding-a-model.md), [RFC-021](../docs/rfc/RFC-021-fingerprint-v5.md).

## Datasets from what your system did

What a system did in production is the most realistic test there is, and what happened afterwards can label it:

```bash
evh capture --importer jsonl --query '{"path": "export.jsonl"}' --capture prod_2026_10   # the records, hashed
evh dataset-from-capture --capture prod_2026_10 --dataset-id prod_v1 --tag source=prod             # a frozen selection
evh label-from-capture --dataset-id prod_v1 --capture prod_2026_10 \
    --map outcomes.yaml --set prod_outcomes                                              # labels from what happened
evh dataset-split --dataset-id prod_v1 --test 0.3 --seed 7                                         # validation and test
evh capture --importer jsonl --query '{"path": "export.jsonl"}' --capture prod_2026_11 \
    --since-capture prod_2026_10                                                         # later: what came since
```

What came since makes the next dataset version; for newer outcomes of the records you hold, take a fresh capture
of the same query and make a new label set from it (tutorial 6 §5).

Labels are not reference sets: arms are scored against a label set as it is, and a reference set is labels promoted on
purpose, at the tier chosen then. Production's own decisions become an arm (`evh arm-from-capture`), scored like any;
`evh sheet-show prod_v1 --runs …` shows each item's outputs, scores, labels and signals (wrong,
disagree, new) to pick the ones worth keeping (`evh pick`); `evh dataset-extend` makes the next version of a governed dataset from
them; `evh deploy-sheet` says what production must match to run what you promoted, and whether a capture shows it
did. Importers for
JSONL, TSV, GitHub issues and Langfuse traces come with the harness, and `text: hidden` keeps a dataset's text off
every public surface. Walkthrough: [tutorial 6](../docs/tutorials/6-datasets-from-production.md); reference:
[RUNBOOK §15](docs/RUNBOOK.md#15-datasets-from-production-the-capture-lane); design:
[RFC-019](../docs/rfc/RFC-019-datasets-from-production.md).

## Do you trust your reference?

Most of the time there is no gold, so a strong model writes the references — "silver" — and
you rank candidates against those. This asks whether that ranking matches the one real
ground truth would have given:

```
evh silver-calibrate --dataset-id my_v1 --ref-match _v1 --arm-match _v2
```

It costs nothing, because "author silver with model X using the same prompt and settings as
the arms" is exactly what X already produced — so every arm on disk is a candidate author
and all of them are tried.

Read the result against the **ceiling** it prints. Two runs of the same arms against the
same gold do not rank identically either, so that retest correlation is the best any proxy
could score. In the summarisation eval's 24 hosted arms
([REPORT_SUMMARIZATION §3.5](../research/REPORT_SUMMARIZATION.md)): ceiling 0.92, silver
authors −0.01–0.70 (mean 0.33).

The number that matters most is the last one. Grouping arms by `family`, a silver author
**promotes models of its own kind by ~7 rank positions, for 22 of 24 authors** — and
excluding the author's own row does not remove it, because the bias is not an author
scoring itself, it is an author rewarding its own kind's style. A silver-ranked leaderboard
is not merely noisier than a gold one; it is biased in a direction you can predict from who
wrote it.

## Scoping a dataset that has grown

A dataset accumulates arms across system versions, and v1 and v2 of one arm are different
measurements that must not share a row:

```
evh leaderboard my_v1 --match _v2    only the v2 arms
evh leaderboard my_v1 --round r2     only the arms in play in a round
evh leaderboard my_v1 --label judged/my-judge   only the arms read under one label
```

`evh run --scratch` is how a smoke pass avoids adding a second measurement to a real sweep's arms and
silently moving numbers you have already reported: it writes under `.build/scratch/runs`, which nothing that
reads runs looks at. Use it whenever you are validating a change rather than measuring something.

**Deleting old runs to make a table shorter is not the alternative to scoping it.** A run is a paid result: scope the table instead.

## Docs

| | |
| --- | --- |
| **[Getting started](../docs/GUIDE.md)** | the loop once, offline, in about fifteen minutes |
| **[Tutorials](../docs/GUIDE.md#where-to-go-next)** | a local model against a baseline; a hosted LLM with your own key; a frontier reference, gold and judging; rounds and dataset versions; the catalog and the inspector |
| **[INTEGRATION.md](docs/INTEGRATION.md)** | plugging in an existing system; getting ground truth when you have none; connecting an agent (`evh mcp`) |
| **[CHANGELOG.md](CHANGELOG.md)** | what each release shipped, what can move a result |
| **[RUNBOOK.md](docs/RUNBOOK.md)** | every command and flag, step by step, with the reasoning; environment variables and exit codes |
| **[RELEASING.md](docs/RELEASING.md)** | pinning a release in your project, and cutting one: version, changelog, tag, GitHub Release |
| **[SCENARIO.md](docs/SCENARIO.md)** | the newcomer scenario, a smoke test run when the newcomer's path changes: two evals, real models, one CPU model, under $1 |
| **[UPGRADING.md](docs/UPGRADING.md)** | from one release to the next (what can move a number), and for a copy of the harness taken before October 2026 |
| **[CONCEPTS.md](docs/CONCEPTS.md)** | why each refusal exists, and the failure it prevents |

---

## Files

In a checkout of this repository; the package installs `scripts/` as `evaluation_harness`, so the
bundled adapter a pinned project has is `evaluation_harness/adapter.py`.

| Path | What it is |
| --- | --- |
| `Makefile` | the verbs — start with `make help` |
| `scripts/adapter.py` | the bundled adapter (token overlap, the worked example's), used when a project has no `adapter.py`; start yours from a copy |
| `scripts/dataset_create.py` | freeze a selection into a `dataset_id` |
| `scripts/materialize.py` | build run inputs, verifying every hash |
| `scripts/label_from_run.py`, `scripts/reference_promote.py` | ground truth: a run's outputs as a model's label set, then labels promoted to a reference set at a tier, with a reason |
| `scripts/run.py` | run an arm → scores, cost, speed, provenance |
| `scripts/compare_runs.py` | compare two runs, or refuse |
| `scripts/promote_baseline.py` | run → baseline, or refuse |
| `scripts/validate_tree.py` | twenty-eight integrity checks (V1–V28) |
| `scripts/ops/records.py` | what runs and baselines exist: `evh runs-list`, `evh baselines` |
| `schemas/` | the contracts: dataset, metrics (a run), baseline, system (an arm), goal, field set, judge scorer, judging set, verdict |
| `scripts/_fields.py`, `scripts/_fetch.py` | item fields (types, checks, the catalog's summary) and items fetched from a pinned URL (ADR-0003) |
| `scripts/stats.py` | the one paired test: `pair-test`, `family-test` and the inspector all call it |
| `scripts/rescore.py` | re-score stored outputs for a new reference or scorer, $0 |
| `scripts/judge_score.py`, `scripts/judging.py` | the judge scorer: gate, judging set, verdicts, projection; prompt, parser, judge client |
| `scripts/catalog_build.py`, `scripts/catalog_serve.py`, `catalog_assets/` | the catalog's pages, and the run inspector; `catalog_periods.py` the period (from today) and the trends, `catalog_arms.py` the arms page |
| `scripts/catalog_adapter.py` | what the catalog asks of a project's data, and `HarnessAdapter`, the answer for this layout |
| `scripts/catalog_views.py`, `scripts/ops/views.py`, `scripts/model/*_views.py` | the catalog and the inspector in the terminal: `evh overview-show`, `activity-show`, `dataset-list`, `arm-list`, `reference-list`, `metric-list`, `goal-list`, `comparison-show` |
| `tests/` | this repository's tests (`make test`, `tests/self_test.py`) and the GUIDE and the offline tutorials run in a fresh project (`make guide-check`); not in the package. The ones that run `evh` install the real wheel (`tools/_wheel.py`, which the deploy uses too). `scripts/test_stats.py` ships: `evh self-test` runs it |
| `tools/` | this repository's report checks (`check_report_claims.py` and friends), judge validations and `*_report.py` tables; not in the package |
| `tests/test_inspector_browser.py`, `requirements-browser.txt` | the catalog and the inspector in headless Chromium: `make browser-install`, then `make browser-check` |
| `tests/test_workbench_browser.py` | the frozen Workbench mockup (`workbench/mockup/`) in headless Chromium (every screen, its skip link, help focus, a round's results): part of `make browser-check` |
| `tests/test_workbench_live_browser.py`, `test_workbench_replay_browser.py`, `test_workbench_store_browser.py`, `test_workbench_heldout_browser.py` | the live Workbench behind a real `evh catalog-serve`, every screen against the project's API, at a desktop's and a phone's width: part of `make browser-check` |
| `requirements-dev.txt` | the code-quality tools; from the repository root, `make quality-install`, then `make quality` |

Bundled providers: `echo` (no network), `openai` (OpenAI or any OpenAI-compatible endpoint),
`openrouter` (`OPENROUTER_API_KEY`, OpenRouter's address), `anthropic` and `litellm` (a LiteLLM
proxy). You choose one and bring your own key;
which variable each reads: [tutorial 2](../docs/tutorials/2-hosted-llm.md#1-choose-a-provider).
Most real integrations replace them with one function that calls their own system.

---

## See also

- [`../examples/`](../examples) — six worked examples, what each one found, and
  what each one broke in this harness.
- [`../research/`](../research) — the reports, the append-only journal, and a
  handover per example for the work that was not finished.
