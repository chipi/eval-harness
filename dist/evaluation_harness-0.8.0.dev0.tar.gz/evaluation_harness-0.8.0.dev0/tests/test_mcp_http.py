#!/usr/bin/env python3
"""Assertions for `evh mcp --http` (RFC-018), through the official SDK's streamable HTTP client.

    python tests/test_mcp_http.py

A server on the loopback, --public, --rate 6, with a hooks file that records what it is told:
its health answers; a request for another Host is refused (DNS rebinding); --public leaves out the
options that answer with text; the fourth call in a minute is refused; the hooks see each call
(tool, argument names, never values; the caller) and serve their own route beside the endpoint;
and a bind beyond the loopback without --allowed-host is refused before it starts.
"""

import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from evaluation_harness._check import check, summary  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))  # tests/: _runstore
import _runstore  # noqa: E402

try:
    import anyio
    from mcp import ClientSession
    from mcp.client.streamable_http import streamable_http_client
except ImportError as exc:
    print(
        f"  FAIL test_mcp_http: {exc}: mcp is a dependency of the package (pip install -r requirements.txt)"
    )
    sys.exit(1)

sys.path.insert(0, str(Path(__file__).resolve().parent))  # tests/: _tmp
import _tmp  # noqa: E402

tmp = Path(_tmp.mkdtemp(prefix="evh-mcp-http-"))
(tmp / "data" / "datasets").mkdir(parents=True)
from evaluation_harness import _format  # noqa: E402

_runstore.write_text(tmp, _format.NAME, f"format: {_format.FORMAT}\n")
seen = tmp / "seen.jsonl"
(tmp / "hooks.py").write_text(
    f"""
import json
def _w(kind, info):
    with open({str(seen)!r}, "a") as fh:
        fh.write(json.dumps({{"kind": kind, **{{k: v for k, v in info.items() if k != "version"}}}}) + "\\n")
def start(info): _w("start", info)
def request(info): _w("request", info)
def error(exc, info): _w("error", info)
routes = {{"/metrics": lambda q: (200, "text/plain", b"evals_mcp_calls_total 1\\n")}}
"""
)
with socket.socket() as s:
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
env = dict(os.environ, EVAL_HOME=str(tmp))
env.pop("EVAL_DATA_DIR", None)
cmd = [sys.executable, str(HERE / "cli.py"), "mcp", "--http", "--port", str(port), "--public", "--rate", "6"]
# The hooks file named relative to where the server starts (the project's parent): read there, before the server
# moves into the project.
cmd += ["--allowed-host", "evals.example.test", "--project", tmp.name, "--hooks", f"{tmp.name}/hooks.py"]
srv = subprocess.Popen(
    cmd, cwd=tmp.parent, env=env, stderr=subprocess.PIPE, text=True, start_new_session=True
)
base = f"http://127.0.0.1:{port}"


def get(path: str, host: str | None = None) -> tuple[int, str]:
    req = urllib.request.Request(base + path, headers={"Host": host} if host else {})  # noqa: S310 -- the test's own server on 127.0.0.1
    try:
        with urllib.request.urlopen(req, timeout=10) as r:  # noqa: S310  # nosec B310
            return r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


try:
    for _ in range(100):
        try:
            if get("/mcp/health")[0] == 200:
                break
        except OSError:
            pass
        time.sleep(0.2)
    code, body = get("/mcp/health")
    check(
        "health: answers, saying it is public", code == 200 and json.loads(body).get("public") is True, body
    )
    req = urllib.request.Request(  # noqa: S310 -- the test's own server
        base + "/mcp", data=b"{}", headers={"Host": "evil.example", "Content-Type": "application/json"}
    )
    try:
        urllib.request.urlopen(req, timeout=10)  # noqa: S310  # nosec B310
        code = 200
    except urllib.error.HTTPError as e:
        code = e.code
    check("another Host is refused (DNS rebinding)", code == 421, code)
    code, body = get("/metrics")
    check(
        "a hooks route is served beside the endpoint", code == 200 and "evals_mcp_calls_total" in body, body
    )

    async def session():
        async with (
            streamable_http_client(base + "/mcp") as streams,
            ClientSession(streams[0], streams[1]) as s,
        ):
            await s.initialize()
            tools = {t.name: t for t in (await s.list_tools()).tools}
            check(
                "--public: no tool answers with an item's text, an output or a label (the sheet, an item, the items' outputs), and no input of one that remains does",
                not {"sheet-show", "comparison-item", "comparison-items"} & set(tools)
                and not {"group", "group_match"}
                & set(tools["comparison-crosstab"].input_schema["properties"])
                and "item" not in tools["dataset-items"].input_schema["properties"],
            )
            check(
                "--public: validate is not offered (a public copy is not a whole project)",
                "validate" not in tools,
            )
            res = await s.call_tool("round-list", {})
            check(
                "a missing required argument is refused before anything runs",
                res.is_error and "'goal' is a required property" in res.content[0].text,
                res.content[0].text,
            )
            res = await s.call_tool("search", {"text": ["x", "--adapter", "os:getcwd"]})
            check(
                "a value that starts with '-' is a value: words to look for, nothing is loaded",
                not res.is_error and res.structured_content["result"]["hits"] == [],
                res.content[0].text,
            )
            res = await s.call_tool('a"} 1\nforged 0', {})
            check("an unknown tool is refused", res.is_error and "no tool" in res.content[0].text)
            results = [await s.call_tool("dataset-show", {"dataset": f"d{i}"}) for i in range(4)]
            check(
                "--rate 6: the three refused calls count; three dataset-show calls answer, the fourth is refused",
                "a minute" in results[3].content[0].text
                and results[3].is_error
                and not any("a minute" in r.content[0].text for r in results[:3]),
                [r.content[0].text[:80] for r in results],
            )

    anyio.run(session)
    lines = [json.loads(ln) for ln in seen.read_text().splitlines()] if seen.is_file() else []
    starts = [x for x in lines if x["kind"] == "start"]
    calls = [x for x in lines if x["kind"] == "request"]
    check(
        "hooks: start, with the tools and the transport",
        starts and starts[0].get("transport") == "http",
        starts,
    )
    check(
        "hooks: an unknown tool is told as 'unknown', never the client's string",
        any(c["tool"] == "unknown" for c in calls) and "forged" not in seen.read_text(),
        [c["tool"] for c in calls],
    )
    calls = [c for c in calls if c["tool"] == "dataset-show"]
    check(
        "hooks: each call, its tool and argument names, never their values",
        len(calls) == 4 and all(c["args"] == ["dataset"] for c in calls) and "d0" not in seen.read_text(),
        calls,
    )
    check("hooks: the caller's address", all(c.get("client") == "127.0.0.1" for c in calls), calls)
    check("hooks: the refused call says why", calls[-1].get("refused") == "rate", calls[-1])
finally:
    os.killpg(srv.pid, 15)
    srv.wait(timeout=10)
log = [ln for ln in (srv.stderr.read() if srv.stderr else "").splitlines() if ln.startswith("{")]
check(
    "the log line: a line per call, never the caller's address or user agent",
    len(log) >= 7 and not any('"client"' in ln or '"agent"' in ln or "127.0.0.1" in ln for ln in log),
    log[:3],
)

# --rate-total: everyone together, whoever they are. And a profile written --with-text: a public
# server serves its rows, never their text.
(tmp / "data" / "profiles").mkdir(parents=True, exist_ok=True)
_runstore.write_text(
    tmp,
    "profiles/p.json",
    json.dumps(
        {
            "dataset_id": "p",
            "items": {"n": 1, "kind": "text", "words": {}},
            "references": [],
            "rows": [{"item_id": "a", "words": 2, "reference": {}, "text": "SECRET ITEM TEXT"}],
        }
    ),
)
with socket.socket() as s:
    s.bind(("127.0.0.1", 0))
    port2 = s.getsockname()[1]
cmd2 = [
    sys.executable,
    str(HERE / "cli.py"),
    "mcp",
    "--http",
    "--port",
    str(port2),
    "--public",
    "--rate-total",
    "4",
    "--request-rate",
    "18",
    "--max-body",
    "4096",
    "--hooks",
    str(tmp / "hooks.py"),
]
srv2 = subprocess.Popen(cmd2, cwd=tmp, env=env, stderr=subprocess.DEVNULL, text=True, start_new_session=True)
base = f"http://127.0.0.1:{port2}"
try:
    for _ in range(100):
        try:
            if get("/mcp/health")[0] == 200:
                break
        except OSError:
            pass
        time.sleep(0.2)

    async def total():
        async with (
            streamable_http_client(base + "/mcp") as streams,
            ClientSession(streams[0], streams[1]) as s,
        ):
            await s.initialize()
            # Refusals first: they cost nothing and never count toward the total.
            for _ in range(3):
                await s.call_tool("no-such-tool", {})
            items = await s.call_tool("dataset-items", {"dataset": "p"})
            check(
                "--public: dataset-items serves a profile's rows, never their text",
                not items.is_error
                and '"item_id": "a"' in items.content[0].text
                and "SECRET" not in items.content[0].text,
                items.content[0].text[:200],
            )
            bad = await s.call_tool(
                "dataset-items", {"dataset": "a.b.x"}
            )  # is answered, and the operation refuses it
            check(
                "an operation's own refusal is an error to the caller",
                bad.is_error,
                bad.content[0].text[:120],
            )
            res = [await s.call_tool("dataset-list", {"period": p}) for p in ("all", "30d", "week")]
            check(
                "--rate-total 4: the fifth call that runs is refused, from anyone (refusals do not count)",
                not res[0].is_error
                and not res[1].is_error
                and res[2].is_error
                and "as many calls" in res[2].content[0].text,
                [r.content[0].text[:60] for r in res],
            )
            again = await s.call_tool("dataset-list", {"period": "all"})
            check(
                "--public: a repeated call is answered from what was kept, and is not counted",
                not again.is_error and again.content[0].text == res[0].content[0].text,
                again.content[0].text[:80],
            )

    anyio.run(total)
    told = [json.loads(ln) for ln in seen.read_text().splitlines() if ln.strip()]
    mine = [
        x for x in told if x.get("kind") == "request" and x.get("tool") == "dataset-items" and "exit" in x
    ]
    check(
        "hooks: an operation's own refusal is told as refused (no analytics event, not an error)",
        any(x.get("exit") == 1 and x.get("refused") == "command" for x in mine)
        and any(x.get("exit") == 0 and "refused" not in x for x in mine),
        mine,
    )

    def post(body: bytes) -> int:
        req = urllib.request.Request(  # noqa: S310 -- the test's own server
            base + "/mcp",
            data=body,
            headers={"Content-Type": "application/json", "Accept": "application/json, text/event-stream"},
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as r:  # noqa: S310  # nosec B310
                return r.status
        except urllib.error.HTTPError as e:
            return e.code

    check(
        "GET on the endpoint is 405 (stateless: no stream to hold open)", get("/mcp")[0] == 405, get("/mcp")
    )
    slash = urllib.request.Request(  # noqa: S310 -- the test's own server
        base + "/mcp/",
        data=b'{"jsonrpc":"2.0","id":1,"method":"ping"}',
        headers={"Content-Type": "application/json", "Accept": "application/json, text/event-stream"},
    )
    try:
        with urllib.request.urlopen(slash, timeout=10) as r:  # noqa: S310  # nosec B310
            slash_code, slash_url = r.status, r.geturl()
    except urllib.error.HTTPError as e:
        slash_code, slash_url = e.code, e.geturl()
    check(
        "/mcp/ is the endpoint itself, never a redirect",
        slash_code == 200 and slash_url.endswith("/mcp/"),
        (slash_code, slash_url),
    )
    big = b'{"jsonrpc":"2.0","id":1,"method":"ping","params":{"x":"' + b"a" * 8000 + b'"}}'
    check("--max-body 4096: a larger body is refused (413) before it is read", post(big) == 413)
    ping = b'{"jsonrpc":"2.0","id":1,"method":"ping"}'
    codes = [post(ping) for _ in range(16)]
    check(
        "--request-rate 18: every request counts, ping too; past it, 429",
        429 in codes and codes[0] != 429,
        codes,
    )
finally:
    os.killpg(srv2.pid, 15)
    srv2.wait(timeout=10)

r = subprocess.run(
    [sys.executable, str(HERE / "cli.py"), "mcp", "--http", "--bind", "0.0.0.0"],  # noqa: S104  # nosec B104 -- refused, never bound
    cwd=tmp,
    env=env,
    capture_output=True,
    text=True,
    timeout=60,
)
check(
    "a bind beyond the loopback needs --allowed-host",
    r.returncode != 0 and "--allowed-host" in r.stderr,
    r.stderr[-200:],
)
from types import SimpleNamespace  # noqa: E402

from evaluation_harness.mcp_server import Hooks, _client, caller_key  # noqa: E402


class Raises:
    def request(self, info):
        raise RuntimeError("hook broke")


Hooks(Raises())("request", {})  # must not raise
check("a hook that raises never breaks the call it observes", True)
fake = SimpleNamespace(
    headers={"CF-Connecting-IP": "203.0.113.9", "user-agent": "x" * 500},
    client=SimpleNamespace(host="10.0.0.1"),
)
addr, ua = _client(SimpleNamespace(request=fake), "CF-Connecting-IP")
check(
    "--client-header names the caller; the address and user agent are capped",
    addr == "203.0.113.9" and len(ua) == 120,
    (addr, len(ua)),
)
check(
    "without the header, the connection's own address",
    _client(
        SimpleNamespace(request=SimpleNamespace(headers={}, client=SimpleNamespace(host="10.0.0.1"))),
        "CF-Connecting-IP",
    )[0]
    == "10.0.0.1",
)

check(
    "the rate counts an IPv6 caller by its /64, an IPv4 caller by its address",
    caller_key("2001:db8:1:2::7") == caller_key("2001:db8:1:2:ffff::1") != caller_key("2001:db8:1:3::7")
    and caller_key("203.0.113.7") == "203.0.113.7",
)
from evaluation_harness.mcp_server import Gate  # noqa: E402


async def held_open() -> list:
    """Nine requests from one caller held open at once: the ninth is 429, a second caller's is not."""
    release = anyio.Event()
    statuses: list = []

    async def app(scope, receive, send):
        await release.wait()
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b""})

    gate = Gate(app, "/mcp", 0, None)

    async def one(ip: str):
        async def send(msg):
            if msg["type"] == "http.response.start":
                statuses.append((ip, msg["status"]))

        scope = {"type": "http", "path": "/mcp", "method": "POST", "headers": [], "client": (ip, 1)}

        async def receive():
            return {"type": "http.request", "body": b"{}", "more_body": False}

        await gate(scope, receive, send)

    async with anyio.create_task_group() as tg:
        for _ in range(9):
            tg.start_soon(one, "198.51.100.1")
        tg.start_soon(one, "198.51.100.2")
        await anyio.sleep(0.2)
        release.set()
    return statuses


async def slow_body() -> int:
    """A body that never finishes arriving is cut at the deadline: 408, the slot freed."""
    statuses: list = []

    async def app(scope, receive, send):
        while (await receive()).get("more_body"):
            pass
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b""})

    gate = Gate(app, "/mcp", 0, None)
    gate.BODY_DEADLINE = 0.3
    first = [True]

    async def receive():
        if first[0]:
            first[0] = False
            return {"type": "http.request", "body": b"{", "more_body": True}
        await anyio.sleep(60)  # the rest never comes
        return {"type": "http.disconnect"}

    async def send(msg):
        if msg["type"] == "http.response.start":
            statuses.append(msg["status"])

    scope = {"type": "http", "path": "/mcp", "method": "POST", "headers": [], "client": ("198.51.100.3", 1)}
    with anyio.fail_after(5):
        await gate(scope, receive, send)
    return statuses[0] if statuses and not gate.open else -1


check("a request whose body stalls is cut at the deadline: 408, its slot freed", anyio.run(slow_body) == 408)
check(
    "an IPv4-mapped IPv6 caller is counted by its IPv4, not a /64 shared with every other",
    caller_key("::ffff:203.0.113.7") == "203.0.113.7" != caller_key("::ffff:203.0.113.8"),
)
from evaluation_harness.mcp_server import tools_for  # noqa: E402

check(
    "a public server offers fewer tools than a local one, and none of the agent sampler's",
    set(tools_for(True)) < set(tools_for(False)) and not {"study-ask", "study-tell"} & set(tools_for(True)),
)
got = anyio.run(held_open)
check(
    f"a caller has at most {Gate.OPEN_PER_CALLER} requests open: the next is 429, another caller's is served",
    sorted(st for ip, st in got if ip == "198.51.100.1") == [200] * Gate.OPEN_PER_CALLER + [429]
    and ("198.51.100.2", 200) in got,
    got,
)
sys.exit(summary())
