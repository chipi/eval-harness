#!/usr/bin/env python3
"""A goal's axes and its decision: limits, the quality leader, the tie, the tie-break. $0, offline.

python tests/test_axes.py
"""

import re
import sys
from html import unescape
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # harness/: the evaluation_harness package
from evaluation_harness import axes
from evaluation_harness._check import check, summary

ITEMS = [f"i{k:02d}" for k in range(12)]
#: Each list stands for REPEAT copies of itself (item ids `<id>~<copy>`): the same means and percentiles, and past the
#: 100 items a continuous measure needs before a contender can be shown (stats.NONINF_MIN_UNITS, ADR-0026).
REPEAT = 1


def arm(label, quality, cost=None, latency=None, tokens=None, flags=(), **extra):
    """An arm with per-item scores: `quality` and the rest are per-item lists or a constant."""

    def series(v):
        if v is None:
            return None
        vals = v if isinstance(v, list) else [v] * len(ITEMS)
        return {"values": {f"{i}~{r}": x for r in range(REPEAT) for i, x in zip(ITEMS, vals)}}

    sc = {"q": series(quality), "cost_usd": series(cost), "latency_ms": series(latency)}
    if tokens is not None:
        sc["tokens_in"] = series(tokens)
        sc["tokens_out"] = series(0)
    for k, v in extra.items():
        sc[k] = series(v)
    return {"label": label, "flags": list(flags), "scores": {k: v for k, v in sc.items() if v}}


GOAL = {"success_criteria": {"primary": {"measure": "q", "direction": "higher"}}}

ax = axes.axes_of(GOAL)
check(
    "axes: quality, then cost and speed built in, with their measures and statistics",
    [(a["name"], a["measure"], a["stat"]) for a in ax]
    == [("quality", "q", "mean"), ("cost", "cost_usd", "mean"), ("speed", "latency_ms", "p95")],
    str(ax),
)
check("a percentile between ranks", axes.percentile([1, 2, 3, 4], 50) == 2.5)

# A big quality gap: the leader wins outright.
strong = [0.9 + 0.001 * k for k in range(12)]
weak = [0.2] * 12
d = axes.decide(GOAL, {"a": arm("A", strong, 0.01, 100), "b": arm("B", weak, 0.001, 50)})
check(
    "decide: a significantly better leader is recommended, whatever it costs",
    d["leader"] == "a" and d["contenders"] == ["a"] and d["recommended"] == "a",
    d["why"],
)

# A quality tie: the cheaper one wins; equal cost goes to speed. Ties need 100 items of a continuous measure
# before they can be shown (ADR-0026), so the tie-break's cases below stand for 120 (REPEAT 10).
REPEAT = 10
near = [0.9 + 0.001 * k + (0.0005 if k % 2 else -0.0005) for k in range(12)]
d = axes.decide(GOAL, {"a": arm("A", strong, 0.01, 100), "b": arm("B", near, 0.001, 300)})
check(
    "decide: arms not significantly different on quality are contenders, and the cheaper is recommended",
    d["contenders"] == ["a", "b"] or set(d["contenders"]) == {"a", "b"},
    d["why"],
)
check("decide: ... recommended by cost", d["recommended"] == "b", d["why"])
d = axes.decide(GOAL, {"a": arm("A", strong, 0.0, 100), "b": arm("B", near, 0.0, 300)})
check("decide: equal cost (both free) falls to speed", d["recommended"] == "a", d["why"])
d = axes.decide(
    {**GOAL, "success_criteria": {**GOAL["success_criteria"], "tie_break": ["speed", "cost"]}},
    {"a": arm("A", strong, 0.01, 300), "b": arm("B", near, 0.001, 100)},
)
check("decide: the goal's tie-break order (speed first) is followed", d["recommended"] == "b", d["why"])

# Limits disqualify, with the reason.
limited = {"success_criteria": {**GOAL["success_criteria"], "axes": {"speed": {"limit": 200}}}}
d = axes.decide(limited, {"a": arm("A", strong, 0.01, 500), "b": arm("B", weak, 0.001, 50)})
check(
    "decide: an arm over a speed limit (on its p95) is out, and the reason is said",
    d["out"].get("a") and "speed p95 500 ms > limit 200 ms" in d["out"]["a"][0] and d["recommended"] == "b",
    d["why"],
)
tail = [100] * 11 + [5000]
d = axes.decide(limited, {"a": arm("A", strong, 0.01, tail)})
check("decide: a slow tail breaks a p95 limit the mean would pass", "a" in d["out"], d["rows"]["a"]["speed"])

# Missing numbers are not recorded, never 0, never a reason to drop an arm, and an axis a contender
# does not record cannot break the tie (an unpriced hosted call must not lose on cost).
d = axes.decide(limited, {"a": arm("A", strong, None, None), "b": arm("B", near, 0.001, 100)})
check(
    "decide: an arm with no cost or latency is not out for it, and those axes cannot break its tie",
    "a" not in d["out"]
    and d["rows"]["a"]["cost"]["value"] is None
    and d["recommended"] is None
    and "cost is not recorded for A: it cannot break the tie." in d["why"],
    d["why"],
)
d = axes.decide(GOAL, {"a": arm("A", strong, None, 300), "b": arm("B", near, 0.001, 100)})
check(
    "decide: a skipped axis falls to the next (cost unknown for A, so speed decides)",
    d["recommended"] == "b" and any(w.startswith("By speed") for w in d["why"]),
    d["why"],
)

# Identical per-item scores are contenders in every strategy, whatever order the arms come in.
same = [1.0] * 12
for strategy in ("balanced", "quality_first", "frugal"):
    for order in (("a", "b"), ("b", "a")):
        both = {"a": arm("A", same, 0.01, 100), "b": arm("B", same, 0.001, 100)}
        d = axes.decide(
            {"success_criteria": {**GOAL["success_criteria"], "strategy": strategy}},
            {k: both[k] for k in order},
        )
        check(
            f"decide ({strategy}, order {order}): identical scores are contenders and the cheaper is recommended",
            set(d["contenders"]) == {"a", "b"} and d["recommended"] == "b" and d["leader"] == "a",
            d["why"],
        )

# An arm measured on part of the set is out, with the counts: it cannot lead on 4 items of 20.
REPEAT = 1
ITEMS[:] = [f"p{k:02d}" for k in range(20)]
full = arm("A", [0.8] * 20, 0.0, 100)
part = arm("B", [0.95] * 4 + [None] * 16, 0.0, 100)
part["scores"]["q"]["values"] = {k: v for k, v in part["scores"]["q"]["values"].items() if v is not None}
d = axes.decide(GOAL, {"a": full, "b": part})
check(
    "decide: an arm with fewer items than the group's most-measured is out, said with the counts",
    d["out"].get("b") == ["n 4 of 20 items"] and d["recommended"] == "a",
    d["why"],
)

# No items shared with the leader: the paired test cannot run, so the arm is out and says why.
ITEMS[:] = [f"x{k:02d}" for k in range(10)]
left = arm("A", [0.9] * 10, 0.0, 100)
ITEMS[:] = [f"y{k:02d}" for k in range(10)]
right = arm("B", [0.9] * 10, 0.0, 100)
d = axes.decide(GOAL, {"a": left, "b": right})
check(
    "decide: an arm sharing fewer than 2 items with the leader is out, with the reason",
    "shares fewer than 2 items with the leader" in (d["out"].get("b") or []) and d["recommended"] == "a",
    d["why"],
)

# A perfect 0 on a lower-is-better measure: the margin is a share of the group's range.
REPEAT = 10
ITEMS[:] = [f"w{k:02d}" for k in range(12)]
lower = {"success_criteria": {"primary": {"measure": "q", "direction": "lower"}}}
d = axes.decide(
    lower,
    {
        "a": arm("A", [0.0] * 12, 0.01, 100),
        "b": arm("B", [0.0] * 11 + [0.012], 0.0, 100),
        "c": arm("C", [0.5] * 12, 0.0, 100),
    },
)
check(
    "decide: a leader at 0 takes its margin from the group's range, and says so",
    "b" in d["contenders"]
    and d["recommended"] == "b"
    and any("of the group's range, the leader being 0" in w for w in d["why"]),
    d["why"],
)
d = axes.decide(lower, {"a": arm("A", [0.0] * 12, 0.01, 100), "b": arm("B", [0.0] * 11 + [0.012], 0.0, 100)})
check(
    "decide: a leader at 0 with one other arm says the goal must set its margin",
    any("set axes.quality.margin" in w for w in d["why"]),
    d["why"],
)
ITEMS[:] = [f"i{k:02d}" for k in range(12)]

# Flagged arms are shown, never recommended.
d = axes.decide(
    GOAL, {"a": arm("A", strong, 0.0001, 10, flags=["wrote the reference"]), "b": arm("B", weak, 0.01, 50)}
)
check("decide: a flagged arm is never the leader", d["leader"] == "b", d["why"])

# Different machines: speed neither compared nor used to break a tie.
d = axes.decide(
    GOAL,
    {"a": arm("A", strong, 0.0, 100), "b": arm("B", near, 0.0, 300)},
    machines={"a": "laptop", "b": "dgx"},
)
check(
    "decide: on different machines, speed is not compared and breaks no tie",
    d["recommended"] is None
    and d["rows"]["b"]["speed"]["vs_leader"]["verdict"].startswith("different machines")
    and any("different machines" in w for w in d["why"]),
    d["why"],
)

# A project's own axis: one line in the goal, then limited and tie-broken like the built-ins.
custom = {
    "success_criteria": {
        **GOAL["success_criteria"],
        "axes": {"grounded": {"measure": "grounded_rate", "direction": "higher", "limit": 0.8}},
        "tie_break": ["grounded", "cost"],
    }
}
d = axes.decide(
    custom,
    {
        "a": arm("A", strong, 0.001, 100, grounded_rate=0.95),
        "b": arm("B", near, 0.0001, 100, grounded_rate=0.85),
        "c": arm("C", near, 0.0, 100, grounded_rate=0.5),
    },
)
check(
    "decide: a custom axis takes a limit and a tie-break place like the built-ins",
    "c" in d["out"] and d["recommended"] == "a" and [x["name"] for x in d["axes"]][-1] == "grounded",
    d["why"],
)
check(
    "decide: a custom axis's direction comes from the project when the goal does not say",
    axes.axes_of({"success_criteria": {**GOAL["success_criteria"], "axes": {"wer": {}}}}, lambda m: "lower")[
        -1
    ]["direction"]
    == "lower",
)
ignored = {"success_criteria": {**GOAL["success_criteria"], "axes": {"speed": {"role": "ignore"}}}}
d = axes.decide(ignored, {"a": arm("A", strong, 0.0, 100), "b": arm("B", near, 0.0, 300)})
check(
    "decide: an axis the goal ignores is neither shown nor used (an overnight batch: speed)",
    "speed" not in d["rows"]["a"] and d["recommended"] is None,
    d["why"],
)
d = axes.decide(GOAL, {"a": arm("A", strong, 0.0, 100, tokens=500), "b": arm("B", weak, 0.0, 50, tokens=100)})
check("cost: tokens per item shown beside the dollars", d["rows"]["a"]["cost"]["tokens"]["mean"] == 500)

# The strategies, on the case that made them: 32 items, a 1.000 leader and a free 0.875 arm the paired test
# finds not significantly different from it (4 items differ). "Not significantly different" no longer makes a
# contender (ADR-0026): on 32 right/wrong items, 4 behind cannot be shown within any margin up to 0.25 (Tango).
REPEAT = 1
ITEMS[:] = [f"m{k:02d}" for k in range(32)]
top = [1.0] * 32
cheap = [1.0] * 28 + [0.0] * 4
pair = {"a": arm("Opus", top, 0.0025, 3000), "k": arm("keywords", cheap, 0.0, 1)}


def with_criteria(**extra):
    return {"success_criteria": {**GOAL["success_criteria"], **extra}}


d = axes.decide(GOAL, pair)
ni = d["rows"]["k"]["quality"].get("noninferior") or {}
check(
    "balanced (default): not significantly different, yet not shown within 5% on 32 items: not a contender",
    d["rows"]["k"]["quality"]["vs_leader"]["verdict"] == "not significant"
    and ni.get("method") == "tango"
    and ni.get("verdict") == "not shown"
    and d["recommended"] == "a",
    d["why"],
)
check(
    "balanced: the reason names the rule and its default margin",
    any("shown no worse than the leader by more than 0.05 (5% of the leader" in w for w in d["why"]),
    d["why"],
)
d = axes.decide(with_criteria(strategy="frugal"), pair)
check(
    "frugal: 10% of the leader by default; 0.125 behind is still not shown within it",
    d["recommended"] == "a" and any("0.1 (10% of the leader, frugal's default" in w for w in d["why"]),
    d["why"],
)
REPEAT = 10
pair = {"a": arm("Opus", top, 0.0025, 3000), "k": arm("keywords", cheap, 0.0, 1)}
d = axes.decide(with_criteria(axes={"quality": {"margin": 0.2}}), pair)
check(
    "the goal's margin (0.2) on 320 items: the free arm is shown within it, a contender, and wins on cost",
    d["recommended"] == "k" and "k" in d["contenders"],
    d["why"],
)
REPEAT = 1
d = axes.decide(with_criteria(strategy="quality_first", axes={"quality": {"margin": 0.15}}), pair)
check(
    "quality_first: the margin does not matter, the best quality is recommended",
    d["recommended"] == "a",
    d["why"],
)
check(
    "the strategy is named in the reasons",
    any(w.startswith("Strategy quality_first") for w in d["why"]),
    d["why"],
)

# frugal + [cost, quality]: the cheapest of the contenders, then the best of those (the goal's margin, 0.2, admits
# both free arms on 120 items).
REPEAT = 10
ITEMS[:] = [f"q{k:02d}" for k in range(12)]
lead = [0.9] * 12
free_hi = [0.9] * 10 + [0.6] * 2
free_lo = [0.9] * 9 + [0.6] * 3
d = axes.decide(
    {
        "success_criteria": {
            **GOAL["success_criteria"],
            "strategy": "frugal",
            "tie_break": ["cost", "quality"],
            "axes": {"quality": {"margin": 0.2}},
        }
    },
    {
        "lead": arm("Lead", lead, 0.01, 100),
        "hi": arm("FreeHi", free_hi, 0.0, 300),
        "lo": arm("FreeLo", free_lo, 0.0, 50),
    },
)
check(
    "tie_break [cost, quality]: among the equally cheap, the better quality wins (not the faster)",
    d["recommended"] == "hi" and any(w.startswith("By quality") for w in d["why"]),
    d["why"],
)

# Nobody eligible: the reason is named and counted, not a list of what might have happened.
REPEAT = 1
d = axes.decide(
    GOAL,
    {
        "a": arm("A", top, 0.0, 100, flags=["n 31 < min_items 32"]),
        "b": arm("B", cheap, 0.0, 100, flags=["n 31 < min_items 32"]),
    },
)
check(
    "decide: with no eligible arm, the reason names the flag and how many arms carry it",
    d["recommended"] is None and d["why"][-1] == "No arm is eligible: n 31 < min_items 32 (2 arms).",
    d["why"],
)

# The home page's glance: the recommendation against the baseline, as ratios.
from evaluation_harness.model.goal_views import axis_ratios  # noqa: E402

d = axes.decide(GOAL, {"a": arm("A", top, 0.01, 200), "b": arm("B", top, 0.001, 100)})
check(
    "ratios: the arm against the baseline per axis, the statistic named",
    axis_ratios(d, "a", "b") == ["cost 10×", "speed p95 2×"],
    str(axis_ratios(d, "a", "b")),
)
d = axes.decide(GOAL, {"a": arm("A", top, 0.0, 200), "b": arm("B", top, 0.0, None)})
check(
    "ratios: two zeros read same; an axis the baseline does not record is left out",
    axis_ratios(d, "a", "b") == ["cost same"],
    str(axis_ratios(d, "a", "b")),
)
check("ratios: none for the baseline itself", axis_ratios(d, "b", "b") == [])

# The goal page's line when the rule and the promoted baseline disagree (catalog_build.baseline_gap).
from evaluation_harness.catalog_build import baseline_gap  # noqa: E402
from evaluation_harness.catalog_charts import LABEL_H, label_y  # noqa: E402


class Scores:
    """Just enough of a catalog adapter for baseline_gap: per-item scores by arm."""

    def __init__(self, arms):
        self.arms = arms

    def scores(self, arm):
        return self.arms[arm]["scores"]


ITEMS[:] = [f"g{k:02d}" for k in range(20)]
v2 = [0.6] * 14 + [0.2] * 6
v1 = [0.2] * 14 + [0.6] * 6
pair = {"v2": arm("v2", v2, 0.0, 100), "v1": arm("v1", v1, 0.0, 100)}
d = axes.decide(GOAL, pair)
rows = [{"arm": "v2", "label": "v2"}, {"arm": "v1", "label": "v1", "baseline": True}]
fake: Any = Scores(pair)
gap = baseline_gap(fake, d, rows, "q")
check(
    "baseline gap: when the rule recommends another arm than the baseline, the page says by how much and the test",
    d["recommended"] == "v2"
    and gap.startswith("Differs from the promoted baseline, v1: v2 is +0.160 on q")
    and "(p " in gap,
    gap,
)
check(
    "baseline gap: nothing to say when the baseline is the recommendation",
    baseline_gap(fake, d, [{"arm": "v2", "label": "v2", "baseline": True}, {"arm": "v1", "label": "v1"}], "q")
    == "",
)

# A judge's group decides on the judge's own score: the goal's quality margin (written for its own
# measure's scale) does not apply there.
from evaluation_harness.model.goal_views import group_decision  # noqa: E402


class Judged(Scores):
    """The fake adapter, plus the direction a group decision asks for."""

    def lower_is_better(self, m, ds):
        return False


ITEMS[:] = [f"j{k:02d}" for k in range(20)]
judged = {"x": arm("X", [5.0] * 20, 0.01, 100), "y": arm("Y", [5.0] * 17 + [4.0] * 3, 0.0, 100)}
for a in judged.values():
    a["scores"]["judge_score"] = a["scores"].pop("q")
goal = {
    "goal_id": "g",
    "success_criteria": {
        "primary": {"measure": "q", "direction": "higher"},
        "axes": {"quality": {"margin": 0.5}},
    },
}
rows_j = [{"arm": k, "label": v["label"], "flags": []} for k, v in judged.items()]
jfake: Any = Judged(judged)
d = group_decision(jfake, goal, "ds", rows_j, "judge_score", {})
check(
    "judge group: the goal's quality margin (0.5, for its own measure) is not used on the judge's score",
    "y" not in d["contenders"] and any("5% of the leader" in w for w in d["why"]),
    d["why"],
)
check(
    "judge group: shown, not recommended (the goal decides on its own measure, q)",
    d["recommended"] is None and d.get("shown_only") and any("the goal decides on q" in w for w in d["why"]),
    d["why"],
)

# A silver group beside a gold one shows its leader and never recommends: gold decides.
from evaluation_harness.model.goal_views import gold_beside  # noqa: E402

tiers = {"gold/ds": "gold", "silver/ds": "silver"}
groups = [{"key": "gold/ds"}, {"key": "silver/ds"}]
check(
    "gold beside: a silver group names the gold group on its dataset; gold, or silver alone, names none",
    gold_beside(tiers, groups, "silver/ds") == "gold/ds"
    and gold_beside(tiers, groups, "gold/ds") is None
    and gold_beside(tiers, [{"key": "silver/ds"}], "silver/ds") is None,
)
d = group_decision(jfake, goal, "ds", rows_j, "judge_score", {}, gold="gold/ds")
check(
    "silver beside gold: the leader stands, nothing is recommended, and the reason says gold decides",
    d["leader"] == "x" and d["recommended"] is None and any("gold decides" in w for w in d["why"]),
    d,
)
for a in judged.values():
    a["scores"]["judge_score_unvalidated"] = a["scores"].pop("judge_score")
d = group_decision(jfake, goal, "ds", rows_j, "judge_score_unvalidated", {})
check(
    "unvalidated judges: the leader stands, nothing is recommended, and the reason says it is a trial",
    d["leader"] == "x" and d["recommended"] is None and any("a trial" in w for w in d["why"]),
    d,
)

# The glance's group tier: the references listing first, else the reference id's own prefix.
from evaluation_harness.model.goal_views import ref_tier  # noqa: E402

check(
    "ref tier: listed tier wins; an unlisted gold/ or silver/ id names its tier; anything else has none",
    ref_tier({"gold/x": "gold"}, "gold/x") == "gold"
    and ref_tier({}, "gold/x") == "gold"
    and ref_tier({}, "silver/x") == "silver"
    and ref_tier({}, "no reference") == "",
)

# The glance's baseline is the one the goal reads (RFC-022): its latest re-score when it has one.
from evaluation_harness.model.goal_views import baseline_read  # noqa: E402

v_bl = {
    "baselines": [{"arm": "runs/ds/old_v1"}, {"arm": "runs/ds/b_v1", "goal": "g1"}],
    "arms": [
        {"arm": "runs/ds/b_v1", "superseded_by": "runs-rescored/s1/runs/ds/b_v1"},
        {"arm": "runs-rescored/s1/runs/ds/b_v1"},
        {"arm": "runs/ds/old_v1"},
    ],
}
check(
    "glance baseline: a re-scored baseline is read from its re-score; one never re-scored is itself; a dataset's own "
    "baseline (no goal) is no goal's (RFC-027); none is None",
    baseline_read(v_bl, "g1")[1] == "runs-rescored/s1/runs/ds/b_v1"
    and baseline_read({**v_bl, "baselines": [{"arm": "runs/ds/old_v1", "goal": "g1"}]}, "g1")[1]
    == "runs/ds/old_v1"
    and baseline_read({**v_bl, "baselines": v_bl["baselines"][:1]}, "g1") == ([], None)
    and baseline_read({"arms": []}, "g1") == ([], None),
)

# A frontier name stays inside the chart: a long one on a dot in the middle goes to the side it fits on.
from evaluation_harness.catalog_build import HALF  # noqa: E402
from evaluation_harness.catalog_charts import LABEL_W, RIGHT, scatter  # noqa: E402

long_name = "triage_local_dgx_vllm_qwen3_30b_a3b_nvfp4_v1 · rescored 3d3a6afd"
svg = scatter([(0.0, 0.0, "a", ""), (0.55, 1.0, long_name, ""), (1.0, 0.5, "z", "")], "x", "y", width=HALF)
spans = []
for m in re.finditer(r'<text x="([0-9.]+)"[^>]*class="tick name"( text-anchor=end)?>([^<]*)<', svg):
    x, end, name = float(m.group(1)), bool(m.group(2)), unescape(m.group(3))
    spans.append((x - LABEL_W * len(name), x) if end else (x, x + LABEL_W * len(name)))
check(
    "chart names: every frontier name, a long one in the middle of a half-width chart too, lies inside the plot (clear of the y axis)",
    len(spans) == 2 and all(x0 >= 70 and x1 <= HALF - RIGHT + 1 for x0, x1 in spans),
    str(spans),
)
NAME_CLASS = 'class="tick name"'
check(
    "chart names are drawn after every dot, so no dot covers a name",
    svg.rfind("<circle") < svg.find(NAME_CLASS),
    f"last dot at {svg.rfind('<circle')}, first name at {svg.find(NAME_CLASS)}",
)

# Chart labels: a name that would cover one already placed moves a line; a clear one stays.
placed = [(100.0, 200.0, 50.0)]
check("labels: a clear spot is kept", label_y(80.0, 100.0, 200.0, placed, 10, 200) == 80.0)
moved = label_y(52.0, 150.0, 260.0, placed, 10, 200)
check(
    "labels: an overlapping name moves at least a line away",
    moved is not None and abs(moved - 50.0) >= LABEL_H,
    moved,
)
check(
    "labels: a name with no clear line in the plot is left off (None), not drawn over another",
    label_y(52.0, 150.0, 260.0, placed, 45, 55) is None,
)
check(
    "labels: names that do not overlap in x share a line",
    label_y(50.0, 210.0, 300.0, placed, 10, 200) == 50.0,
)

# A limit that is the baseline (RFC-022): out only when the paired test finds the arm worse than the baseline.
BL = {
    "success_criteria": {
        "primary": {"measure": "q", "direction": "higher"},
        "axes": {"noise": {"measure": "noise", "direction": "lower", "limit": "baseline"}},
    }
}
base = arm("base", 0.5, noise=[1] * 2 + [0] * 10)
arms_bl = {
    "base": base,
    "worse": arm("worse", 0.6, noise=[1] * 12),
    "same": arm("same", 0.6, noise=[1] * 3 + [0] * 9),
}
d = axes.decide(BL, arms_bl, baseline="base")
check(
    "limit baseline: an arm the paired test finds worse than the baseline is out, with the reason",
    "worse" in d["out"] and "worse than the baseline base" in "; ".join(d["out"]["worse"]),
    d["out"],
)
check(
    "limit baseline: an arm the paired test does not separate from the baseline stays in",
    "same" not in d["out"]
    and d["rows"]["same"]["noise"]["within"] is True
    and d["rows"]["base"]["noise"]["within"],
    d["out"],
)
d0 = axes.decide(BL, arms_bl)
check(
    "limit baseline: without a baseline no limit applies, and the decision says so",
    not d0["out"] and any("has none promoted" in w for w in d0["why"]),
    d0["why"],
)
# Each arm on its own (owner, 2026-10-31): one arm worse at p = 2/64 among ten others is out, which Holm across the
# eleven would not rule out (its first threshold is 0.05 / 11).
many = {"base": arm("base", 0.5, noise=[0] * 12), "worse": arm("worse", 0.6, noise=[1] * 6 + [0] * 6)}
many |= {f"f{k}": arm(f"f{k}", 0.6, noise=[1] + [0] * 11) for k in range(10)}
dm = axes.decide(BL, many, baseline="base")
check(
    "limit baseline: each arm is gated on its own, not corrected across the group",
    "worse" in dm["out"] and not any(k.startswith("f") for k in dm["out"]),
    dm["out"],
)
check(
    "limit baseline: the axis title says what the limit is",
    "no worse than the baseline (paired test)" in axes.axis_title(axes.axes_of(BL)[-1]),
)
_ids = [f"item-{n:03d}" for n in range(60)]
_tpi = axes.tokens_per_item(
    {
        "tokens_in": {"values": dict.fromkeys(_ids[::2], 1)},
        "tokens_out": {"values": dict.fromkeys(_ids[1::2], 2)},
    }
)
check(
    "tokens per item: in the items' order, whatever the hash seed (an API answer's bytes never depend on it)",
    list(_tpi) == sorted(_ids) and _tpi["item-001"] == 2.0,
    list(_tpi)[:5],
)

sys.exit(summary())
