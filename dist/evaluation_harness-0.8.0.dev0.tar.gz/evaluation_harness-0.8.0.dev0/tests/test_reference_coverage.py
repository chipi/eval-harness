#!/usr/bin/env python3
"""A run scored against references for only some of its items says so, and records it.

    python tests/test_reference_coverage.py

evh run took a gold directory as covering the dataset: an item with no reference file
was simply not scored, so gold for 20 of 200 items gave a 20-item mean recorded as a 200-item
gold run, with no warning. Now: partial coverage is warned, recorded (reference_coverage) and
named by the leaderboard; a reference directory with no file for any item is refused before a
single call. $0, offline (the tutorial's echo arms).
"""

import os
import shutil
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # harness/: the evaluation_harness package
sys.path.insert(0, str(Path(__file__).resolve().parent))
KIT = HERE.parent / "tutorial"
from evaluation_harness import _format  # noqa: E402
from evaluation_harness._check import check, summary  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))  # tests/: _runstore
import _runstore  # noqa: E402
import _runview  # noqa: E402

proj = Path(tempfile.mkdtemp(prefix="evh-coverage-"))
env = dict(os.environ, EVAL_HOME=str(proj), EVAL_BUILD_REF="test-coverage")
for k in ("EVAL_DATA_DIR", "EVAL_MAX_COST_USD", "EVAL_GOALS_DIR"):
    env.pop(k, None)


import _cli  # noqa: E402


def evh(*args):
    return _cli.run(proj, env, *args)


try:
    data = proj / "data"
    (data / "systems").mkdir(parents=True)
    _runstore.write_text(proj, _format.NAME, f"format: {_format.FORMAT}\n")
    shutil.copytree(KIT / "tickets", proj / "tutorial" / "tickets")
    r = evh("dataset-create", "--dataset-id", "tickets_v1", "--source-dir", "tutorial/tickets")
    r = r if r.returncode else evh("dataset-materialize", "--dataset-id", "tickets_v1")
    check("setup: the tutorial dataset", r.returncode == 0, r.stderr[-300:])
    _runstore.write_bytes(
        proj, "systems/tickets_lead1_v1.yaml", (KIT / "systems" / "tickets_lead1_v1.yaml").read_bytes()
    )
    gold = "references/gold/tickets_v1"
    files = sorted((KIT / "gold").glob("*.txt"))
    two = proj / "gold_two"
    two.mkdir()
    for f in files[:2]:
        shutil.copy(f, two / f.name)
    r = evh(
        "label-import", "--sheet", "gold_two", "--dataset-id", "tickets_v1", "--set", "two", "--by", "owner"
    )
    r = (
        r
        if r.returncode
        else evh(
            "reference-promote",
            "--dataset-id",
            "tickets_v1",
            "--labels",
            "two",
            "--tier",
            "gold",
            "--reason",
            "Two hand-written summaries, for a reference that covers some items.",
            "--by",
            "owner",
        )
    )
    check("setup: gold for two of the items, promoted", r.returncode == 0, (r.stdout + r.stderr)[-300:])

    r = evh("run", "--system", "tickets_lead1_v1", "--dataset", "tickets_v1", "--run-id", "partial")
    out = r.stdout + r.stderr
    m = _runview.record_of(proj, "partial")[1] if r.returncode == 0 else {}
    check(
        "partial gold: the run warns how many items have a reference",
        r.returncode == 0 and f"only 2 of {len(files)} items have a gold reference" in out,
        out[-400:],
    )
    check(
        "partial gold: the run records it",
        m.get("reference_coverage") == {"items_with_reference": 2, "items": len(files)},
        str(m.get("reference_coverage")),
    )
    lb = evh("leaderboard", "tickets_v1")
    check(
        "the leaderboard names a run whose quality is a mean over some items",
        f"had a reference for 2 of {len(files)} items" in lb.stdout,
        lb.stdout[-500:],
    )
    r = evh("validate")
    check("validate accepts the recorded coverage (schema)", r.returncode == 0, (r.stdout + r.stderr)[-400:])

    for n in _runstore.listdir(proj, gold):
        _runstore.unlink(proj, f"{gold}/{n}")
    _runstore.write_text(proj, f"{gold}/not_an_item.txt", "x")
    r = evh("run", "--system", "tickets_lead1_v1", "--dataset", "tickets_v1", "--run-id", "none")
    check(
        "a reference directory with no file for any item is refused before a call",
        r.returncode != 0
        and "nothing would be scored" in (r.stdout + r.stderr)
        and not _runstore.exists(proj, "runs/none"),
        (r.stdout + r.stderr)[-400:],
    )

    # rescore keeps what a project adapter attached at call time (`_extra` names it); it used
    # to drop any extra not named `truncated` or `reasoning_tokens` and call it a dropped metric.
    (proj / "adapter.py").write_text(
        "from evaluation_harness.adapter import Result\n"
        'PRIMARY_METRIC = "overlap_f1"\n'
        "def call_system(text, params):\n"
        '    return Result(output=text.split(".")[0] + ".", cost_usd=0.0, extra={"my_extra": 1.0})\n'
        "def score(output, reference):\n"
        '    return {"overlap_f1": 0.5} if reference is not None else {"output_words": 1.0}\n'
    )
    for f in files:
        _runstore.write_bytes(proj, f"{gold}/{f.name}", f.read_bytes())
    _runstore.write_text(
        proj,
        "systems/own_v1.yaml",
        "system_id: own_v1\nadapter: adapter.py\nparams:\n  provider: echo\n",
    )
    env["PYTHONPATH"] = str(HERE)
    r = evh("run", "--system", "own_v1", "--dataset", "tickets_v1", "--run-id", "own")
    # A scorer that gives other numbers: the same scorer on the same references would be the score the run has.
    (proj / "adapter.py").write_text(
        (proj / "adapter.py").read_text().replace('{"overlap_f1": 0.5}', '{"overlap_f1": 0.75}')
    )
    r2 = evh("rescore", "--dataset-id", "tickets_v1", "--match", "own_v1")
    # a re-score is a score under the run, read as "rescored <8 characters of the scorer>" (RFC-022)
    resc = [rec for _k, lb, rec in _runview.scores_of(proj, "own") if lb.startswith("rescored ")]
    mr = resc[-1] if r2.returncode == 0 and resc else {}
    check(
        "rescore keeps a project adapter's call-time extra, and reports nothing as dropped",
        r.returncode == 0
        and "my_extra" in (mr.get("scores") or {})
        and not mr.get("rescore_dropped_metrics"),
        (r.stdout + r.stderr + r2.stdout + r2.stderr)[-500:] + str(mr.get("rescore_dropped_metrics")),
    )
finally:
    shutil.rmtree(proj, ignore_errors=True)

sys.exit(summary())
