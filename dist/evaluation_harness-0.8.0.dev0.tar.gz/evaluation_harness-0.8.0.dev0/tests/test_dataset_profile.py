#!/usr/bin/env python3
"""Assertions for dataset profiles: `evh dataset-profile`, `evh dataset-items`, the dataset page's
"what's inside", V1 over data/profiles/.

    python tests/test_dataset_profile.py

In a throwaway project ($0, offline): three small datasets whose gold is labels, JSON lists and
free text; a rows map gives one of them a link per item. The profile counts items and words,
reads the gold's shape, links each item; `--with-text` refuses text git does not track and adds
text it does; the page shows the section, a profile of another version is marked stale, and a
dataset without a profile says how to write one.
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import _runstore  # noqa: E402
from evaluation_harness._check import check, summary  # noqa: E402

proj = Path(tempfile.mkdtemp(prefix="evh-profile-"))
env = dict(os.environ, EVAL_HOME=str(proj), EVAL_BUILD_REF="test-profile")
env.pop("EVAL_DATA_DIR", None)


import _cli  # noqa: E402


def evh(*args):
    return _cli.run(proj, env, *args)


def dataset(ds: str, texts: dict[str, str], gold: dict[str, str]) -> None:
    src = proj / "src" / ds
    src.mkdir(parents=True)
    for k, t in texts.items():
        (src / f"{k}.txt").write_text(t, encoding="utf-8")
    r = evh("dataset-create", "--dataset-id", ds, "--source-dir", f"src/{ds}")
    r = r if r.returncode else evh("dataset-materialize", "--dataset-id", ds)
    check(f"setup: {ds} is created and materialized", r.returncode == 0, (r.stdout + r.stderr)[-300:])
    g = proj / "src" / f"{ds}_gold"
    g.mkdir(parents=True)
    for k, t in gold.items():
        (g / f"{k}.txt").write_text(t, encoding="utf-8")
    r = evh(
        "label-import",
        "--sheet",
        f"src/{ds}_gold",
        "--dataset-id",
        ds,
        "--set",
        "gold_answers",
        "--by",
        "owner",
    )
    r = (
        r
        if r.returncode
        else evh(
            "reference-promote",
            "--dataset-id",
            ds,
            "--labels",
            "gold_answers",
            "--tier",
            "gold",
            "--reason",
            "The answers written for the test decide.",
            "--by",
            "owner",
        )
    )
    check(f"setup: {ds}'s gold, imported and promoted", r.returncode == 0, (r.stdout + r.stderr)[-300:])


def items_of(ds: str) -> list[dict]:
    return _runstore.read_json(proj, f"datasets/{ds}.json")["items"]


def item_ids(ds: str) -> list[str]:
    return [it["item_id"] for it in items_of(ds)]


# A project as `evh init` makes it carries its data's format: the model's reads (a page's `evh scorer-list`) refuse one
# that does not.
from evaluation_harness import _format  # noqa: E402

(proj / "data").mkdir(parents=True, exist_ok=True)
_runstore.write_text(proj, "project.yaml", f"format: {_format.FORMAT}\n")

try:
    (proj / "data").mkdir(exist_ok=True)
    dataset(
        "topics",
        {
            "a": "the market fell today",
            "b": "the team won",
            "c": "a new chip ships",
            "d": "rates rose again",
            "e": "a faster laptop",
            "f": "the cup final",
        },
        {"a": "Business", "b": "Sports", "c": "Sci/Tech", "d": "Business", "e": "Sci/Tech", "f": "Sports"},
    )
    # A short answer per item, none repeated: the items' gold, never listed as labels.
    dataset(
        "answers",
        {"a": "capital of France", "b": "two plus two", "c": "largest ocean"},
        {"a": "Paris", "b": "four", "c": "Pacific"},
    )
    dataset(
        "ents",
        {"a": "Ada met Alan in London", "b": "nothing here"},
        {"a": '[{"text":"Ada","type":"person"},{"text":"London","type":"location"}]', "b": "[]"},
    )
    long_ref = " ".join(["word"] * 12)
    dataset("notes", {"a": "one two three", "b": "four five"}, {"a": long_ref, "b": long_ref + " more"})
    ids = item_ids("topics")
    if not _runstore.sqlite():
        (proj / "data" / "sources").mkdir(parents=True, exist_ok=True)
    _runstore.write_text(
        proj,
        "sources/topics.rows.json",
        json.dumps(
            {
                "source": {"name": "acme/news", "url": "https://example.org/acme/news"},
                "item_url": "https://example.org/acme/news?row={row}",
                # keyed by id, matched by the item's bytes: ents and notes reuse the ids a and b
                "rows": {
                    it["item_id"]: {"row": i, "sha256": it["source_sha256"]}
                    for i, it in enumerate(items_of("topics"))
                },
            }
        ),
    )
    # dataset-create reads a fetcher's rows file into the record (E1): freeze topics again, the same items.
    r = evh("dataset-create", "--dataset-id", "topics", "--source-dir", "src/topics", "--force")
    check("setup: topics frozen again with its rows file", r.returncode == 0, (r.stdout + r.stderr)[-300:])

    r = evh("dataset-profile", "--dataset-id", "topics")
    p = _runstore.read_json(proj, "profiles/topics.json") if r.returncode == 0 else {}
    check("profile: written for a materialized dataset", r.returncode == 0, (r.stdout + r.stderr)[-300:])
    check(
        "profile: counts the items and their words",
        p.get("items", {}).get("n") == 6 and p["items"]["words"]["max"] == 4,
    )
    gold = (p.get("references") or [{}])[0]
    check(
        "profile: a gold of few short values reads as labels, with their counts",
        gold.get("shape") == "labels" and gold.get("labels") == {"Business": 2, "Sci/Tech": 2, "Sports": 2},
        json.dumps(gold),
    )
    check(
        "profile: each item links to its row from the record's source block, and the source is named",
        (p.get("source") or {}).get("ref") == "acme/news"
        and all(
            r_["source_url"] == f"https://example.org/acme/news?row={ids.index(r_['item_id'])}"
            for r_ in p["rows"]
        ),
    )
    evh("dataset-profile", "--dataset-id", "answers")
    pa = _runstore.read_text(proj, "profiles/answers.json")
    check(
        "profile: short answers that do not repeat are summarised, never listed per item",
        json.loads(pa)["references"][0]["shape"] == "text" and "Paris" not in pa and "Pacific" not in pa,
        pa[:300],
    )
    check("profile: no text unless asked for", not any("text" in r_ for r_ in p.get("rows", [])))

    evh("dataset-profile", "--dataset-id", "ents")
    pe = _runstore.read_json(proj, "profiles/ents.json")
    check(
        "profile: a JSON-list gold reads as entries per item",
        pe["references"][0]["shape"] == "lists" and pe["references"][0]["entries"]["max"] == 2,
        json.dumps(pe["references"]),
    )
    check("profile: an item with no source has no link", not any("source_url" in r_ for r_ in pe["rows"]))
    evh("dataset-profile", "--dataset-id", "notes")
    pn = _runstore.read_json(proj, "profiles/notes.json")
    check(
        "profile: a gold of longer text reads as words per reference", pn["references"][0]["shape"] == "text"
    )

    r = evh("dataset-profile", "--dataset-id", "topics", "--with-text")
    check(
        "--with-text: refused when git does not track the items' source files",
        r.returncode != 0 and "tracked by git" in r.stderr,
        (r.stdout + r.stderr)[-300:],
    )
    subprocess.run(["git", "init", "-q"], cwd=proj, check=True)
    r = evh("dataset-profile", "--dataset-id", "topics", "--with-text")
    check(
        "--with-text: refused in a git checkout that does not track the files",
        r.returncode != 0,
        r.stdout[-200:],
    )
    subprocess.run(["git", "add", "src/topics"], cwd=proj, check=True)
    r = evh("dataset-profile", "--dataset-id", "topics", "--with-text")
    check(
        "--with-text: refused while the files are only staged, not committed",
        r.returncode != 0,
        r.stdout[-200:],
    )
    git = ["git", "-c", "user.name=t", "-c", "user.email=t@example.test", "-c", "commit.gpgsign=false"]
    subprocess.run([*git, "commit", "-qm", "items"], cwd=proj, check=True)
    r = evh("dataset-profile", "--dataset-id", "topics", "--with-text")
    pt = _runstore.read_json(proj, "profiles/topics.json")
    check(
        "--with-text: adds each item's text once git tracks it",
        r.returncode == 0 and all(r_.get("text") for r_ in pt["rows"]),
        (r.stdout + r.stderr)[-300:],
    )
    evh("dataset-profile", "--dataset-id", "topics")

    r = evh("dataset-items", "topics")
    check(
        "dataset-items: prints the shape and a row per item",
        r.returncode == 0
        and "6 items" in r.stdout
        and "Business 2" in r.stdout
        and r.stdout.count("example.org") >= 6,
        r.stdout[-400:],
    )
    r = evh("dataset-items", "topics", "--item", ids[0][:10])
    check(
        "dataset-items --item: one item, with its text when it is materialized here",
        r.returncode == 0
        and any(t in r.stdout for t in ("the market fell", "the team won", "a new chip", "rates rose")),
        r.stdout[-300:],
    )
    r = evh("dataset-items", "nothing")
    check(
        "dataset-items: no profile is refused, saying how to write one",
        r.returncode != 0 and "dataset-profile" in r.stderr,
    )

    r = evh("validate")
    v1 = next((ln for ln in r.stdout.splitlines() if " V1 " in ln), "")
    check("V1: the profiles match profile.schema.json", "ok" in v1, v1 or r.stdout[-300:])

    # A profile of another version of the items: the page says it is stale.
    doc = _runstore.read_json(proj, "profiles/notes.json")
    doc["items_sha256"] = "0" * 64
    _runstore.write_text(proj, "profiles/notes.json", json.dumps(doc))
    _runstore.unlink(proj, "profiles/ents.json")
    out = proj / "catalog"
    r = evh("catalog", "--out", str(out))
    check("catalog: builds", r.returncode == 0, (r.stdout + r.stderr)[-300:])
    page = (out / "d" / "topics.html").read_text() if (out / "d" / "topics.html").is_file() else ""
    check(
        "page: what's inside, with the item count, the labels, a link per item and the source",
        "what&#x27;s inside" in page
        and "6 items" in page
        and "Sci/Tech" in page
        and page.count("source ↗") == 6
        and "acme/news" in page,
    )
    check(
        "page: no inline style attribute (the deployment's CSP)",
        ' style="' not in page.split("what&#x27;s inside")[1],
    )
    notes = (out / "d" / "notes.html").read_text() if (out / "d" / "notes.html").is_file() else ""
    check("page: a profile of another version is marked stale", "items changed since this profile" in notes)
    ents = (out / "d" / "ents.html").read_text() if (out / "d" / "ents.html").is_file() else ""
    check(
        "page: without a profile, it says how to write one",
        "No profile yet" in ents and "dataset-profile" in ents,
    )

    # Every page names the read command that answers it; with --mcp, the same as a tool call.
    import html as _html
    import re

    from evaluation_harness import ops

    READ_TOOLS = {op.name for op in ops.of_kind("read")}

    term = re.compile(r"<span data-elsewhere=term>(.*?)</span>")
    lines = {
        f.relative_to(out).as_posix(): [
            _html.unescape(c) for c in re.findall(r"<code>(.*?)</code>", m.group(1))
        ]
        for f in sorted(out.rglob("*.html"))
        for m in [term.search(f.read_text())]
        if m
    }
    check(
        "every page: names its command in the footer (the home, the lists, each dataset)",
        {"index.html", "datasets.html", "d/topics.html", "inspect.html"} <= set(lines),
        sorted(lines),
    )
    bad = []
    for where, cmds in lines.items():
        for c in cmds:
            words = c.split()
            if words[:1] != ["evh"] or words[1] not in READ_TOOLS:
                bad.append((where, c, "not a read tool"))
            elif where != "inspect.html":  # the inspector's is filled in from the arms picked
                r = evh(*words[1:])
                if r.returncode != 0:
                    bad.append((where, c, r.stderr[-120:]))
    check("every page: its command is a read tool, and runs as named", not bad, bad[:5])
    check(
        "without --mcp: no tool call is named", "data-elsewhere=mcp" not in (out / "index.html").read_text()
    )
    r = evh("catalog", "--out", str(out), "--mcp", "https://evals.example.test/mcp")
    d = (out / "d" / "topics.html").read_text()
    check(
        "--mcp: each page names its tool call, the server and how to connect",
        r.returncode == 0
        and "From an agent: the tool" in d
        and "<code>dataset-show</code> with <code>{&quot;dataset&quot;: &quot;topics&quot;}</code>" in d
        and "https://evals.example.test/mcp" in d
        and "how to connect" in d,
        d.split("<footer>")[-1][:600],
    )
    home = (out / "index.html").read_text()
    check(
        "share card: a description and og:title/og:description on every page, still noindex, no image without --card",
        '<meta name="description" content="' in home
        and '<meta property="og:title" content="' in home
        and '<meta name="robots" content="noindex, nofollow">' in home
        and "og:image" not in home
        and '<meta name="twitter:card" content="summary">' in home,
        home[:900],
    )
    r = evh("catalog", "--out", str(out), "--card", "https://evals.example.test/assets/social.png")
    d = (out / "d" / "topics.html").read_text()
    check(
        "share card: --card names the image, and the card is the large one",
        r.returncode == 0
        and '<meta property="og:image" content="https://evals.example.test/assets/social.png">' in d
        and '<meta name="twitter:card" content="summary_large_image">' in d,
        d[:900],
    )
    r = evh(
        "catalog",
        "--out",
        str(out),
        "--link",
        "Site=https://evals.example.test/",
        "--link",
        "MCP=https://evals.example.test/#mcp",
    )
    menu = (out / "goals.html").read_text().split('class="menu-links"')[-1].split("</nav>")[0]
    check(
        "phone menu: an MCP section the bar hides on phones is in the menu",
        r.returncode == 0 and 'class="menu-mcp" href="https://evals.example.test/#mcp"' in menu,
        menu[-300:],
    )
    r = evh("catalog", "--out", str(out), "--mcp", "javascript:alert(1)")
    check("--mcp: only an http(s) address", r.returncode != 0, r.stderr[-120:])
finally:
    shutil.rmtree(proj, ignore_errors=True)

sys.exit(summary())
