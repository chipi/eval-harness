#!/usr/bin/env python3
"""Operational commands: init, list-runs, self-check, sweep, cost-report.

    python tests/test_ops_commands.py

The least-covered scripts tested as a user would call them: with `python -m evaluation_harness
<command>`, in a fresh temp project. Tests verify what each command prints and writes.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # harness/: the evaluation_harness package
sys.path.insert(0, str(Path(__file__).resolve().parent))  # its siblings in tests/
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))  # _wheel
import _runstore
import _wheel
from evaluation_harness import _common
from evaluation_harness._check import check, store_under_test, summary


def aim(proj: Path) -> Path:
    """The project, for _runstore: this process caches the project it resolved first, and this test has several."""
    _common.project_root.cache_clear()
    return proj


def kit_system(proj: Path, name: str) -> None:
    """A tutorial system copied from the project's kit into its systems."""
    _runstore.write_text(aim(proj), f"systems/{name}", (proj / "tutorial/systems" / name).read_text())


def system_ids(proj: Path) -> list[str]:
    """The ids of the tickets_lead* systems of the project."""
    return sorted(
        n.removesuffix(".yaml")
        for n in _runstore.listdir(aim(proj), "systems")
        if n.startswith("tickets_lead") and n.endswith(".yaml")
    )


def evh_run(
    *args: str, cwd: Path | None = None, env: dict | None = None, timeout: int = 600
) -> subprocess.CompletedProcess:
    """Run an evh command in a project."""
    return subprocess.run(
        [sys.executable, "-m", "evaluation_harness", *args],
        cwd=cwd,
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
    )


def project_env(proj: Path, site: Path) -> dict:
    """Environment for evh in a project (installed from wheel)."""
    env = {
        **os.environ,
        "EVH_ACTOR": "person:test",
        "PYTHONPATH": str(site),
        "PYTHONDONTWRITEBYTECODE": "1",
        "EVAL_BUILD_REF": "test-ops",
        "GIT_AUTHOR_NAME": "t",
        "GIT_AUTHOR_EMAIL": "t@example.invalid",
        "GIT_COMMITTER_NAME": "t",
        "GIT_COMMITTER_EMAIL": "t@example.invalid",
    }
    for k in ("EVAL_HOME", "EVAL_DATA_DIR", "EVAL_MAX_COST_USD"):
        env.pop(k, None)
    return env


def test_init(tmp: Path) -> None:
    """init: creates folders, .gitignore, and with --tutorial copies the kit."""
    site = _wheel.install(tmp / "site-packages")
    proj = tmp / "proj_init"
    proj.mkdir()
    env = project_env(proj, site)

    # Basic init
    r = evh_run("init", "--store", store_under_test(), cwd=proj, env=env)
    if _runstore.sqlite():
        # In the database a directory is the files it holds: init makes data/ (where the database will be, and how a
        # command run in the project finds it) and says the store, never folders it did not make.
        made = "store    sqlite" in r.stdout and "folders" not in r.stdout
    else:
        made = (proj / "data/sources").is_dir() and (proj / "data/systems").is_dir()
    check(
        "init (no args): exit 0, makes data/ and the store's folders",
        r.returncode == 0
        and "project:" in r.stdout
        and (proj / "data").is_dir()
        and made
        and (proj / ".gitignore").is_file(),
        r.stdout[:200],
    )
    found = evh_run("data-ls", cwd=proj, env=env)
    store_now = "sqlite" if _runstore.sqlite() else "files"
    check(
        "after init, a command run in the project finds it (its data/ folder), in its store",
        found.returncode == 0 and f"store: {store_now}" in found.stdout,
        (found.stdout + found.stderr)[-300:],
    )

    # Init with --tutorial
    proj_tut = tmp / "proj_tut"
    proj_tut.mkdir()
    env_tut = project_env(proj_tut, site)
    r = evh_run("init", "--store", store_under_test(), "--tutorial", cwd=proj_tut, env=env_tut)
    check(
        "init --tutorial: exit 0, copies tutorial kit",
        r.returncode == 0
        and "tutorial" in r.stdout
        and (proj_tut / "tutorial/tickets").is_dir()
        and (proj_tut / "tutorial/systems").is_dir(),
        r.stdout[:200],
    )

    # Init twice: no overwrite
    r = evh_run("init", "--store", store_under_test(), cwd=proj, env=env)
    check(
        "init twice: exit 0, keeps existing files",
        r.returncode == 0 and "kept" in r.stdout and ".gitignore" in r.stdout,
        r.stdout[:200],
    )


def test_list_runs(tmp: Path) -> None:
    """runs-list: shows runs and baselines; filters; exits 0 even with no runs."""
    site = _wheel.install(tmp / "site-packages")
    proj = tmp / "proj_list"
    proj.mkdir()
    env = project_env(proj, site)

    # No runs yet
    r = evh_run("init", "--store", store_under_test(), "--tutorial", cwd=proj, env=env)
    r = evh_run("runs-list", cwd=proj, env=env)
    check(
        "runs-list (no runs): exit 0, says 'no runs yet'",
        r.returncode == 0 and "no runs yet" in r.stdout,
        r.stdout[:200],
    )

    # No baselines yet
    r = evh_run("baselines", cwd=proj, env=env)
    check(
        "evh baselines (none): exit 0, says 'no baselines yet'",
        r.returncode == 0 and "no baselines" in r.stdout,
        r.stdout[:200],
    )

    # Create a dataset and run
    r = evh_run(
        "dataset-create",
        "--dataset-id",
        "tickets_v1",
        "--source-dir",
        "tutorial/tickets",
        cwd=proj,
        env=env,
    )
    r = evh_run("dataset-materialize", "--dataset-id", "tickets_v1", cwd=proj, env=env)
    kit_system(proj, "tickets_lead1_v1.yaml")
    r = evh_run("run", "--system", "tickets_lead1_v1", "--dataset", "tickets_v1", cwd=proj, env=env)
    check("evh run: succeeds", r.returncode == 0, r.stderr[:200])

    # Now list the run
    r = evh_run("runs-list", cwd=proj, env=env)
    check(
        "runs-list (with run): shows run_id and metrics",
        r.returncode == 0 and "tickets_lead1" in r.stdout and "dataset_id" in r.stdout,
        r.stdout,
    )


def test_self_check(tmp: Path) -> None:
    """self-test: in a pinned package, runs a tutorial end-to-end."""
    site = _wheel.install(tmp / "site-packages")
    env = {
        **os.environ,
        "PYTHONPATH": str(site),
        "PYTHONDONTWRITEBYTECODE": "1",
        "EVAL_BUILD_REF": "test-ops-selftest",
    }
    for k in ("EVAL_HOME", "EVAL_DATA_DIR", "EVAL_MAX_COST_USD"):
        env.pop(k, None)

    # From an empty folder: `python -m` puts the working directory first on sys.path, and run from
    # harness/ (as make commands-check does) it imported the checkout, not the wheel, whose self-test
    # is the whole development suite: this test never tested the installed package, and ran every
    # test again (about 5 minutes of CI's commands job).
    bare = tmp / "bare"
    bare.mkdir()
    r = subprocess.run(
        [sys.executable, "-m", "evaluation_harness", "self-test"],
        cwd=bare,
        env=env,
        capture_output=True,
        text=True,
        timeout=900,
    )
    check(
        "self-test: exit 0, the installed package's check (the tutorial in a scratch folder), not the checkout's suite",
        r.returncode == 0
        and "the installed package, in a scratch folder" in r.stdout
        and "harness self-tests" not in r.stdout,
        r.stdout[-500:],
    )


def test_sweep(tmp: Path) -> None:
    """sweep: runs multiple arms, survives arm failure, ends with leaderboard."""
    site = _wheel.install(tmp / "site-packages")
    proj = tmp / "proj_sweep"
    proj.mkdir()
    env = project_env(proj, site)

    # Setup: init, dataset, materialize, arms
    evh_run("init", "--store", store_under_test(), "--tutorial", cwd=proj, env=env)
    evh_run(
        "dataset-create",
        "--dataset-id",
        "tickets_v1",
        "--source-dir",
        "tutorial/tickets",
        cwd=proj,
        env=env,
    )
    evh_run("dataset-materialize", "--dataset-id", "tickets_v1", cwd=proj, env=env)
    for arm in ("lead1", "lead2"):
        kit_system(proj, f"tickets_{arm}_v1.yaml")

    # Dry run: costs nothing
    system_list = system_ids(proj)
    r = evh_run(
        "sweep",
        "--systems",
        *system_list,
        "--dataset",
        "tickets_v1",
        "--dry-run",
        cwd=proj,
        env=env,
    )
    check(
        "sweep --dry-run: exit 0, says 'nothing was called'",
        r.returncode == 0 and "Dry run" in r.stdout,
        r.stdout,
    )

    # Real sweep
    system_list = system_ids(proj)
    r = evh_run(
        "sweep",
        "--systems",
        *system_list,
        "--dataset",
        "tickets_v1",
        "--repeat",
        "1",
        cwd=proj,
        env=env,
        timeout=120,
    )
    check(
        "sweep (real): exit 0, runs both arms, shows leaderboard",
        r.returncode == 0
        and "[1/" in r.stdout
        and "[2/" in r.stdout
        and ("FRONTIER" in r.stdout or "arm" in r.stdout),
        r.stdout[-500:],
    )


def test_cost_report(tmp: Path) -> None:
    """cost-report: reads billed vs recorded costs from runs."""
    site = _wheel.install(tmp / "site-packages")
    proj = tmp / "proj_cost"
    proj.mkdir()
    env = project_env(proj, site)

    # Setup: init, dataset, run with cost
    evh_run("init", "--store", store_under_test(), "--tutorial", cwd=proj, env=env)
    evh_run(
        "dataset-create",
        "--dataset-id",
        "tickets_v1",
        "--source-dir",
        "tutorial/tickets",
        cwd=proj,
        env=env,
    )
    evh_run("dataset-materialize", "--dataset-id", "tickets_v1", cwd=proj, env=env)
    kit_system(proj, "tickets_lead1_v1.yaml")
    evh_run("run", "--system", "tickets_lead1_v1", "--dataset", "tickets_v1", cwd=proj, env=env)

    # cost-report with no runs (nothing billed yet)
    r = evh_run("cost-report", "--dataset-id", "tickets_v1", cwd=proj, env=env)
    check(
        "cost-report (empty runs): exits 0, says 'no runs matched' or empty table",
        r.returncode == 0 or "no runs matched" in r.stdout,
        r.stdout,
    )

    # cost-report on all datasets
    r = evh_run("cost-report", cwd=proj, env=env)
    check(
        "cost-report (all): exit 0",
        r.returncode == 0,
        r.stdout[-200:],
    )


def main() -> int:
    """Run all operational command tests."""
    tmp = Path(tempfile.mkdtemp(prefix="evh-ops-"))
    try:
        test_init(tmp / "init")
        test_list_runs(tmp / "list")
        test_self_check(tmp / "selfcheck")
        test_sweep(tmp / "sweep")
        test_cost_report(tmp / "cost")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return summary()


if __name__ == "__main__":
    sys.exit(main())
