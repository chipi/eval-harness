#!/usr/bin/env python3
"""The hosted providers: one layer for the arms and the judges, keys by role. $0, no network.

    python tests/test_providers.py

Fake `openai` and `anthropic` modules record what each call was built with. Before one layer:
`provider: openrouter` read OPENAI_API_KEY and called OpenAI's address unless the arm set both
`base_url` and `api_key_env`; a judge ignored its declared `provider:` and went wherever the
environment's proxy or OpenRouter key pointed.
"""

import json
import os
import sys
import tempfile
import types
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # harness/: the evaluation_harness package
from evaluation_harness._check import check, summary

seen: dict = {}


class _Usage:
    """Like the SDK's usage object: model_dump() is what billed() reads (OpenRouter's cost)."""

    prompt_tokens, completion_tokens = 3, 1

    def model_dump(self):
        return {
            "prompt_tokens": 3,
            "completion_tokens": 1,
            "completion_tokens_details": {"reasoning_tokens": 7},
            "cost": 2.5e-06,
        }


class _Resp:
    def __init__(self):
        msg = types.SimpleNamespace(content='{"scores": {"accuracy": 4}}')
        self.choices = [types.SimpleNamespace(message=msg, finish_reason="stop")]
        self.usage = _Usage()
        self.model = "upstream/model-1"
        self.provider = "SomeHost"


class _OpenAI:
    def __init__(self, api_key=None, base_url=None, **opts):
        seen.clear()
        seen.update(sdk="openai", api_key=api_key, base_url=base_url, opts=opts)
        self.chat = types.SimpleNamespace(completions=types.SimpleNamespace(create=self._create))

    def _create(self, **kw):
        seen["kw"] = kw
        return _Resp()


class _Anthropic:
    def __init__(self, api_key=None, base_url=None, **opts):
        seen.clear()
        seen.update(sdk="anthropic", api_key=api_key, base_url=base_url, opts=opts)
        self.messages = types.SimpleNamespace(create=self._create)

    def _create(self, **kw):
        seen["kw"] = kw
        return types.SimpleNamespace(
            content=[types.SimpleNamespace(type="text", text='{"scores": {"accuracy": 4}}')],
            usage=types.SimpleNamespace(input_tokens=10, output_tokens=20),
            stop_reason="max_tokens",
            model="claude-x",
        )


fake_openai = types.ModuleType("openai")
fake_openai.OpenAI = _OpenAI  # type: ignore[attr-defined]
fake_anthropic = types.ModuleType("anthropic")
fake_anthropic.Anthropic = _Anthropic  # type: ignore[attr-defined]
sys.modules["openai"] = fake_openai
sys.modules["anthropic"] = fake_anthropic

from evaluation_harness import _fingerprint, _providers, adapter, judging  # noqa: E402

VARS = (
    "OPENAI_API_KEY",
    "OPENAI_BASE_URL",
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_BASE_URL",
    "OPENROUTER_API_KEY",
    "LITELLM_API_KEY",
    "LITELLM_BASE_URL",
    "MY_KEY",
)


def clear() -> None:
    for v in VARS:
        os.environ.pop(v, None)
        os.environ.pop("EVAL_JUDGE_" + v, None)


def refused(fn) -> str:
    try:
        fn()
    except SystemExit as exc:
        return str(exc)
    return ""


clear()

# ── arms: the bundled adapter ────────────────────────────────────────────────
os.environ["OPENROUTER_API_KEY"] = "sk-or-test-key"
r = adapter.call_system("text", {"provider": "openrouter", "model": "mistralai/mistral-small"})
check(
    "openrouter: OPENROUTER_API_KEY and OpenRouter's address, with nothing else set",
    seen.get("api_key") == "sk-or-test-key" and seen.get("base_url") == "https://openrouter.ai/api/v1",
    str({k: v for k, v in seen.items() if k != "kw"}),
)
check("openrouter: asks for the bill", (seen["kw"].get("extra_body") or {}).get("usage") == {"include": True})
check(
    "a reported bill is the cost, and is kept in meta where cost-report reads it",
    r.cost_usd == 2.5e-06 and (r.meta or {}).get("usage") == {"cost": 2.5e-06},
    f"{r.cost_usd} {r.meta}",
)
check(
    "an arm records the model and host that answered, and its reasoning tokens",
    r.meta.get("response_model") == "upstream/model-1"
    and r.meta.get("provider") == "SomeHost"
    and r.extra.get("reasoning_tokens") == 7.0,
    f"{r.meta} {r.extra}",
)
os.environ["OPENAI_API_KEY"] = "sk-openai-test-key"
adapter.call_system("text", {"provider": "openrouter", "model": "m"})
check(
    "openrouter: an OPENAI_API_KEY in the environment does not send the call to OpenAI",
    seen.get("api_key") == "sk-or-test-key" and "openrouter.ai" in (seen.get("base_url") or ""),
)
adapter.call_system("text", {"provider": "openai", "model": "gpt-x"})
check(
    "openai: OPENAI_API_KEY and the SDK's default address, no request body",
    seen.get("api_key") == "sk-openai-test-key"
    and seen.get("base_url") is None
    and not seen["kw"].get("extra_body"),
    str(seen),
)
check("openai: no call limit set, the SDK's own default stands", seen.get("opts") == {}, str(seen))
adapter.call_system("text", {"provider": "openai", "model": "gpt-x", "call_timeout_s": 30})
check(
    "openai: the arm's call_timeout_s is the client's timeout, never sent in the request",
    seen.get("opts") == {"timeout": 30.0} and "call_timeout_s" not in str(seen["kw"]),
    str(seen),
)
os.environ["ANTHROPIC_API_KEY"] = "sk-ant-test"
adapter.call_system("t", {"provider": "anthropic", "model": "claude-x", "call_timeout_s": 45})
os.environ.pop("ANTHROPIC_API_KEY")
check(
    "anthropic: the arm's call_timeout_s is the client's timeout",
    seen.get("opts") == {"timeout": 45.0},
    str(seen),
)
os.environ["OPENAI_BASE_URL"] = "http://127.0.0.1:8000/v1"
adapter.call_system("text", {"provider": "openai", "model": "local"})
check(
    "openai: OPENAI_BASE_URL points it at a compatible endpoint",
    seen.get("base_url") == "http://127.0.0.1:8000/v1",
)
os.environ.pop("OPENAI_BASE_URL")
adapter.call_system(
    "text",
    {
        "provider": "openrouter",
        "model": "m",
        "base_url": "http://127.0.0.1:9/v1",
        "api_key_env": "OPENAI_API_KEY",
    },
)
check(
    "openrouter: an arm's own base_url and api_key_env still win",
    seen.get("base_url") == "http://127.0.0.1:9/v1" and seen.get("api_key") == "sk-openai-test-key",
)
adapter.call_system(
    "t", {"provider": "openai", "model": "m", "reasoning": {"enabled": False}, "provider_routing": {"x": 1}}
)
check(
    "an arm's reasoning and provider_routing reach the request body, as a judge's do",
    seen["kw"].get("extra_body") == {"reasoning": {"enabled": False}, "provider": {"x": 1}},
    str(seen["kw"].get("extra_body")),
)
os.environ.pop("OPENROUTER_API_KEY")
msg = refused(lambda: adapter.call_system("text", {"provider": "openrouter", "model": "m"}))
check("openrouter: a missing key names OPENROUTER_API_KEY", "OPENROUTER_API_KEY" in msg, msg)
check("an arm is not told about judge variables", "EVAL_JUDGE_" not in msg, msg)

os.environ["LITELLM_API_KEY"] = "k-litellm"
msg = refused(lambda: adapter.call_system("t", {"provider": "litellm", "model": "eval-x"}))
check("litellm: no proxy address is refused, naming LITELLM_BASE_URL", "LITELLM_BASE_URL" in msg, msg)
os.environ["LITELLM_BASE_URL"] = "http://127.0.0.1:4001/"
adapter.call_system("t", {"provider": "litellm", "model": "eval-x"})
check(
    "litellm: the proxy's address with /v1, its key, the model as written",
    seen.get("base_url") == "http://127.0.0.1:4001/v1"
    and seen.get("api_key") == "k-litellm"
    and seen["kw"]["model"] == "eval-x",
    str(seen),
)

os.environ["ANTHROPIC_API_KEY"] = "sk-ant-test"
os.environ["MY_KEY"] = "sk-ant-other"
ra = adapter.call_system(
    "t", {"provider": "anthropic", "model": "claude-x", "usd_per_mtok_in": 1, "usd_per_mtok_out": 2}
)
check(
    "anthropic: ANTHROPIC_API_KEY, priced from the config, a max_tokens stop reads as length",
    seen.get("sdk") == "anthropic"
    and seen.get("api_key") == "sk-ant-test"
    and ra.cost_usd == round(10 / 1e6 + 20 * 2 / 1e6, 8)
    and ra.meta.get("finish_reason") == "length",
    f"{seen} {ra}",
)
adapter.call_system(
    "t",
    {"provider": "anthropic", "model": "claude-x", "api_key_env": "MY_KEY", "base_url": "http://a.invalid"},
)
check(
    "anthropic: api_key_env and base_url work as for every other provider",
    seen.get("api_key") == "sk-ant-other" and seen.get("base_url") == "http://a.invalid",
)
msg = refused(
    lambda: adapter.call_system("t", {"provider": "anthropic", "model": "c", "reasoning": {"enabled": True}})
)
check("anthropic: an OpenAI-shaped field is refused, not silently dropped", "reasoning" in msg, msg)

# ── judges: the same layer, keys EVAL_JUDGE_<NAME> first ─────────────────────
jp = {
    "provider": "litellm",
    "model": "eval-judge",
    "max_tokens": 400,
    "usd_per_mtok_in": 1,
    "usd_per_mtok_out": 1,
}
jr = judging.call_judge("judge this", jp)
check(
    "judge: goes where its provider says, sharing the arms' key when it has none of its own",
    seen.get("base_url") == "http://127.0.0.1:4001/v1" and seen.get("api_key") == "k-litellm",
    str(seen),
)
check(
    "judge: records cost, the model and host that answered, and reasoning tokens",
    jr.cost_usd == 2.5e-06
    and jr.meta["response_model"] == "upstream/model-1"
    and jr.meta["provider"] == "SomeHost"
    and jr.extra.get("reasoning_tokens") == 7.0
    and jr.extra.get("truncated") == 0.0,
    f"{jr}",
)
os.environ["EVAL_JUDGE_LITELLM_API_KEY"] = "k-judging"
os.environ["EVAL_JUDGE_LITELLM_BASE_URL"] = "http://judging.invalid"
judging.call_judge("judge this", jp)
check(
    "judge: EVAL_JUDGE_<NAME> is used first (its own key and its own proxy)",
    seen.get("api_key") == "k-judging" and seen.get("base_url") == "http://judging.invalid/v1",
    str(seen),
)
adapter.call_system("t", {"provider": "litellm", "model": "eval-x"})
check(
    "an arm never reads a judge's key",
    seen.get("api_key") == "k-litellm" and seen.get("base_url") == "http://127.0.0.1:4001/v1",
)
os.environ.pop("ANTHROPIC_API_KEY")
msg = refused(lambda: judging.call_judge("x", {"provider": "anthropic", "model": "c"}))
check(
    "judge: a missing key names both variables a judge may set",
    "EVAL_JUDGE_ANTHROPIC_API_KEY or ANTHROPIC_API_KEY" in msg,
    msg,
)
msg = refused(lambda: judging.call_judge("x", {"provider": "openrouterr", "model": "m"}))
check(
    "judge: an unknown provider is refused, naming the four",
    "unknown provider" in msg and "litellm" in msg,
    msg,
)
os.environ["OPENROUTER_API_KEY"] = "sk-or-test-key"
msg = refused(lambda: judging.call_judge("x", {"provider": "anthropic", "model": "c"}))
check("judge: an OpenRouter key does not stand in for the provider the judge names", msg != "", msg)

# ── identity ─────────────────────────────────────────────────────────────────
check(
    "identity: api_key_env is a credential, not part of what is measured",
    _providers.identity_params({"model": "m", "api_key_env": "K", "base_url": "u"})
    == {"model": "m", "base_url": "u"},
)
with tempfile.TemporaryDirectory() as td:
    kw: dict[str, Any] = {
        "root": Path(td),
        "dataset": {"dataset_id": "d", "items": []},
        "reference_id": None,
        "reference_tier": None,
        "system_id": "c",
        "adapter_id": "bundled",
        "adapter_path": None,
    }
    a_fp = _fingerprint.build_fingerprint(params={"provider": "openai", "model": "m"}, **kw)
    b_fp = _fingerprint.build_fingerprint(
        params={"provider": "openai", "model": "m", "api_key_env": "K2"}, **kw
    )
    check(
        "a run's fingerprint does not move when only the key it was paid with changes",
        a_fp["hash"] == b_fp["hash"] and "api_key_env" not in json.dumps(b_fp),
        str(b_fp["settings"]),
    )

# A key written into a config is never shown, and is named so evh run can refuse it.
params = {"api_key": "sk-1", "api_key_env": "X", "max_tokens": 300, "authorization": "Bearer x", "model": "m"}
check(
    "secret params: a literal key is named; max_tokens and the variable's name are not",
    _providers.secret_params(params) == ["api_key", "authorization"],
    str(_providers.secret_params(params)),
)
shown = _providers.shown_params(params)
check(
    "shown params: literal keys read (hidden), api_key_env is left out, the rest is kept",
    shown == {"api_key": "(hidden)", "max_tokens": 300, "authorization": "(hidden)", "model": "m"},
    str(shown),
)

os.environ["LITELLM_API_KEY"] = "sk-litellm-test"
adapter.call_system(
    "t", {"provider": "litellm", "model": "eval-x", "base_url": "http://gw:4000", "reasoning_effort": "none"}
)
check(
    "litellm: a reasoning setting is named in allowed_openai_params, so the proxy passes it on",
    (seen["kw"].get("extra_body") or {}).get("allowed_openai_params") == ["reasoning_effort"]
    and (seen["kw"].get("extra_body") or {}).get("reasoning_effort") == "none",
    str(seen.get("kw")),
)
adapter.call_system("t", {"provider": "litellm", "model": "eval-x", "base_url": "http://gw:4000"})
check(
    "litellm: without one nothing extra is sent",
    "allowed_openai_params" not in (seen["kw"].get("extra_body") or {}),
    str(seen.get("kw")),
)
os.environ.pop("LITELLM_API_KEY")
check(
    "litellm: an address given with /v1 already is not given a second one",
    _providers.route({"provider": "litellm", "model": "m", "base_url": "http://gw:4000/v1"}, "arm").base_url
    == "http://gw:4000/v1"
    and _providers.route({"provider": "litellm", "model": "m", "base_url": "http://gw:4000/"}, "arm").base_url
    == "http://gw:4000/v1",
)

clear()
local = {"provider": "openai", "model": "llama3.1:8b"}
check(
    "openai: a local server or Ollama's port needs no OPENAI_API_KEY (Ollama takes any key)",
    _providers.problems({**local, "base_url": "http://127.0.0.1:11434/v1"}, "arm") == []
    and _providers.problems({**local, "base_url": "http://localhost:8000/v1"}, "arm") == []
    and _providers.problems({**local, "base_url": "http://100.69.49.126:11434/v1"}, "arm") == []
    and _providers.route({**local, "base_url": "http://127.0.0.1:11434/v1"}, "arm").key == _providers.NO_KEY,
)
check(
    "openai: any other address still needs the key, and says so",
    any(
        "OPENAI_API_KEY is not set" in p
        for p in _providers.problems({**local, "base_url": "https://api.example.com/v1"}, "arm")
    )
    and any("OPENAI_API_KEY is not set" in p for p in _providers.problems(local, "arm")),
)
os.environ["OPENAI_API_KEY"] = "sk-real"
check(
    "openai: a key that is set is used, local or not",
    _providers.route({**local, "base_url": "http://127.0.0.1:11434/v1"}, "arm").key == "sk-real",
)
clear()

# env-check: a local server bills nothing, so it is no reason to demand a spending cap.
import subprocess  # noqa: E402

with tempfile.TemporaryDirectory() as proj:
    base_env = {
        k: v
        for k, v in os.environ.items()
        if not k.startswith("EVAL_") and k not in VARS and not k.startswith("EVAL_JUDGE_")
    }
    script = str(Path(__file__).resolve().parents[1] / "scripts" / "env_check.py")
    ran = subprocess.run(
        [sys.executable, script],
        env=dict(base_env, EVAL_HOME=proj, OPENAI_BASE_URL="http://127.0.0.1:11434/v1"),
        capture_output=True,
        text=True,
        timeout=60,
    )
    check(
        "env-check: a local server is callable with no key, said so, and asks for no spending cap",
        ran.returncode == 0
        and "openai: a local server, called with no key" in ran.stdout
        and "A provider key is set" not in ran.stdout,
        ran.stdout[-600:] + ran.stderr[-300:],
    )
    keyed = subprocess.run(
        [sys.executable, script],
        env=dict(base_env, EVAL_HOME=proj, OPENAI_API_KEY="test-openai-key-from-env-setup"),
        capture_output=True,
        text=True,
        timeout=60,
    )
    check(
        "env-check: a real key with no cap still fails, as before",
        keyed.returncode == 6 and "A provider key is set" in keyed.stdout,
        keyed.stdout[-400:],
    )
    # Where each variable came from (the 0.8.0 newcomer run could not tell its shell's keys from its .env's): one
    # only in .env, one only exported, one in both (the exported one wins, so the file's is not used).
    (Path(proj) / ".env").write_text(
        "ANTHROPIC_API_KEY=test-anthropic-key-from-file\nOPENAI_API_KEY=test-openai-key-from-file\nEVAL_MAX_COST_USD=1\n"
    )
    mixed = subprocess.run(
        [sys.executable, script],
        env=dict(
            base_env,
            EVAL_HOME=proj,
            OPENAI_API_KEY="test-openai-key-exported-over-env",
            OPENROUTER_API_KEY="test-openrouter-key-exported-only",
        ),
        capture_output=True,
        text=True,
        timeout=60,
    )
    line = {
        v: next((ln for ln in mixed.stdout.splitlines() if f" {v} " in ln), "")
        for v in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "OPENROUTER_API_KEY")
    }
    check(
        "env-check says where each variable came from: .env, the shell, or the shell over .env",
        "(.env)" in line["ANTHROPIC_API_KEY"]
        and "(shell, over .env)" in line["OPENAI_API_KEY"]
        and "(shell)" in line["OPENROUTER_API_KEY"]
        and "mid-run abort (.env)" in mixed.stdout,
        mixed.stdout[-900:],
    )
    # The retry count env-check prints is the count the retry core uses (it printed 3 while the core made 8 attempts).
    from evaluation_harness import _retry

    tries: list[int] = []

    def _always_429() -> None:
        tries.append(1)
        raise RuntimeError("429 rate limit exceeded, try again later")

    os.environ.pop("EVAL_MAX_RETRIES", None)
    try:
        _retry.call_with_retries(_always_429, sleep=lambda _s: None)
    except RuntimeError:
        pass
    retries_line = next((x for x in mixed.stdout.splitlines() if "EVAL_MAX_RETRIES" in x), "")
    check(
        "env-check prints the retry count the core uses when EVAL_MAX_RETRIES is unset",
        len(tries) > 1 and retries_line.split() == ["EVAL_MAX_RETRIES", str(len(tries))],
        f"core made {len(tries)} attempt(s); env-check: {retries_line!r}",
    )
sys.exit(summary())
