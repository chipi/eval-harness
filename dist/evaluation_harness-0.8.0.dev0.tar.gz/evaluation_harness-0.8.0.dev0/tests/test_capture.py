#!/usr/bin/env python3
"""The capture lane's first steps (RFC-019): importers, `evh importer-check`, `evh capture`.

In a throwaway project, offline: the jsonl importer's mapping, filter and window; the contract
check going red on each kind of bad record; a capture's files and hashes; no overwrite without
--force; --since-capture continuing from an earlier capture.

    python tests/test_capture.py
"""

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from evaluation_harness import _common, _format, _importers, _store  # noqa: E402
from evaluation_harness._check import check, summary  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))  # tests/: _runstore
import _runstore  # noqa: E402

proj = Path(tempfile.mkdtemp(prefix="evh-capture-"))
(proj / "data").mkdir()
_runstore.write_text(proj, _format.NAME, f"format: {_format.FORMAT}\n")
env = dict(os.environ, EVAL_HOME=str(proj))
env.pop("EVAL_DATA_DIR", None)


import _cli  # noqa: E402


def evh(*args):
    return _cli.run(proj, env, *args)


def out(r):
    return r.stdout + r.stderr


rows = [
    {
        "id": "a1",
        "body": "first",
        "kind": "x",
        "created_at": "2026-10-01T10:00:00Z",
        "outcome": {"verdict": "fixed"},
    },
    {"id": "a2", "body": "second", "kind": "", "created_at": "2026-10-05T10:00:00Z", "outcome": None},
    {
        "id": "a3",
        "body": {"signal": "s", "probes": {"p": 1}},
        "kind": "y",
        "created_at": "2026-10-09T10:00:00Z",
    },
    {"id": "a4", "body": "untimed", "kind": "x"},
]
(proj / "rows.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))


def ids(query):
    recs, _ = _importers.read("jsonl", {"path": str(proj / "rows.jsonl"), **query})
    return [r["id"] for r in recs]


# ── the jsonl importer ──────────────────────────────────────────────────────────────────────
check("jsonl: every row a record", ids({}) == ["a1", "a2", "a3", "a4"], ids({}))
check("jsonl: where on a value", ids({"where": {"kind": "x"}}) == ["a1", "a4"])
check(
    'jsonl: where on an empty cell matches ""',
    ids({"where": {"kind": ""}}) == ["a2"],
    ids({"where": {"kind": ""}}),
)
check(
    "jsonl: the window is [since, until), untimed rows left out",
    ids({"since": "2026-10-02", "until": "2026-10-09T10:00:00Z"}) == ["a2"],
    ids({"since": "2026-10-02", "until": "2026-10-09T10:00:00Z"}),
)
recs, _ = _importers.read("jsonl", {"path": str(proj / "rows.jsonl")})
r1 = _importers.normalise(next(recs))
check(
    "jsonl: id, body, fields, created_at and outcome mapped",
    r1["body"] == "first"
    and r1["fields"] == {"kind": "x"}
    and r1["created_at"] == "2026-10-01T10:00:00Z"
    and r1["outcome"] == {"verdict": "fixed"},
    r1,
)

# ── hashes ──────────────────────────────────────────────────────────────────────────────────
edited = dict(r1, outcome={"verdict": "noise"})
check(
    "record_sha256 moves when only the outcome changes; body_sha256 does not",
    _importers.record_sha256(edited) != _importers.record_sha256(r1)
    and _importers.body_sha256(edited) == _importers.body_sha256(r1),
)

# ── importer-check ──────────────────────────────────────────────────────────────────────────
r = evh("importer-check", "--importer", "jsonl", "--query", json.dumps({"path": "rows.jsonl"}))
check("importer-check: a good file passes", r.returncode == 0 and r.stdout.rstrip().endswith("PASS"), out(r))


def bad_file(name, lines):
    (proj / name).write_text("".join(json.dumps(x) + "\n" for x in lines))
    return evh("importer-check", "--importer", "jsonl", "--query", json.dumps({"path": name}))


for label, lines, says in (
    ("a repeated id", [{"id": "d", "body": "1"}, {"id": "d", "body": "2"}], "no id repeats"),
    ("an id with a slash", [{"id": "../x", "body": "1"}], "every record is well-formed"),
    ("an id over 200 characters", [{"id": "a" * 201, "body": "1"}], "every record is well-formed"),
    ("a bad time", [{"id": "t", "body": "1", "created_at": "not a time"}], "every record is well-formed"),
    ("no body and no fields", [{"id": "e", "body": None}], "every record is well-formed"),
):
    r = bad_file("bad.jsonl", lines)
    check(f"importer-check: red on {label}", r.returncode == 6 and f"FAIL {says}" in out(r), out(r)[-300:])

(proj / "flaky.py").write_text(
    "import random\n"
    "class Importer:\n"
    "    def __init__(self, options): pass\n"
    "    def records(self, query):\n"
    "        yield {'id': 'f', 'body': str(random.random())}\n"
)
r = evh("importer-check", "--importer", "flaky.py:Importer", "--query", "{}")
check(
    "importer-check: red when two reads differ",
    r.returncode == 6 and "FAIL two reads" in out(r),
    out(r)[-300:],
)
r = evh("importer-check", "--importer", "../escape", "--query", "{}")
check(
    "importer-check: a name that would leave data/ is refused",
    r.returncode != 0 and "lowercase" in out(r),
    out(r)[-200:],
)

# ── capture ─────────────────────────────────────────────────────────────────────────────────
q = json.dumps({"path": "rows.jsonl", "until": "2026-10-06"})
r = evh("capture", "--importer", "jsonl", "--query", q, "--capture", "c1")
_common.project_root.cache_clear()  # the importers above resolved this process's project; _runstore aims by EVAL_HOME
doc = (
    _runstore.read_json(proj, "captures/c1/capture.json")
    if _runstore.is_file(proj, "captures/c1/capture.json")
    else {}
)
check(
    "capture: the records in the window, each a file, each hashed",
    r.returncode == 0
    and doc.get("n_records") == 2
    and _runstore.listdir(proj, "captures/c1/records") == ["a1.json", "a2.json"],
    out(r),
)
rec = _runstore.read_json(proj, "captures/c1/records/a1.json") if doc else {}
check(
    "capture: capture.json holds the importer, its code hash, the query and the window",
    doc.get("importer") == "jsonl"
    and len(doc.get("importer_sha256", "")) == 64
    and doc.get("query") == json.loads(q)
    and doc.get("window") == {"until": "2026-10-06"},
    doc,
)
check(
    "capture: each record's sha256 is the record on disk",
    doc and {x["id"]: x["sha256"] for x in doc["records"]}["a1"] == _importers.record_sha256(rec),
)
r = evh("capture", "--importer", "jsonl", "--query", q, "--capture", "c1")
check("capture: never overwritten without --force", r.returncode != 0 and "--force" in out(r), out(r))
r = evh(
    "capture",
    "--importer",
    "jsonl",
    "--query",
    json.dumps({"path": "rows.jsonl"}),
    "--capture",
    "c2",
    "--since-capture",
    "c1",
)
doc2 = _runstore.read_json(proj, "captures/c2/capture.json") if r.returncode == 0 else {}
check(
    "capture --since-capture: starts where the earlier one ended, skips what it holds",
    doc2.get("query", {}).get("since") == "2026-10-06"
    and [x["id"] for x in doc2.get("records", [])] == ["a3"]
    and doc2.get("continues") == "c1",
    out(r) + json.dumps(doc2)[:300],
)
r = evh("capture", "--importer", "jsonl", "--query", json.dumps({"path": "bad.jsonl"}), "--capture", "c3")
check(
    "capture: malformed records write nothing",
    r.returncode != 0 and not _runstore.exists(proj, "captures/c3"),
    out(r)[-200:],
)

# ── the window is kept (the first live triage capture took August records into one that said 29 October) ──
# An importer that ignores since, and a record (a0) that c1's window held but c1 never saw: it arrived late.
(proj / "deaf.py").write_text(
    "class Importer:\n"
    "    def __init__(self, options): pass\n"
    "    def records(self, query):\n"
    "        for i, t in (('a0', '2026-10-03T10:00:00Z'), ('a1', '2026-10-01T10:00:00Z'),"
    " ('a2', '2026-10-05T10:00:00Z'), ('a3', '2026-10-09T10:00:00Z')):\n"
    "            yield {'id': i, 'body': i, 'created_at': t}\n"
)
r = evh("importer-check", "--importer", "deaf.py:Importer", "--query", "{}")
check(
    "importer-check: red on an importer that ignores since",
    r.returncode == 6 and "FAIL it keeps to since" in out(r),
    out(r)[-300:],
)
r = evh("importer-check", "--importer", "deaf.py:Importer", "--query", json.dumps({"since": "2026-10-04"}))
check(
    "importer-check: red when a record falls outside the query's own window",
    r.returncode == 6 and "FAIL every record is inside the window" in out(r) and "a0" in out(r),
    out(r)[-300:],
)
r = evh(
    "capture", "--importer", "deaf.py:Importer", "--query", "{}", "--capture", "c4", "--since-capture", "c1"
)
check(
    "capture: a record outside the window is named and nothing is written",
    r.returncode != 0
    and "a0: before since" in out(r)
    and "--late" in out(r)
    and not _runstore.exists(proj, "captures/c4"),
    out(r)[-300:],
)
r = evh(
    "capture",
    "--importer",
    "deaf.py:Importer",
    "--query",
    "{}",
    "--capture",
    "c4",
    "--since-capture",
    "c1",
    "--late",
)
doc4 = _runstore.read_json(proj, "captures/c4/capture.json") if r.returncode == 0 else {}
check(
    "capture --late: a record older than since that the earlier capture lacks is kept, listed as late",
    doc4.get("late") == ["a0"] and sorted(x["id"] for x in doc4.get("records", [])) == ["a0", "a3"],
    out(r)[-300:] + json.dumps(doc4)[:300],
)
_runstore.rmtree(proj, "captures/c4")

# ── dataset-from-capture ────────────────────────────────────────────────────────────────────
more = [{"id": f"m{i}", "body": f"Same  text {i % 3}", "kind": "abc"[i % 3]} for i in range(12)]
more.append({"id": "m_dup", "body": "same text 0", "kind": "a"})
(proj / "more.jsonl").write_text("".join(json.dumps(x) + "\n" for x in more))
evh("capture", "--importer", "jsonl", "--query", json.dumps({"path": "more.jsonl"}), "--capture", "m")
(proj / "data" / "fields").mkdir(exist_ok=True)
_runstore.write_text(
    proj,
    "fields/kinds.yaml",
    "fieldset_id: kinds\ndescription: test\nfields:\n"
    "  - {name: kind, type: choice, values: [a, b, c, x, y, ''], label: Kind, description: a kind, public: true}\n",
)


def ds(name):
    return _runstore.read_json(proj, f"datasets/{name}.json")


r = evh("dataset-from-capture", "--capture", "c1", "--dataset-id", "cap_v1")
d = ds("cap_v1") if r.returncode == 0 else {}
cap1 = _runstore.read_json(proj, "captures/c1/capture.json")
check(
    "from-capture: every record's body is an item, its hash the capture's body_sha256",
    sorted(it["item_id"] for it in d.get("items", [])) == ["a1", "a2"]
    and {it["item_id"]: it["source_sha256"] for it in d.get("items", [])}
    == {x["id"]: x["body_sha256"] for x in cap1["records"]},
    out(r)[-300:],
)
check(
    "from-capture: only the body: the outcome is nowhere in the item's bytes",
    _runstore.exists(proj, "sources/cap_v1")
    and all(
        "fixed" not in _runstore.read_text(proj, f"sources/cap_v1/{n}")
        for n in _runstore.listdir(proj, "sources/cap_v1")
    ),
)
check(
    "from-capture: made_from records the capture, its hash and the rules",
    d.get("made_from", {}).get("capture") == "c1"
    and len(d["made_from"].get("capture_sha256", "")) == 64
    and d["made_from"].get("records") == 2,
    d.get("made_from"),
)
r = evh("dataset-materialize", "--dataset-id", "cap_v1")
check("from-capture: the dataset materializes, hashes checked", r.returncode == 0, out(r)[-300:])
r = evh("validate")
check("from-capture: validate passes (V1 schema, V2, V4)", r.returncode == 0, out(r)[-400:])

r = evh("dataset-from-capture", "--capture", "m", "--dataset-id", "m_where", "--where", "kind:b")
check(
    "from-capture --where on a field",
    r.returncode == 0 and {it["item_id"] for it in ds("m_where")["items"]} == {"m1", "m4", "m7", "m10"},
    out(r)[-200:],
)
r = evh("dataset-from-capture", "--capture", "m", "--dataset-id", "m_text", "--dedup", "text")
check(
    "from-capture --dedup text: case and whitespace folded, the first kept",
    r.returncode == 0
    and len(ds("m_text")["items"]) == 3
    and "m_dup" not in {it["item_id"] for it in ds("m_text")["items"]},
    out(r)[-200:],
)
r = evh("dataset-from-capture", "--capture", "m", "--dataset-id", "m_exact", "--dedup", "exact")
check(
    "from-capture --dedup exact: only identical bodies",
    r.returncode == 0 and len(ds("m_exact")["items"]) == 4,
)
r = evh("dataset-from-capture", "--capture", "m", "--dataset-id", "m_nos", "--sample", "3")
check(
    "from-capture no longer samples: the capture does",
    r.returncode != 0 and "--sample" in out(r),
    out(r)[-200:],
)
# The fleet's beta (2026-11-12): the folder a dataset's items go in held the capture's own export, and it was deleted
# without a word. A file the harness did not write there is refused, and stays.
_runstore.write_text(proj, "sources/m_own/export.jsonl", '{"id": "x"}\n')
r = evh("dataset-from-capture", "--capture", "m", "--dataset-id", "m_own")
check(
    "from-capture: a folder holding a file the harness did not write is refused, the file kept",
    r.returncode != 0
    and "export.jsonl" in out(r)
    and _runstore.exists(proj, "sources/m_own/export.jsonl")
    and not _runstore.exists(proj, "datasets/m_own.json"),
    out(r)[-300:],
)
r = evh("dataset-from-capture", "--capture", "m", "--dataset-id", "m_where", "--where", "kind:b", "--force")
check("from-capture --force: the dataset's own items are replaced", r.returncode == 0, out(r)[-300:])
_runstore.write_text(proj, "sources/m_where/notes.txt", "mine\n")
r = evh("dataset-from-capture", "--capture", "m", "--dataset-id", "m_where", "--where", "kind:b", "--force")
check(
    "from-capture --force: a file beside the dataset's items that it did not write is refused, kept",
    r.returncode != 0 and "notes.txt" in out(r) and _runstore.exists(proj, "sources/m_where/notes.txt"),
    out(r)[-300:],
)

# ── a sample is the capture's (owner, 2026-11-01: 1 billion records a day are sampled as they are read) ──
logs = [
    {"id": f"l{i}", "body": f"line {i}", "created_at": f"2026-10-{1 + i % 20:02d}T00:00:00Z"}
    for i in range(2000)
]
(proj / "logs.jsonl").write_text("".join(json.dumps(x) + "\n" for x in logs))
lq = json.dumps({"path": "logs.jsonl", "until": "2026-10-11"})
want = sorted(x["id"] for x in logs if x["created_at"] < "2026-10-11" and _importers.sampled(x["id"], 0.1, 7))


def capture_ids(cid):
    d = _runstore.read_json(proj, f"captures/{cid}/capture.json")
    return d, sorted(x["id"] for x in d["records"])


r = evh(
    "capture", "--importer", "jsonl", "--query", lq, "--capture", "s1", "--sample-rate", "0.1", "--seed", "7"
)
d1, got1 = capture_ids("s1") if r.returncode == 0 else ({}, [])
evh("capture", "--importer", "jsonl", "--query", lq, "--capture", "s2", "--sample-rate", "0.1", "--seed", "7")
check(
    "capture --sample-rate --seed: the records whose seeded id hash falls below the rate, the same draw again",
    got1 == want
    and 60 < len(got1) < 140
    and capture_ids("s2")[1] == got1
    and d1.get("sample") == {"rate": 0.1, "seed": 7, "read": 1000, "kept": len(got1)}
    and "a sample of" in out(r),
    out(r)[-300:],
)
(proj / "pushdown.py").write_text(
    "import json\n"
    "from evaluation_harness import _importers\n"
    "class Importer:\n"
    "    def __init__(self, options): self.sample = options.get('sample')\n"
    "    def records(self, query):\n"
    "        for line in open('logs.jsonl'):\n"
    "            x = json.loads(line)\n"
    "            if x['created_at'] >= '2026-10-11': continue\n"
    "            if self.sample and not _importers.sampled(x['id'], **self.sample): continue\n"
    "            yield x\n"
)
r = evh(
    "capture",
    "--importer",
    "pushdown.py:Importer",
    "--query",
    "{}",
    "--capture",
    "s3",
    "--sample-rate",
    "0.1",
    "--seed",
    "7",
)
d3, got3 = capture_ids("s3") if r.returncode == 0 else ({}, [])
check(
    "capture: the importer receives the rule and may sample at the source; the same records result",
    got3 == want and d3["sample"]["read"] == len(want),
    out(r)[-300:],
)
for bad_args, says in (
    (["--sample-rate", "0.1"], "--seed"),
    (["--sample-rate", "0", "--seed", "7"], "share"),
    (["--sample-rate", "1.5", "--seed", "7"], "share"),
    (["--seed", "7"], "--sample-rate"),
):
    r = evh("capture", "--importer", "jsonl", "--query", lq, "--capture", "s_bad", *bad_args)
    check(f"capture {' '.join(bad_args)}: refused", r.returncode != 0 and says in out(r), out(r)[-200:])
allq = json.dumps({"path": "logs.jsonl"})
r = evh("capture", "--importer", "jsonl", "--query", allq, "--capture", "s4", "--since-capture", "s1")
d4, got4 = capture_ids("s4") if r.returncode == 0 else ({}, [])
check(
    "capture --since-capture keeps the earlier capture's sample rule",
    d4.get("sample", {}).get("rate") == 0.1
    and d4["sample"]["seed"] == 7
    and bool(got4)
    and all(_importers.sampled(i, 0.1, 7) for i in got4)
    and not set(got4) & set(got1),
    out(r)[-300:],
)
r = evh(
    "capture",
    "--importer",
    "jsonl",
    "--query",
    allq,
    "--capture",
    "s5",
    "--since-capture",
    "s1",
    "--sample-rate",
    "0.2",
    "--seed",
    "7",
)
check(
    "capture --since-capture with another sample rule is refused",
    r.returncode != 0 and "keeps it" in out(r),
    out(r)[-200:],
)
r = evh("capture-show", "s1")
check("captures: names the sample", "a sample: rate 0.1, seed 7" in out(r), out(r)[-300:])
for c in ("s1", "s2", "s3", "s4"):
    _runstore.rmtree(proj, f"captures/{c}")
r = evh(
    "dataset-from-capture",
    "--capture",
    "m",
    "--dataset-id",
    "m_f",
    "--fieldset",
    "kinds",
    "--field",
    "kind",
    "--where",
    "kind:a",
)
check(
    "from-capture --fieldset --field: record fields become typed item fields",
    r.returncode == 0 and all(it.get("fields") == {"kind": "a"} for it in ds("m_f")["items"]),
    out(r)[-300:],
)
r = evh("dataset-from-capture", "--capture", "c2", "--dataset-id", "cap_v2", "--from", "cap_v1")
lin = ds("cap_v2").get("derived_from", {}) if r.returncode == 0 else {}
check(
    "from-capture --from: the earlier version's items stay, the new are added, lineage recorded",
    sorted(it["item_id"] for it in ds("cap_v2")["items"]) == ["a1", "a2", "a3"]
    and lin.get("dataset_id") == "cap_v1"
    and lin.get("added") == ["a3"]
    and lin.get("removed") == [],
    out(r)[-300:],
)
# 2026-11-04, the triage v2 (a beta agent): a version made --from the last one, from a capture whose records
# correct an item's body, kept the old body and reported "0 changed".
(proj / "fix.jsonl").write_text(json.dumps({"id": "a1", "body": "The corrected body of a1."}) + "\n")
evh("capture", "--importer", "jsonl", "--query", json.dumps({"path": "fix.jsonl"}), "--capture", "c_fix")
r = evh("dataset-from-capture", "--capture", "c_fix", "--dataset-id", "cap_fixed", "--from", "cap_v1")
lin = ds("cap_fixed").get("derived_from", {}) if r.returncode == 0 else {}
a1: dict = (
    next(
        (it for it in ds("cap_fixed")["items"] if it["item_id"] == "a1"),
        {},
    )
    if r.returncode == 0
    else {}
)
check(
    "from-capture --from: a captured record replaces the earlier version's item of its id, counted changed",
    lin.get("changed") == ["a1"]
    and lin.get("added") == []
    and "corrected body" in _runstore.read_text(proj, f"sources/cap_fixed/{a1.get('source_path', '-')}")
    if a1
    else False,
    out(r)[-300:],
)
# and a field set alone keeps the fields it declares (it kept none, silently)
r = evh(
    "dataset-from-capture",
    "--capture",
    "m",
    "--dataset-id",
    "m_fs",
    "--fieldset",
    "kinds",
    "--where",
    "kind:b",
)
check(
    "from-capture --fieldset alone: every field the set declares is kept",
    r.returncode == 0
    and ds("m_fs")["items"]
    and all(it.get("fields") == {"kind": "b"} for it in ds("m_fs")["items"]),
    out(r)[-300:],
)
r = evh("dataset-from-capture", "--capture", "c1", "--dataset-id", "cap_v1")
check(
    "from-capture: a dataset is never overwritten without --force", r.returncode != 0 and "frozen" in out(r)
)
REC = "captures/c1/records"
rec_doc = _runstore.read_json(proj, f"{REC}/a1.json")
rec_doc["outcome"] = {"verdict": "noise"}
_runstore.write_text(proj, f"{REC}/a1.json", json.dumps(rec_doc))
r = evh("dataset-from-capture", "--capture", "c1", "--dataset-id", "cap_tampered")
check(
    "from-capture: a record edited since the capture is refused",
    r.returncode != 0 and "does not match the hash" in out(r),
    out(r)[-300:],
)

# ── V17: validate catches the edited record ────────────────────────────────────────────────
r = evh("validate")
check(
    "V17: validate fails on a capture whose record was edited (its outcome only)",
    r.returncode != 0 and "FAIL V17" in out(r) and "c1/a1" in out(r),
    out(r)[-400:],
)
rec_doc["outcome"] = {"verdict": "fixed"}  # put it back as it was
_runstore.write_text(proj, f"{REC}/a1.json", json.dumps(rec_doc))


def put_record(name, content):
    # the directory may be gone (files store); the store makes it where it keeps directories
    with _runstore._InProject(proj) as data:
        _store.mkdir(data / REC, parents=True, exist_ok=True)
        _store.write_bytes(data / REC / name, content)


# ── V17: a capture whose records are not fetched is named, not failed; a partial one fails ─────
aside = {n: _runstore.read_bytes(proj, f"{REC}/{n}") for n in _runstore.listdir(proj, REC)}
_runstore.rmtree(proj, REC)
r = evh("validate")
check(
    "V17: a capture with no record files (not fetched) is named, not failed",
    "not fetched here" in out(r) and "c1" in out(r) and "FAIL V17" not in out(r),
    out(r)[-400:],
)
put_record("a2.json", aside["a2.json"])
r = evh("validate")
check(
    "V17: a capture with some records missing still fails",
    r.returncode != 0 and "FAIL V17" in out(r) and "record file missing" in out(r),
    out(r)[-400:],
)
_runstore.rmtree(proj, REC)
for name, content in aside.items():
    put_record(name, content)

# ── capture-scrub ──────────────────────────────────────────────────────────────────────────
(proj / "scrub.py").write_text(
    "import json, pathlib, sys\n"
    "for f in pathlib.Path(sys.argv[1]).glob('*.json'):\n"
    "    r = json.loads(f.read_text())\n"
    "    if isinstance(r.get('body'), str) and 'Same' in r['body']:\n"
    "        r['body'] = r['body'].replace('Same', '<redacted>')\n"
    "        f.write_text(json.dumps(r))\n"
    "print('scrubbed what it found')\n"
)
before = _runstore.read_json(proj, "captures/m/capture.json")
r = evh("capture-scrub", "m", "--command", f"{sys.executable} scrub.py {{records}}")
after = _runstore.read_json(proj, "captures/m/capture.json")
changed = [e for e in after["records"] if "sha256_before_scrub" in e]
check(
    "capture-scrub: the records changed are re-hashed, their old hash kept, the command recorded",
    r.returncode == 0
    and len(changed) == 12
    and all(
        e["sha256_before_scrub"] == {b["id"]: b["sha256"] for b in before["records"]}[e["id"]]
        for e in changed
    )
    and after.get("scrubbed", {}).get("records_changed") == 12
    and "scrub.py" in after["scrubbed"].get("files_sha256", {})
    and not any(k.startswith("/") for k in after["scrubbed"]["files_sha256"]),
    out(r)[-300:],
)
r = evh("validate")
check("capture-scrub: V17 passes on the scrubbed capture", r.returncode == 0, out(r)[-300:])
(proj / "bad_scrub.py").write_text(
    "import pathlib, sys\nfor f in pathlib.Path(sys.argv[1]).glob('*.json'):\n    f.write_text('not json')\n"
)
snap = {
    n: _runstore.read_text(proj, f"captures/m/records/{n}")
    for n in _runstore.listdir(proj, "captures/m/records")
}
r = evh("capture-scrub", "m", "--command", f"{sys.executable} bad_scrub.py {{records}}")
check(
    "capture-scrub: a scrubber that breaks the records is undone, nothing recorded",
    r.returncode != 0
    and "as they were" in out(r)
    and snap
    == {
        n: _runstore.read_text(proj, f"captures/m/records/{n}")
        for n in _runstore.listdir(proj, "captures/m/records")
    },
    out(r)[-300:],
)
r = evh("capture-scrub", "m", "--command", "true")
check("capture-scrub: a command without {records} is refused", r.returncode != 0 and "{records}" in out(r))

# ── evh capture-list ───────────────────────────────────────────────────────────────────────────
r = evh("capture-list", "--json")
caps = {c["capture"]: c for c in json.loads(r.stdout)["result"]["captures"]} if r.returncode == 0 else {}
check(
    "captures: each capture, its importer, scrubbed or not, and the datasets made from it",
    set(caps) == {"c1", "c2", "m", "c_fix"}
    and caps["m"]["scrubbed"]
    and sorted(caps["c1"]["datasets"]) == ["cap_v1"]
    and sorted(caps["c_fix"]["datasets"]) == ["cap_fixed"]
    and caps["c2"]["continues"] == "c1",
    r.stdout[-400:],
)
r = evh("capture-show", "../x")
check("captures: a path as the id is refused", r.returncode != 0)

# ── --one-per, --where !=, --tag ───────────────────────────────────────────────────────────
r = evh("dataset-from-capture", "--capture", "m", "--dataset-id", "m_one", "--one-per", "kind")
check(
    "--one-per: one record per value of the field, the newest (by time, then id)",
    r.returncode == 0
    and sorted(it["item_id"] for it in ds("m_one")["items"]) == ["m7", "m8", "m_dup"]
    and ds("m_one")["made_from"]["one_per"] == "kind",
    out(r)[-300:],
)
r = evh(
    "dataset-from-capture",
    "--capture",
    "m",
    "--dataset-id",
    "m_not",
    "--where",
    "kind!=a",
    "--where",
    "kind!=b",
)
check(
    "--where FIELD!=VALUE drops the matching records",
    r.returncode == 0 and {it["item_id"] for it in ds("m_not")["items"]} == {"m2", "m5", "m8", "m11"},
    out(r)[-300:],
)
r = evh(
    "dataset-from-capture",
    "--capture",
    "c1",
    "--dataset-id",
    "cap_tagged",
    "--tag",
    "source=fleet",
    "--tag",
    "environment=prod",
)
check(
    "--tag: the dataset's own tags, outside its identity",
    r.returncode == 0 and ds("cap_tagged").get("tags") == {"source": "fleet", "environment": "prod"},
    out(r)[-300:],
)
r = evh("dataset-from-capture", "--capture", "c1", "--dataset-id", "cap_badtag", "--tag", "noequals")
check("--tag without KEY=VALUE is refused", r.returncode != 0 and "KEY=VALUE" in out(r))
r = evh("validate")
check("validate passes with tags and one_per (V1)", r.returncode == 0, out(r)[-300:])

# ── the catalog's Captures page ────────────────────────────────────────────────────────────
from evaluation_harness import catalog_build as cb  # noqa: E402
from evaluation_harness.catalog_adapter import HarnessAdapter  # noqa: E402

site = proj / "catalog"
with _runstore._InProject(proj):
    cb.build(HarnessAdapter(proj / "data"), site)
page = (site / "captures.html").read_text() if (site / "captures.html").exists() else ""
check(
    "catalog: a Captures page lists each capture, what continues what, and links the datasets made from it",
    all(f'id="capture-{c}"' in page for c in ("c1", "c2", "m"))
    and "continues c1" in page
    and 'cap_v1 <small class="muted">no runs yet</small>' in page
    and 'href="d/cap_v1.html"' not in page
    and "evh capture-list" in page
    and 'href="captures.html"' in (site / "index.html").read_text(),
    page[-600:],
)
# Only datasets with runs have a catalog page, so the origin's link is checked on the helper the page uses.
with _runstore._InProject(proj):
    meta = HarnessAdapter(proj / "data").dataset_meta("cap_v1")
check(
    "catalog: a dataset frozen from a capture links its origin to the capture",
    meta.get("capture") == "c1"
    and 'capture <a href="captures.html#capture-c1">c1</a>' in cb.origin_html(meta)
    and cb.origin_html({"origin": "version of x"}) == "version of x",
    str(meta),
)
# A version made from another and from a capture says both, on its page and in the list (owner, 2026-11-14).
lin = {"dataset_id": "x_v1", "added": [], "removed": [], "changed": ["i1"]}
by_ds = {
    "x_v1": {"parent": None, "children": ["x_v2"]},
    "x_v2": {"parent": lin, "children": [], "origin": "capture c1, where a:b", "capture": "c1"},
    "y_v1": {"parent": None, "children": [], "origin": "capture c1, where a:b", "capture": "c1"},
}
both, only_cap, only_ver = (cb._version_links(by_ds, d, "../") for d in ("x_v2", "y_v1", "x_v1"))
check(
    "catalog: a dataset's page says where it came from, the capture and the version it was made from, each linked",
    both[0] == "origin and versions" and 'capture <a href="../captures.html#capture-c1">c1</a>' in both[1]
    and 'Made from <a class="cell-link" href="../d/x_v1.html">' in both[1]
    and only_cap[0] == "origin" and "c1</a>" in only_cap[1] and "Made from" not in only_cap[1]
    and only_ver[0] == "versions" and "Made into" in only_ver[1] and "capture" not in only_ver[1],
    [both, only_cap, only_ver],
)  # fmt: skip
import _runfix  # noqa: E402

for d in ("cap_v1", "cap_v2"):
    _runfix.put_run(proj / "data", {"run_id": f"{d}_run", "system_id": "sys_a", "dataset_id": d, "scores": {"acc": 1.0},
                                    "primary_metric": "acc"}, [{"item_id": "i1", "acc": 1.0}])  # fmt: skip
said = {d: evh("dataset-show", d) for d in ("cap_v1", "cap_v2")}
check(
    "evh dataset-show: a capture-made dataset says its capture; one made from a version and a capture says both",
    all(r.returncode == 0 for r in said.values())
    and "made from capture c1" in said["cap_v1"].stdout and "derived from cap_v1:" in said["cap_v2"].stdout
    and "from capture c2" in said["cap_v2"].stdout,
    {d: (r.stdout + r.stderr)[-400:] for d, r in said.items()},
)  # fmt: skip

# 2026-11-04 (a beta agent): an importer named by a path relative to the project was not found when the
# command ran from another directory, though a capture records the path as given.
(proj / "tools").mkdir(exist_ok=True)
(proj / "tools" / "imp.py").write_text(
    "class Importer:\n"
    "    def __init__(self, options=None):\n        pass\n"
    "    def records(self, query):\n"
    "        yield {'id': 'x1', 'body': 'one', 'fields': {}, 'created_at': '2026-10-01T00:00:00Z',\n"
    "               'source': {'system': 's'}, 'outcome': {}}\n"
)
r = subprocess.run(
    [
        sys.executable,
        str(HERE / "cli.py"),
        "importer-check",
        "--importer",
        "tools/imp.py:Importer",
        "--query",
        "{}",
    ],
    cwd=proj / "data",
    env=env,
    capture_output=True,
    text=True,
)
check(
    "importer: a path relative to the project is found from a subdirectory too",
    "no file" not in out(r) and r.returncode == 0,
    out(r)[-300:],
)

sys.exit(summary())
