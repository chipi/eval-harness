# Tutorial kit

Six invented support tickets (`tickets/`) and a one-line summary of each written by a
person (`gold/`) — a small golden dataset — with four systems (`systems/`), a goal
(`goals/`), the tickets' fields (`fields/`, `ticket_fields.csv`) and a judge scorer
(`scorers/`, `judge_prompt.txt`). `evh init --store files --tutorial` copies it into a new project. Nothing
here is real customer data.

[Getting started](https://evals.humancopilot.eu/docs/GUIDE/) walks through creating a
dataset, running the arms, making a reference from a run, comparing them and choosing a
baseline, entirely offline. The tutorials that follow it use the rest of the kit:
[tutorial 3](https://evals.humancopilot.eu/docs/tutorials/3-frontier-reference-and-judging/)
the gold summaries and the judge scorer, whose two judges are `provider: fake` (offline, $0,
never validated; swap them for real models to use it for real),
[tutorial 4](https://evals.humancopilot.eu/docs/tutorials/4-rounds-and-versions/) the goal's
rounds, and [tutorial 5](https://evals.humancopilot.eu/docs/tutorials/5-catalog-and-inspector/)
the fields, and [tutorial 6](https://evals.humancopilot.eu/docs/tutorials/6-datasets-from-production/) `production/`: the same tickets as a support desk's export, with how each ended, and the rules that turn those outcomes into labels.
