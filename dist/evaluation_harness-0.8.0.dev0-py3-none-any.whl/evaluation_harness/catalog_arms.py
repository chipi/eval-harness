"""The arms page: every arm, and every system across the datasets it ran on.

    arms.html   the table of every arm (grouped by dataset, system, model, provider or what it is
                scored against; a derived arm under the arm it came from), the systems, what changed
                in the period, and each goal's arms on its trade-off charts

`evh arm-list` prints the same rows (`arm_rows`, `system_rows`). The period parts are the shared ones
(catalog_periods.py, catalog_assets/period.js); the grouping, facets and comparison are
catalog_assets/group.js and arms.js.
"""

from __future__ import annotations

import html

from evaluation_harness.model import goal_views as gv

#: Providers that bill per call over the network. An arm is hosted when it runs through one of
#: these or its system prices tokens; every other provider runs on the machine that ran the arm.
HOSTED_PROVIDERS = ("litellm", "openai", "anthropic", "openrouter", "together", "groq", "mistral", "gemini")

#: How many arms of one dataset re-measured the same way on one day make one line of "what
#: changed" instead of one each.
FEED_FOLD = 3

#: How a table of arms can be grouped: (key, the chip's name).
TIERS = ("free", "small", "mid", "large")

# The "dataset" chip groups by what can be ranked together (`set_key`): a dataset, scored one way, on one measure.
GROUPS = (
    ("", "no grouping"),
    ("set", "dataset"),
    ("system", "system"),
    ("model", "model"),
    ("provider", "provider"),
    ("scored", "scored against"),
)


def e(s) -> str:
    """`s` escaped for HTML text and attributes."""
    return html.escape(str(s), quote=True)


def _base(arm: str) -> str:
    """The label prefix an arm's id starts with (runs, silver, rescored-cd35dc1f, ...)."""
    return arm.split("/", 1)[0]


def arm_rows(A, by_ds: dict, only: str | None = None) -> list[dict]:
    """One row per arm, by dataset, then system, the system's own measurement first:
    {"arm", "label", "dataset", "system", "model", "provider", "family", "tier", "local",
    "weights", "record", "smoke", "quality", "scored", "reference", "how", "roles", "goal", "measure", "value", "lower",
    "repeats", "cost", "latency", "first", "last"}. `reference` is the reference set's id ("" when none). `weights` is "open", "proprietary" or "" (unknown: the
    adapter's model_facts does not list the model). `record` is the model record the arm uses ("" when
    none), `deployment` the deployment of it its system named ("" when none) and `smoke` that record's latest smoke of the arm's system: pass, check or none ("" without a
    record). `quality` is "a contender" when a goal's
    decision makes the arm a contender beside its quality leader (the leader too), "below the leader" when it
    weighs the arm and does not, "" when no decision weighs it. A role "over a limit" is an arm a
    goal leaves out for a limit it breaks; "not eligible" one it leaves out for another reason.
    `how` says what the arm is beside the system's other arms: measured, rescored against a
    reference, judged by a scorer, re-parsed, or run again.
    `source` and `moved`: for an arm derived from the system's measured arm on the same dataset
    (rescored, re-parsed, run again), that arm and how far the deciding measure moved from it; None
    when there is none, or the two are not on the same measure (a judge scores its own). `only`: the rows of this
    dataset and no other, and the goals' decisions (their paired tests) on it alone: a decision reads one dataset's
    arms, so each row is what it is among all of them."""
    from evaluation_harness import catalog_build as cb  # noqa: PLC0415
    from evaluation_harness import catalog_models as cm  # noqa: PLC0415

    if only is not None:
        by_ds = {only: by_ds[only]} if only in by_ds else {}
    cfg = getattr(A, "arm_config", None)
    fn = getattr(A, "model_facts", None)
    facts = (fn() if callable(fn) else None) or {}
    records = cm.arm_records(A)
    roles: dict = {}
    quality: dict = {}
    measure_of: dict = {}
    for r in gv.glance(A, by_ds):
        g, dec = r["goal"], r["dec"]
        # A leader is named with how far it is from the rest: the arms its lead over is not significant.
        lead = "leader"
        if dec and r["leader"]:
            near = [
                a
                for a in dec["eligible"]
                if a != r["leader"]
                and not str(
                    (dec["rows"][a]["quality"].get("vs_leader") or {}).get("verdict") or ""
                ).startswith("significant")
            ]
            if len(dec["eligible"]) > 1:
                lead = (
                    f"leader, not significantly ahead of {len(near)}"
                    if near
                    else "leader, significantly ahead"
                )
        for arm, word in (
            (r["baseline"], "baseline"),
            (r["leader"], lead),
            (r["recommended"], "recommended"),
        ):
            if arm:
                roles.setdefault(arm, []).append(word)
        for arm, rnd in (r.get("retired") or {}).items():
            roles.setdefault(arm, []).append(f"retired in {rnd}")
        if dec:
            for arm in dec["rows"]:
                measure_of.setdefault(arm, (g, r["measure"], r["lower"]))
                if arm in (dec.get("contenders") or []):
                    quality[arm] = "a contender"
                elif arm in dec["eligible"]:
                    quality.setdefault(arm, "below the leader")
                if arm not in dec["eligible"] and arm not in (r.get("retired") or {}):
                    over = any(" limit " in why for why in (dec.get("out") or {}).get(arm) or [])
                    roles.setdefault(arm, []).append("over a limit" if over else "not eligible")
    out = []
    for ds, v in sorted(by_ds.items()):
        tiers = {x["id"]: x["tier"] for x in v["refs"]}
        arms = sorted(
            v["arms"], key=lambda a: (a["arm"].rsplit("/", 1)[-1], _base(a["arm"]) != "runs", a["arm"])
        )
        for a in arms:
            c = cfg(a["arm"]) if callable(cfg) else {}
            p = (c or {}).get("params") or {}
            cid = (c or {}).get("system_id") or a["arm"].rsplit("/", 1)[-1]
            derived = next((r.get("derived") for r in a["run_list"] if r.get("derived")), "")
            if a["judge"]:
                how = f"judged by {a['judge']}"
            elif derived == "rescore":
                how = f"rescored against {a['reference'] or 'no reference'}"
            elif derived:
                how = {"reparse": "re-parsed"}.get(derived, derived)
            elif not a.get("read_as"):
                how = "measured"
            else:
                how = f"run again ({a['read_as']})"
            g, m, lower = measure_of.get(a["arm"], (None, a["metric"], a["lower"]))
            value = (a["means"].get(m) or (None,))[0] if m else None
            dated = [r.get("created_at") or "" for r in a["run_list"] if r.get("created_at")]
            out.append(
                {
                    "arm": a["arm"],
                    "label": a["label"],
                    "dataset": ds,
                    "system": cid,
                    "model": p.get("model") or "",
                    "provider": p.get("provider") or "",
                    "family": p.get("family") or "",
                    "tier": p.get("price_tier") or "",
                    "local": not (
                        (p.get("provider") or "") in HOSTED_PROVIDERS or p.get("usd_per_mtok_in") is not None
                    ),
                    "weights": (facts.get(p.get("model") or "") or {}).get("weights") or "",
                    "record": (records.get(a["arm"]) or {}).get("model_id", ""),
                    "deployment": (c or {}).get("deployment") or "",
                    "smoke": cm.smoke_of(records[a["arm"]], cid) if a["arm"] in records else "",
                    "quality": quality.get(a["arm"], ""),
                    "scored": "judge" if a["judge"] else (tiers.get(a["reference"]) or "no reference"),
                    # What the row is measured against, as every arms table says it (UXS index rule 4).
                    "kind": cb.row_kind(a, tiers),
                    "against": cb.scored_against(a, ""),
                    "reference": a.get("reference") or "",
                    "how": how,
                    "roles": roles.get(a["arm"], []),
                    "goal": g,
                    "measure": m,
                    "value": value,
                    "lower": lower,
                    "repeats": a["runs"],
                    "cost": (a["means"].get("cost_usd") or (None,))[0],
                    "latency": (a["means"].get("latency_ms") or (None,))[0],
                    "first": min(dated, default="")[:10],
                    "last": max(dated, default="")[:10],
                    "source": None,
                    "moved": None,
                    "superseded_by": a.get("superseded_by") or "",
                }
            )
    measured = {(r["dataset"], r["system"]): r for r in out if r["how"] == "measured"}
    for r in out:
        src = measured.get((r["dataset"], r["system"]))
        if r["how"] == "measured" or src is None:
            continue
        r["source"] = src["arm"]
        if r["measure"] and r["measure"] == src["measure"] and None not in (r["value"], src["value"]):
            r["moved"] = r["value"] - src["value"]
    return out


def system_rows(A, by_ds: dict, rows: list[dict], spend: list[dict]) -> list[dict]:
    """One row per system across every dataset it ran on: {"system", "model", "provider",
    "family", "datasets", "arms", "usd", "ranks": [(goal, dataset, rank, of)]}. A rank is the
    system's best arm on the goal's deciding measure among the arms the goal's decision weighs."""
    by_cfg: dict = {}
    for r in rows:
        by_cfg.setdefault(r["system"], []).append(r)
    arm_cfg = {r["arm"]: r["system"] for r in rows}
    usd: dict = {}
    for x in spend:
        if x.get("kind") == "arm" and isinstance(x.get("usd"), (int, float)) and x.get("arm") in arm_cfg:
            usd[arm_cfg[x["arm"]]] = usd.get(arm_cfg[x["arm"]], 0.0) + float(x["usd"])
    ranks: dict = {}
    for gr in gv.glance(A, by_ds):
        dec = gr["dec"]
        if not dec:
            continue
        # One place per system, and no arm a round retired (a re-timing, a second run, a paired side run):
        # a system run twice took two places, so the catalog read "#8 of 33" where the site reads "5th of 30".
        retired_in = gv.retired_in_of(A, gr["goal"])
        vals = {
            a: dec["rows"][a]["quality"]["value"] for a in dec["rows"] if not gv.retired_round(retired_in, a)
        }
        ordered = sorted(
            (a for a in vals if vals[a] is not None), key=lambda a: vals[a], reverse=not gr["lower"]
        )
        best: dict = {}
        for a in ordered:
            best.setdefault(arm_cfg.get(a, a.rsplit("/", 1)[-1]), len(best) + 1)
        for cid, i in best.items():
            ranks.setdefault(cid, []).append((gr["goal"], gr["dataset"], i, len(best)))
    out = []
    for cid, rs in sorted(by_cfg.items()):
        out.append(
            {
                "system": cid,
                "model": rs[0]["model"],
                "provider": rs[0]["provider"],
                "family": rs[0]["family"],
                "tier": rs[0]["tier"],
                "local": rs[0]["local"],
                "datasets": sorted({r["dataset"] for r in rs}),
                "arms": len(rs),
                "usd": usd.get(cid),
                "ranks": ranks.get(cid, []),
            }
        )
    return out


def period_arms(A, by_ds: dict, rows: list[dict]) -> dict:
    """{arm id | "c:<system>": row} in the shape catalog_build's period builders give: an arm's or
    a system's measured runs and what it was billed; new from its first run."""
    from evaluation_harness import catalog_build as cb  # noqa: PLC0415
    from evaluation_harness import catalog_periods as cp  # noqa: PLC0415

    w, idx = cb.window(A, by_ds), cp.arm_index(by_ds)
    by_arm = {a["arm"]: a for v in by_ds.values() for a in v["arms"]}
    out = {}
    for r in rows:
        runs = cp.runs_of([by_arm[r["arm"]]], idx)
        out[r["arm"]] = {
            "runs": runs,
            "usd": cp.spend_of(
                w["spend"], lambda x, arm=r["arm"]: x.get("kind") == "arm" and x.get("arm") == arm
            ),
            "made": r["first"],
        }
    for cid in sorted({r["system"] for r in rows}):  # sorted: a set's order differs per process (hash seed)
        ids = {r["arm"] for r in rows if r["system"] == cid}
        runs = cp.runs_of([by_arm[a] for a in ids], idx)
        out[f"c:{cid}"] = {
            "runs": runs,
            "usd": cp.spend_of(w["spend"], lambda x, ids=ids: x.get("kind") == "arm" and x.get("arm") in ids),
            # The day its first run was made, any run (a re-parsed one too), as the home page's systems tile dates it.
            "made": min(
                (r["created_at"][:10] for a in ids for r in by_arm[a]["run_list"] if r.get("created_at")),
                default="",
            ),
        }
    return out


def _role_tint(word: str) -> str:
    """A role's badge class: a result (leader, recommended) set solid, an arm left out drawn dashed."""
    if word.startswith(("leader", "recommended")):
        return " role-result"
    if word.startswith(("over a limit", "not eligible", "retired")):
        return " role-out"
    return ""


def set_key(r: dict) -> str:
    """What an arm can be ranked with: its dataset, how it is scored (against one reference, or by one judge) and the
    measure that decides, with its direction. Two arms in one group are on one scale."""
    how = r["how"] if r["how"].startswith("judged") else f"against {r['reference'] or 'no reference'}"
    measure = f" · {r['measure']} {'↓' if r['lower'] else '↑'}" if r["measure"] else ""
    return f"{r['dataset']} · {how}{measure}"


def _reading_order(r: dict) -> tuple:
    """A dataset's arms in the order to read them: what a goal decided first, then best on the deciding measure."""
    roles = " ".join(r["roles"])
    # An arm scored against the reference it wrote is read after the others: its score is its own outputs.
    rank = (
        5
        if r["kind"] == "t-author"
        else next(
            (i for i, w in enumerate(("recommended", "leader", "baseline")) if w in roles),
            3 if r["quality"] == "a contender" else 4,
        )
    )
    v = r["value"]
    return (r["dataset"], rank, v is None, (v if r["lower"] else -v) if v is not None else 0, r["arm"])


def render_arms(A, by_ds: dict, out, nav: list, rows: list[dict] | None = None) -> None:
    """Write arms.html."""
    from evaluation_harness import catalog_build as cb  # noqa: PLC0415
    from evaluation_harness import catalog_models as cm  # noqa: PLC0415
    from evaluation_harness import catalog_periods as cp  # noqa: PLC0415

    w = cb.window(A, by_ds)
    rows = rows if rows is not None else arm_rows(A, by_ds)
    period_rows, trs = period_arms(A, by_ds, rows), []
    # The page opens grouped by dataset, three rows a group (owner, 2026-11-12): within a dataset the arms a goal
    # decided on come first (recommended, leader, baseline, contender), then the best on the deciding measure.
    for r in sorted(rows, key=_reading_order):
        latency = (
            "—"
            if not r["latency"]
            else f"{r['latency'] / 1000:.1f} s"
            if r["latency"] >= 1000
            else f"{r['latency']:.0f} ms"
        )
        badges = "".join(
            f'<span class="role{_role_tint(x)}">{e(x)}</span>' for x in dict.fromkeys(r["roles"])
        )
        attrs = {
            "dataset": r["dataset"],
            "set": set_key(r),
            "system": r["system"],
            "model": r["model"] or "—",
            "provider": r["provider"] or "—",
            "scored": r["scored"],
            "where": "local" if r["local"] else "hosted",
            "tier": r["tier"] or "—",
            "weights": r["weights"] or "unknown",
            "quality": r["quality"] or "not decided",
        }
        against = r["against"] if r["against"] != "—" else "no reference"
        how = (
            "judged by " + cb.scorer_link(r["how"].removeprefix("judged by "), code=False)
            if r["how"].startswith("judged by ")
            else f"rescored against {against}"
            if r["how"].startswith("rescored against")
            else f"{e(r['how'])} · against {against}"
        )
        trs.append(
            {
                "key": r["arm"],
                "cls": r["kind"],
                "made": r["first"],
                "data": attrs,
                "cells": [
                    f'<input type="checkbox" class="pick" aria-label="pick {e(r["label"])}" data-arm="{e(r["arm"])}" data-ds="{e(r["dataset"])}">',
                    cb.arm_link(r["arm"], r["label"]) + (f"<br>{badges}" if badges else ""),
                    how
                    + (
                        '<br><span class="selfref">wrote its own reference</span>'
                        if r["kind"] == "t-author"
                        else ""
                    )
                    + (
                        f'<br><small class="muted">{cb.fmt(r["value"] - r["moved"])} → {cb.fmt(r["value"])} '
                        f"({r['moved']:+.3f}) vs measured</small>"
                        if r["moved"] is not None
                        else ""
                    )
                    + (
                        '<br><small class="muted">the goals read its re-score</small>'
                        if r["superseded_by"]
                        else ""
                    ),
                    cb.dataset_link(r["dataset"]),
                    # The model once, linked to its record when it has one (the id, then the record's link, named it
                    # twice); the smoke chip only when an arm smoke ran: "not smoked" was on 568 of 646 rows.
                    (
                        cm.model_link(r["record"], r["model"] or r["record"])
                        if r["record"]
                        else f"<code>{e(r['model'])}</code>"
                        if r["model"]
                        else "—"
                    )
                    + (f' <small class="muted">@ {e(r["deployment"])}</small>' if r["deployment"] else "")
                    + (
                        f" {cm.SMOKE_BADGE[r['smoke']]}"
                        if r["record"] and r["smoke"] in ("pass", "check")
                        else ""
                    )
                    + f'<br><small class="muted">{e(r["provider"] or "—")}{" · local" if r["local"] else ""}</small>',
                    (
                        cb.metric_link(r["measure"])
                        + f' <span data-v="{r["value"]}" data-g="{e(set_key(r))}" data-better="{"lower" if r["lower"] else "higher"}">'
                        + f'{cb.fmt(r["value"])}</span> <span class="dir" title="{"lower" if r["lower"] else "higher"} is better">'
                        + f"{'↓' if r['lower'] else '↑'}</span>"
                    )
                    if r["measure"] and r["value"] is not None
                    else "—",
                    f'<span data-v="{r["repeats"]}">{r["repeats"]}</span>',
                    f'<span data-v="{r["cost"] if r["cost"] is not None else ""}">{"$0" if r["cost"] == 0 else cb.fmt_amount(r["cost"], "usd") if r["cost"] is not None else "—"}</span>',
                    f'<span data-v="{r["latency"] if r["latency"] is not None else ""}">{latency}</span>',
                    f'<span data-flow="runs" data-line>{len(period_rows[r["arm"]]["runs"])}</span>',
                    '<span data-flow="usd">—</span>',
                ],
            }
        )
    cfgs = system_rows(A, by_ds, rows, w["spend"])
    crs = []
    for c in cfgs:
        key = f"c:{c['system']}"
        crs.append(
            {
                "key": key,
                "made": period_rows[key]["made"],
                "cells": [
                    f'<a href="?group=system&amp;q={e(c["system"])}#every"><code>{e(c["system"])}</code></a>',
                    (f"<code>{e(c['model'])}</code>" if c["model"] else "—")
                    + f'<br><small class="muted">{e(c["provider"] or "—")}{" · local" if c["local"] else ""}</small>',
                    "<br>".join(cb.dataset_link(d) for d in c["datasets"]),
                    f'<span data-v="{c["arms"]}">{c["arms"]}</span>',
                    f'<span data-v="{c["usd"] or 0}">{cb.fmt_amount(c["usd"], "usd") if c["usd"] else "—"}</span>',
                    # sorts by its best place, as a share of its field (#3 of 33 before #10 of 33)
                    (
                        f'<span data-v="{min(i / n for _g, _ds, i, n in c["ranks"]):.4f}">'
                        + "<br>".join(
                            f'{cb.goal_link(g)} <span class="nowrap">#{i} of {n}</span>'
                            for g, _ds, i, n in c["ranks"]
                        )
                        + "</span>"
                    )
                    if c["ranks"]
                    else "—",
                    f'<span data-flow="runs" data-line>{len(period_rows[key]["runs"])}</span>',
                    '<span data-flow="usd">—</span>',
                ],
            }
        )
    # What changed for arms in the period: first runs, re-measurements, baselines, retirements.
    # A dataset's arms re-measured the same way on one day (a rescore of every arm) are one change,
    # not one row each: they would bury everything else in the list.
    feed = []
    same: dict = {}
    for r in rows:
        if r["first"]:
            same.setdefault((r["first"], r["dataset"], r["how"]), []).append(r["arm"])
    for (day, ds, how), arms in same.items():
        if how != "measured" and len(arms) >= FEED_FOLD:
            feed.append([day, ("dataset", ds, len(arms)), how])
        else:
            feed.extend([day, a, how] for a in arms)
    for v in by_ds.values():
        for bl in v.get("baselines") or []:
            if bl.get("promoted_at") and bl.get("arm"):
                feed.append([bl["promoted_at"][:10], bl["arm"], "promoted as the baseline"])
    from evaluation_harness.model import rounds as model_rounds  # noqa: PLC0415

    fn = getattr(A, "rounds", None)
    shown = {r["arm"] for r in rows}
    for rnd in fn() if callable(fn) else []:
        for x in rnd.get("arm_records") or []:
            arm = model_rounds.arm_id(rnd, x)
            if x.get("retired") and arm in shown:
                day = (rnd.get("closed_at") or rnd.get("opened_at") or "")[:10]
                feed.append([day, arm, f"retired in {rnd['round_id']}: {x['retired'].get('reason', '')}"])
    feed.sort(key=lambda x: x[0], reverse=True)
    labels = {r["arm"]: r["label"] for r in rows}
    cb.write_period_rows(out, "arms", period_rows)

    # Each goal's arms on its trade-off charts, one goal at a time (the select picks).
    charts: list = []
    options: list = []
    for gr in gv.glance(A, by_ds):
        if not gr["dec"]:
            continue
        svg = cb.tradeoff_charts(gr["dec"], labels, gr["measure"])
        if svg:
            k = cb.slug(f"{gr['goal']['goal_id']}-{gr['dataset']}")
            options.append(
                f'<option value="{k}">{e(gr["goal"].get("title") or gr["goal"]["goal_id"])} · {e(gr["dataset"])}</option>'
            )
            ref = (
                f'<p class="small muted">scored against <code>{e(gr["group"])}</code></p>'
                if gr["group"]
                else ""
            )
            charts.append(f'<div data-tradeoff="{k}"{"" if not charts else " hidden"}>{ref}{svg}</div>')

    facet_chips = (
        '</span><span class="kindgroup"><span class="kind">runs</span>'
        + "".join(
            f'<button type="button" class="chip" data-facet="{f}" data-value="{v}" aria-pressed="false">{e(n)}</button>'
            for f, v, n in (("where", "local", "local"), ("where", "hosted", "hosted"))
        )
        + '</span><span class="kindgroup"><span class="kind">price</span>'
        + "".join(
            f'<button type="button" class="chip" data-facet="tier" data-value="{e(t)}" aria-pressed="false">{e(t)}</button>'
            # in their own order, cheapest first; a tier the systems name beyond these after them
            for t in sorted(
                {r["tier"] for r in rows if r["tier"]},
                key=lambda t: (TIERS.index(t) if t in TIERS else len(TIERS), t),
            )
        )
    )
    if any(r["quality"] for r in rows):
        facet_chips += (
            '</span><span class="kindgroup"><span class="kind">against the leader</span>'
            + "".join(
                f'<button type="button" class="chip" data-facet="quality" data-value="{v}" aria-pressed="false">{v}</button>'
                for v in ("a contender", "below the leader")
            )
        )
    if any(r["weights"] for r in rows):
        facet_chips += '</span><span class="kindgroup"><span class="kind">weights</span>' + "".join(
            f'<button type="button" class="chip" data-facet="weights" data-value="{v}" aria-pressed="false">{n}</button>'
            for v, n in (("open", "open weights"), ("proprietary", "proprietary"))
        )
    n_cfg = len(cfgs)
    body = cb.hero(
        "arms",
        "Arms and systems",
        f"{len(rows)} arms from {n_cfg} systems on {len(by_ds)} datasets. An arm is one system on one dataset "
        "scored one way: measured, rescored against another reference, judged, or run again (the how column "
        "says which; group by system to see them together). Pick arms on one dataset to open them in the inspector.",
        cp.bar(w["first"], w["until"]),
    )
    body += cb.block(
        "01",
        "every arm",
        '<details class="arm-tools" open><summary>group, filter and key</summary>'
        + cb.group_chips("arms", GROUPS)
        + f'<p class="row-chips facet-chips" data-for="arms" role="group" aria-label="only"><span class="muted small">only</span><span>{facet_chips}</span><span class="muted small">any in a kind, every kind at once</span></p>'
        + cp.row_chips("arms", "arms")
        + cb.ROW_KEY
        + '<p class="rolekey small muted"><span><b>leader</b> first on the goal\'s deciding measure among the arms its decision weighs; "not significantly ahead of N": N of them the paired test cannot tell apart from it</span><span><b>recommended</b> what the goal\'s rule picks from those (its strategy: cost, speed or quality first)</span><span><b>baseline</b> the arm the goal promoted</span><span><b>×N</b> after an arm: N runs of it, averaged per item</span><span><b>a contender</b> not significantly different from the leader; <b>below the leader</b> weighed and behind it</span></p>'
        + "</details>"
        + '<p class="compare-bar" hidden><span data-picked role="status" aria-live="polite">0 picked</span> <a class="btn small" data-compare href="#">open in the inspector</a> <button type="button" class="btn small" data-unpick>clear</button> <small class="muted" data-why></small></p>'
        + cb.table(
            "arms",
            [
                '<span class="vh">pick</span>',
                "arm",
                "how measured",
                "dataset",
                "model · provider",
                '<span data-first="desc">deciding measure</span>',
                "repeats",
                "cost / item",
                "latency",
                "runs in period",
                "spend in period",
            ],
            trs,
            "filter arms (name, model, provider…)",
            period=True,
            noun="arm",
            attrs={
                "default-group": "set",
                "fold": "3",
                "undecided": "no goal decides here: listed best first, not tested against a leader",
            },
        ),
        "every",
    )
    body += cb.block(
        "02",
        "systems",
        '<p class="small muted">One row per system, across every dataset it ran on: where it ranks on each '
        "goal is its best arm among the arms the goal's decision weighs.</p>"
        + cp.row_chips("systems", "systems")
        + cb.table(
            "systems",
            [
                "system",
                "model · provider",
                "datasets",
                "arms",
                "spend",
                "rank on each goal",
                "runs in period",
                "spend in period",
            ],
            crs,
            "filter systems",
            period=True,
        ),
        "systems",
    )
    if feed:
        body += cb.block(
            "03",
            "what changed in the period",
            '<p class="muted pempty" data-feed-empty="armfeed" hidden>Nothing changed for an arm in this period.</p>'
            + cb.table(
                "armfeed",
                ["when", "arm", "what"],
                [
                    {
                        "made": d,
                        "cells": [
                            f'<span data-v="{e(d)}">{e(d)}</span>',
                            f"{a[2]} arms on {cb.dataset_link(a[1])}"
                            if isinstance(a, tuple)
                            else cb.arm_link(a, labels.get(a, a)),
                            e(w_),
                        ],
                    }
                    for d, a, w_ in feed
                ],
            ).replace('class="data sortable"', 'class="data sortable" data-period-feed', 1),
            "changed",
        )
    if charts:
        body += cb.block(
            "04",
            "cost and quality, by goal",
            f'<p><select id="tradeoff-goal" class="chip more" aria-label="goal">{"".join(options)}</select></p>'
            + "".join(charts),
            "bygoal",
        )
    # a way past the 690 rows: a keyboard reached the first row after 37 stops and had no way to sections 02-04
    jump = '<nav class="jump small" aria-label="on this page">On this page: <a href="#every">every arm</a> · <a href="#systems">systems</a>'
    jump += ' · <a href="#changed">what changed</a>' if '"changed"' in body or 'id="changed"' in body else ""
    jump += ' · <a href="#bygoal">cost and quality, by goal</a>' if charts else ""
    body = body.replace(
        '<section class="block tight" id="every">',
        f'<div class="wrap">{jump}</nav></div><section class="block tight" id="every">',
        1,
    )
    cb.write(
        out,
        "arms.html",
        cb.page(
            "Arms",
            body,
            0,
            "arms",
            (*cb.PERIOD_SCRIPTS("arms"), "assets/group.js", "assets/arms.js"),
            nav=nav,
            item=A.item_word,
            elsewhere=(("arm-list", {}),),
        ),
    )
