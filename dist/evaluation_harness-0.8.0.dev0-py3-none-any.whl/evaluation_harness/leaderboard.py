"""Rank every arm that ran on one dataset — quality, cost and speed together.

`run-compare` answers "is B better than A". When you sweep four models you want
one table, not six pairwise comparisons, and you want the three axes side by
side because they trade against each other:

    the best output is often the slowest and dearest, and the decision is
    usually "which is good ENOUGH per dollar", not "which scores highest"

The tables are the goal's view of the dataset (model/goal_views): one per reference the arms are scored
against, each arm one row (its runs' repeats collapse into it and their spread is shown — an arm whose own spread
exceeds the gap to its neighbour is not distinguishable from it, and the table says so), flagged and led as the
goal page has it.

    evh leaderboard my_v1
    evh leaderboard my_v1 --sort overlap_f1
"""

from __future__ import annotations

import argparse
import math
import random
import shutil
import statistics
import textwrap
from collections.abc import Iterable

from evaluation_harness import _common, _jsonout, _store
from evaluation_harness._adapter import recorded_metric_kinds
from evaluation_harness._common import (
    BOOKKEEPING_PREFIXES,
    classify_metrics,
    die,
    how,
    read_json,
)
from evaluation_harness._record import derived_with
from evaluation_harness._runs import (
    AMBIGUOUS_HOW,
    direction,
    is_repeat_set,
    mixed_versions,
    per_item,
    runs_on,
)
from evaluation_harness.stats import kept

# COST_KEYS / SPEED_KEYS / DESCRIPTIVE_KEYS now live in _common, so that
# compare_runs.py judges direction the same way this ranks it.


# ── is the ordering above real? ──────────────────────────────────────────────
# A leaderboard sorted by a mean always produces an ordering. Whether that ordering
# survives re-running the eval is a different question, and it is the only one
# that matters -- so the answer is printed, not left to the reader.
#
# THREE readings, all order-independent, all computed over the whole table at once.
# What is NOT used: any walk down the table comparing each arm to a running "leader".
# That is a sorting algorithm, not a comparison -- its answer depends on whether you
# walk top-down or bottom-up, and on this data those two directions disagree about
# whether the top arm differs significantly from the field at all.

#: Two per-item values closer than this count as tied.
#:
#: 1e-9 is right for scores stored at full precision and WRONG for scores rounded on the
#: way to disk: at 6 decimals, arms that genuinely tie can land ~1e-6 apart and get
#: strictly ordered. The previous comment here claimed this tolerance "absorbs the
#: 6-decimal rounding". It does not.
#:
#: The fix is not a looser constant -- 1e-6 would merge a real gap (the closest distinct
#: rouge1 means on this data are 8.8e-7 apart). It is to notice the precision and say so,
#: so low-precision runs get rescored rather than quietly mis-tied.
_TIE_TOL = 1e-9

#: Below this many decimals, stored scores cannot be tie-detected reliably.
_MIN_TIE_DECIMALS = 8


def _stored_decimals(values: list[float]) -> int:
    """How many decimal places the stored values actually carry."""
    best = 0
    for v in values[:500]:
        t = f"{v!r}"
        if "." in t and "e" not in t:
            best = max(best, len(t.split(".")[1].rstrip("0")))
    return best


#: A value that is a whole number of 1/_FRACTION_DENOM's is a ratio of small integers (a mean
#: of 1-5 ratings over 2 judges and 2 dimensions is in quarters), stored exactly however few
#: decimals it shows, so its ties are exact and the precision note would be a false alarm.
_FRACTION_DENOM = 27720  # lcm(1..12)


def _small_fractions(values: list[float]) -> bool:
    vals = values[:500]
    return bool(vals) and all(abs(v * _FRACTION_DENOM - round(v * _FRACTION_DENOM)) < 1e-6 for v in vals)


NEMENYI_Q05 = {
    # alpha = 0.05, nu = infinity: the studentised range divided by sqrt(2).
    #
    # COMPUTED, NOT TRANSCRIBED -- see tools/nemenyi_table.py, which solves
    #   P(R <= q) = k * INTEGRAL phi(z) [Phi(z) - Phi(z-q)]^(k-1) dz  =  1 - alpha
    # by Simpson plus bisection, in stdlib. It reproduces all 24 values Demsar (2006)
    # publishes for k = 2..25 to within 0.0007, which is below the precision Demsar
    # prints, and `test_nemenyi_table` asserts that every time.
    #
    # It used to stop at 25 and this file REFUSED to print a critical difference above
    # that, rather than reuse a smaller k's value and understate the CD. The refusal
    # was right; the scope was not. Four of five evals here have 26-28 arms, so
    # four of five had no pairwise verdict at all -- over roughly thirty lines of
    # arithmetic. Found by external review.
    2: 1.9600,
    3: 2.3437,
    4: 2.5690,
    5: 2.7278,
    6: 2.8497,
    7: 2.9483,
    8: 3.0309,
    9: 3.1017,
    10: 3.1637,
    11: 3.2187,
    12: 3.2680,
    13: 3.3127,
    14: 3.3536,
    15: 3.3912,
    16: 3.4260,
    17: 3.4584,
    18: 3.4887,
    19: 3.5171,
    20: 3.5438,
    21: 3.5690,
    22: 3.5929,
    23: 3.6156,
    24: 3.6373,
    25: 3.6579,
    26: 3.6776,
    27: 3.6964,
    28: 3.7145,
    29: 3.7319,
    30: 3.7486,
    31: 3.7647,
    32: 3.7802,
    33: 3.7952,
    34: 3.8097,
    35: 3.8237,
    36: 3.8373,
    37: 3.8504,
    38: 3.8632,
    39: 3.8756,
    40: 3.8876,
}


def significance(
    matrix: dict[str, dict[str, float]],
    metric: str,
    seed: int = 20260925,
    asc: bool = False,
    raw_values: list[float] | None = None,
) -> dict:
    """Print the global test, the critical difference, and per-arm rank intervals; return them as numbers.

    `raw_values` are the per-item values as they came off disk, before any averaging
    (`_runs.per_item(raw=...)` collects them). Stored precision has to be measured on those:
    `fmean` returns full float precision whatever it was given, so checking the means
    reports 17 decimals for scores that were stored with 6."""
    arms = sorted(matrix)
    items = sorted(set.intersection(*(set(matrix[a]) for a in arms))) if arms else []
    k, N = len(arms), len(items)
    if k < 2 or N < 3:
        print(
            f"\n  Not enough paired data for a significance test "
            f"({k} arm(s), {N} shared item(s)). Ordering above is a mean, nothing more."
        )
        return {"enough_data": False, "metric": metric, "arms": k, "items": N}
    V = {a: [matrix[a][i] for i in items] for a in arms}

    # Within-item ranks: 1 = best on THAT item. Ranking inside the item is what removes
    # the item effect -- on a real dataset most of the variance is "some items are hard
    # for everyone", and an unpaired comparison leaves all of it in the noise.
    ranks: dict[str, list[float]] = {a: [] for a in arms}
    for j in range(N):
        # `asc` means lower is better for this metric (cost, latency). Without it the
        # within-item ranks were always "highest value = rank 1", so `--asc` produced a
        # correctly sorted TABLE above a significance block that had the field exactly
        # backwards -- the worst arm ranked first.
        col = sorted(((V[a][j], a) for a in arms), reverse=not asc)
        i = 0
        while i < len(col):
            grp = [i]
            # TIES NEED A TOLERANCE, not exact equality. These values are means of scores
            # that were rounded to 6 decimals on the way to disk, and several of these
            # metrics are ratios of small integers -- so two arms that genuinely tied on an
            # item come back differing by ~1e-7 and get strictly ordered. Exact equality
            # found 179 tied pairs where 216 were real, and that alone moved one reported
            # p-value from 0.110 to 0.138. `fmean` adds its own ~5e-17 on top.
            while grp[-1] + 1 < len(col) and abs(col[grp[-1] + 1][0] - col[i][0]) <= _TIE_TOL:
                grp.append(grp[-1] + 1)
            shared = statistics.fmean(x + 1 for x in grp)
            for x in grp:
                ranks[col[x][1]].append(shared)
            i = grp[-1] + 1
    avg_rank = {a: statistics.fmean(ranks[a]) for a in arms}

    raw = raw_values or []
    decimals = _stored_decimals(raw)
    if decimals and decimals < _MIN_TIE_DECIMALS and not _small_fractions(raw):
        print(
            f"\n  NOTE: these scores are rounded to ~{decimals} decimals, so arms that\n"
            f"        genuinely tie on an item can differ by rounding alone and be\n"
            f"        ordered anyway — which inflates the p-value. If the adapter's score()\n"
            f"        rounds, stop it rounding; then `{how('evh rescore', 'make rescore')}` regenerates them."
        )

    # Friedman, as a permutation test: shuffle which arm got which rank WITHIN each item
    # -- exactly the world where arms do not matter -- and see how often chance beats the
    # observed spread. No distributional assumption, no scipy.
    stat = lambda rk: sum(statistics.fmean(rk[a]) ** 2 for a in arms)  # noqa: E731
    observed = stat(ranks)
    by_item = [[ranks[a][j] for a in arms] for j in range(N)]
    B = 5000

    def friedman() -> dict:
        rng, hits = random.Random(seed), 0
        for _ in range(B):
            perm: dict[str, list[float]] = {a: [] for a in arms}
            for j in range(N):
                row = by_item[j][:]
                rng.shuffle(row)
                for a, v in zip(arms, row):
                    perm[a].append(v)
            if stat(perm) >= observed:
                hits += 1
        version, words, gauss = rng.getstate()
        return {"p": ((hits + 1) / (B + 1)).hex(), "state": [version, list(words), gauss]}

    # Kept with the paired tests' p's (stats.EVH_P_CACHE), read back exactly: 1.4 million shuffles for 28 arms
    # on 280 items took 5 s of CPU here and 47-60 s for the public MCP server's first call (2026-11-04). The
    # generator's state after them is kept too: the rank intervals below draw on from it, so they are the same.
    got = kept(
        f"friedman-perm-1:{B}:{seed}",
        ";".join(",".join(float(v).hex() for v in row) for row in by_item),
        friedman,
    )
    p = float.fromhex(got["p"])
    rng = random.Random()
    rng.setstate((got["state"][0], tuple(got["state"][1]), got["state"][2]))

    # ABOVE THE TABLE, SAY SO. This used to default to the k=25 value for any larger
    # k, which is too SMALL -- so the critical difference was too small and more pairs
    # were called distinguishable than the test supports. Four of this repo's five
    # evals have 26-28 arms, so four of five published "pairs distinguishable"
    # counts were mildly anti-conservative. Guessing a critical value is worse than
    # declining to print one.
    q = NEMENYI_Q05.get(k)
    cd = q * math.sqrt(k * (k + 1) / (6.0 * N)) if q else None
    span = max(avg_rank.values()) - min(avg_rank.values())
    pairs = [(a, b) for a in arms for b in arms if avg_rank[b] - avg_rank[a] > cd] if cd is not None else []

    print(f"\n  IS THE ORDERING REAL?   metric={metric}  k={k} arms  N={N} items")
    print(
        f"    global test (permutation on within-item ranks): p = {p:.4f}"
        f"  ->  {'an arm effect exists' if p < 0.05 else 'NO detectable arm effect'}"
    )
    if cd is None:
        print(
            f"    Nemenyi critical difference: NOT AVAILABLE for k={k} arms — the\n"
            f"    tabulated studentised range in this file stops at k={max(NEMENYI_Q05)}.\n"
            f"    No pairwise verdict is printed rather than reusing a smaller k's value,\n"
            f"    which would understate the critical difference and overstate how many\n"
            f"    pairs differ. Narrow the field with --match, or extend the table from a\n"
            f"    source you trust.   observed rank span = {span:.2f}"
        )
    else:
        print(f"    Nemenyi critical difference = {cd:.2f} rank positions; observed span = {span:.2f}")
        print(f"    pairs distinguishable: {len(pairs)} of {k * (k - 1) // 2}")
    if p >= 0.05:
        print(
            "    The table above is sorted, but these runs do not show the arms differ.\n"
            "    Do not report an ordering from it."
        )
    elif not pairs:
        print(
            "    An effect exists, but NO PAIR is distinguishable once all comparisons\n"
            "    are accounted for. 'Which arm is better than which' has no answer here."
        )

    # Resample ITEMS, re-rank the whole table each time, and report PROBABILITIES rather
    # than an interval.
    #
    # This used to print a 95% rank interval per arm. Those are MARGINAL: each is correct
    # on its own, but jointly they cover only ~57% of resamples, and two non-overlapping
    # intervals read as "this pair differs significantly" when that is exactly the claim they
    # cannot make -- the critical-difference line above is the only thing that can. A
    # simultaneous band would be honest but useless here: its half-width is 14-17 rank
    # positions out of 24.
    #
    # P(top 5) and P(bottom 5) answer the question people actually bring to a leaderboard
    # -- "is this one of the good ones" -- and cannot be misread as a pairwise verdict.
    R = 2000
    top_n = max(1, min(5, k // 4))
    tally: dict[str, list[float]] = {a: [] for a in arms}
    for _ in range(R):
        idx = [rng.randrange(N) for _ in range(N)]
        mu = {a: statistics.fmean(V[a][j] for j in idx) for a in arms}
        # MIDRANKS. `sorted` is stable and `arms` is alphabetical, so tied arms used to
        # take positions in NAME order -- on a saturated metric where many arms tie,
        # P(1st) was largely reporting which arm sorts first alphabetically. The same
        # bug was fixed in rank_stability.py and not looked for here.
        # ...and honour `asc` here too. The within-item ranks above were fixed for
        # `--asc` while this bootstrap still sorted descending, so the table said an
        # arm was rank 1 and P(1st) said 0.00 for the same arm in the same output.
        order = sorted(arms, key=lambda x: mu[x] if asc else -mu[x])
        i = 0
        while i < len(order):
            j2 = i
            # The tolerance the within-item ranks use: float sums of equal scores can differ in
            # the last bit and must still tie.
            while j2 + 1 < len(order) and abs(mu[order[j2 + 1]] - mu[order[i]]) <= _TIE_TOL:
                j2 += 1
            shared = (i + j2) / 2 + 1
            for x in range(i, j2 + 1):
                tally[order[x]].append(shared)
            i = j2 + 1
    width = max(len(a) for a in arms) + 2
    # With few arms the top is one place, and "top 1" would be P(1st) printed twice.
    top_col = top_n > 1
    by_rank = []
    for a in sorted(arms, key=lambda x: avg_rank[x]):
        t = tally[a]
        by_rank.append(
            (
                a,
                avg_rank[a],
                sum(1 for x in t if x == 1) / R,
                sum(1 for x in t if x <= top_n) / R,
                sum(1 for x in t if x > k - top_n) / R,
            )
        )
    if not _jsonout.table(
        ["arm", "avg_rank", "p_first", f"p_top_{top_n}", f"p_bottom_{top_n}"],
        by_rank,
    ):
        print(
            f"\n    {'arm':{width}} {'avg rank':>9} {'P(1st)':>8}"
            + (f" {f'P(top {top_n})':>10}" if top_col else "")
            + f" {f'P(bot {top_n})':>10}"
        )
        for a, rank, p1, pt, pb in by_rank:
            print(
                f"    {a:{width}} {rank:9.2f} {p1:8.2f}"
                + (f" {pt:10.2f}" if top_col else "")
                + f" {pb:10.2f}"
            )
    print(
        "    Probabilities over resampled items: how often this arm lands 1st"
        + (f", in the top {top_n}" if top_col else "")
        + f", in the bottom {top_n}.\n    NOT a pairwise claim -- the critical-difference line above is the only\n"
        f"    pairwise verdict here."
    )
    # Ties used to be broken by arm NAME, which on a saturated metric made P(1st) a measure of
    # the alphabet; tied arms now share a midrank.
    print(
        "    P(1st) means UNIQUELY first: tied arms share a midrank, so a draw counts\n"
        "    for nobody and the column can sum to less than 1."
    )
    return {
        "enough_data": True,
        "metric": metric,
        "arms": k,
        "items": N,
        "global_p": p,
        "arm_effect": p < 0.05,
        "nemenyi_cd": cd,
        "rank_span": span,
        "pairs_total": k * (k - 1) // 2,
        # Pairs are read only after the global test finds an arm effect (Nemenyi follows Friedman);
        # without one the text says "do not report an ordering", and the data carries no pairs.
        "pairwise_valid": p < 0.05 and cd is not None,
        "pairs_distinguishable": (len(pairs) if p < 0.05 else 0) if cd is not None else None,
        # [better, worse]: the first has the lower average rank by more than the critical difference
        "distinguishable_pairs": [list(x) for x in pairs] if p < 0.05 else [],
        "top_n": top_n,
        "avg_rank": {a: avg_rank[a] for a in sorted(arms, key=lambda x: avg_rank[x])},
        "resamples": R,
    }


def _terminal_width() -> int:
    return shutil.get_terminal_size((100, 24)).columns


def _wrap(text: str, indent: int) -> str:
    """`text` wrapped to the terminal, every line indented, the continuation lines two further."""
    return textwrap.fill(
        text,
        width=_terminal_width(),
        initial_indent=" " * indent,
        subsequent_indent=" " * (indent + 2),
        break_long_words=False,
        break_on_hyphens=False,
    )


def _cell(v: float | None, kind: str | None) -> str:
    """A number as the text table shows it (the JSON table keeps the stored value): money to the millionth of a
    dollar, time to a tenth, large counts whole, a score to four places."""
    if v is None:
        return "—"
    if kind == "cost":
        return f"{v:.6f}"
    if kind == "speed":
        return f"{v:.1f}"
    return f"{v:.0f}" if abs(v) >= 1000 else f"{v:.4f}"


UNVALIDATED = "_unvalidated"


def _head(k: str, split: bool) -> tuple[str, str]:
    """A column's header as two lines. Split, the shared `_unvalidated` ending drops to the second line: a judged
    table's three judge columns are 25 characters each and do not fit 100 columns with their name on one line."""
    if split and k.endswith(UNVALIDATED):
        return k[: -len(UNVALIDATED)], UNVALIDATED
    return k, ""


def runs_cell(n_scored: int, n_all: int) -> str:
    """The `runs` cell of a judged table: the runs the judge scored out of the arm's runs on the dataset (`1/3`), so an
    arm with repeats does not read as a single run."""
    return f"{n_scored}/{n_all}" if n_all > n_scored else str(n_scored)


def runs_note(read_as: Iterable[str]) -> str | None:
    """What `runs` counts in a judged table: judging scores one run of an arm, its latest (judge_score.discover_arms),
    so an arm with repeats shows 1/3 here, unlike every other table."""
    if any((x or "").startswith("judged/") for x in read_as):
        return (
            "runs: the judge scored the latest run of each arm, so an arm with repeats shows 1/3 (one of its three "
            "runs); its repeats are not averaged here."
        )
    return None


def _fit_columns(
    show: list[str], rows: list[dict], kinds: dict[str, str], sort_key: str, wide: bool, split: bool = False
) -> list[str]:
    """The metric columns the text table has room for, in the order they matter: the ranking metric and the quality
    metrics of its family (its first word: a judged table's `judge_score_…` and each judge's `judge_<id>_…`), the
    cost and the speed the frontier reads, the other quality metrics, then the rest. The first always stays, and so
    does each judge of a judged table."""
    if wide:
        return show
    family = sort_key.split("_", 1)[0] + "_"
    first = [k for k in show if k == sort_key]
    first += [
        k for k in show if k != sort_key and k.startswith(family) and kinds.get(k, "quality") == "quality"
    ]
    frontier = [
        next((k for k in show if kinds.get(k) == "cost" and k.startswith("total_")), None)
        or next((k for k in show if kinds.get(k) == "cost"), None),
        next((k for k in show if kinds.get(k) == "speed"), None),
    ]
    order = first + [k for k in frontier if k and k not in first]
    order += [k for k in show if kinds.get(k, "quality") == "quality" and k not in order]
    order += [k for k in show if k not in order]
    arm_w = max(len(r["system_id"]) + 2 for r in rows) + 2
    used = 2 + arm_w + 1 + 4 + 2
    keep: set[str] = set()
    # A judged table's judges are the evidence of its ranking: they stay on a terminal too narrow for them, the cost
    # and speed columns going first.
    must = set(first) if family == "judge_" else set(first[:1])
    for k in order:
        cw = max(*map(len, _head(k, split)), *(len(_cell(r.get(k), kinds.get(k))) for r in rows)) + 2
        if used + cw > _terminal_width() and keep and k not in must:
            break
        used, keep = used + cw, keep | {k}
    return [k for k in show if k in keep]


def _frontier(rows: list[dict], quality: str, kinds: dict[str, str], asc: bool = False) -> dict | None:
    """Which arms are on the menu at all, across quality, cost and speed together.

    An arm is DOMINATED when some other arm is at least as good on quality AND costs no
    more AND is no slower. A dominated arm is off the table whatever your budget is --
    there is simply a better version of the same trade. What is left is the real choice.

    The frontier is only as meaningful as the quality metric handed to it: computed on a
    length-sensitive facet it ranks verbosity, and swapping that facet for its opposite
    produced a completely different frontier once -- with the same runs. So the facet is
    named in the output, every time.

    Returns what it printed as numbers, or None when it printed no frontier.
    """
    if not rows:
        return None
    # Every row's keys, not the first row's: an arm with no latency (a rule) heads the table at times.
    seen = {k for r in rows for k in r}
    cost = next((k for k in sorted(seen) if kinds.get(k) == "cost" and k.startswith("total_")), None)
    cost = cost or next((k for k in sorted(seen) if kinds.get(k) == "cost"), None)
    speed = next((k for k in sorted(seen) if kinds.get(k) == "speed"), None)
    if not (cost and speed):
        print("\n  No frontier: needs a cost and a speed metric alongside quality.")
        return None
    pts: dict[str, tuple] = {r["system_id"]: (r.get(quality), r.get(cost), r.get(speed)) for r in rows}
    pts = {a: v for a, v in pts.items() if None not in v}
    if len(pts) < 2:
        return None

    def dominators(a: str) -> list[str]:
        """The arms at least as good as `a` on all three and different from it: so better on at least one. A tie
        on an axis is not worse; two arms identical on all three dominate neither."""
        qa, ca, la = pts[a]
        return [
            b
            for b, (qb, cb, lb) in pts.items()
            if b != a
            and (qb <= qa if asc else qb >= qa)
            and cb <= ca
            and lb <= la
            and (qb, -cb, -lb) != (qa, -ca, -la)
        ]

    front = sorted((a for a in pts if not dominators(a)), key=lambda a: pts[a][0] if asc else -pts[a][0])
    beaten = sorted(a for a in pts if dominators(a))
    # Dominance is transitive, so every dominated arm has a dominator on the frontier: name the best of them.
    by = {a: next(b for b in front if b in dominators(a)) for a in beaten}
    w = max(len(a) for a in pts) + 2
    print(f"\n  FRONTIER on {quality} / {cost} / {speed} — {len(front)} of {len(pts)} arms")
    if not _jsonout.table(["arm", "quality", "cost", "speed"], [[a, *pts[a]] for a in front]):
        print(f"    {'arm':{w}} {quality:>12} {cost:>12} {speed:>12}")
        for a in front:
            q, c, lat = pts[a]
            print(f"    {a:{w}} {q:12.6f} {c:12.6f} {lat:12.1f}")
    if beaten:
        print(
            _wrap(
                "dominated (another arm is as good on all three and better on at least one): "
                + ", ".join(f"{a} (by {by[a]})" for a in beaten),
                4,
            )
        )
    return {
        "quality": quality,
        "cost": cost,
        "speed": speed,
        "arms": len(pts),
        "frontier": front,
        "dominated": beaten,
        "dominated_by": by,
    }


def _metric_kinds(by_config: dict[str, list[dict]]) -> dict[str, str]:
    """{metric: kind} for these runs: what they recorded, overridden by what their adapters
    declare today; a disagreement no adapter settles is printed as a warning."""
    # An adapter may declare what ITS metrics mean; runs carry the declaration. Without
    # this the sort key falls to whatever sorts first among the unclassified, which ranked
    # a ten-model sweep by `compression` — a length ratio — and called it quality.
    declared: dict[str, str] = {}
    disagree: dict[str, set] = {}
    for runs in by_config.values():
        for r in runs:
            for k, v in (r.get("metric_kinds") or {}).items():
                if k in declared and declared[k] != v:
                    disagree.setdefault(k, {declared[k]}).add(v)
                declared[k] = v

    # THE ADAPTER'S CURRENT DECLARATION WINS OVER THE RUNS'. A run freezes the metric
    # kinds that were declared when it was measured, and this used to merge those and
    # stop -- so fixing a misdeclared metric in the adapter changed nothing on any
    # leaderboard built from runs that predate the fix. `llm_named_unknown` counts
    # document ids a reranker INVENTED; undeclared, it landed in the quality columns
    # where higher reads as better, so an arm that hallucinated more looked improved.
    # It was corrected in the adapter and kept showing as quality here, because the runs
    # measured before the fix carry the old declaration.
    #
    # The runs remain the fallback for an adapter that cannot be imported (a missing
    # dependency, a moved file), which is why they are read first and overridden second
    # rather than skipped.
    for runs in by_config.values():
        for r in runs:
            current = recorded_metric_kinds(r.get("adapter"))
            for k, v in (current or {}).items():
                if k in declared and declared[k] != v:
                    disagree.pop(k, None)  # the adapter settles it; not a conflict
                declared[k] = v

    # Two runs of the same metric declaring different kinds is a real disagreement and
    # used to be resolved by dict ordering -- silently, by whichever run happened to be
    # read last. Say so instead.
    for k, vs in sorted(disagree.items()):
        print(
            f"  WARNING: runs disagree on metric kind for {k!r}: {sorted(vs)} — "
            f"no adapter could be imported to settle it"
        )
    return declared


def body(
    dataset: str,
    sort: str | None = None,
    asc: bool = False,
    desc: bool = False,
    match: str | None = None,
    label: str | None = None,
    round: str | None = None,
    goal: str | None = None,
    wide: bool = False,
) -> int:
    """Generate a leaderboard from run results."""
    # A dataset accumulates arms across system VERSIONS -- v1 and v2 of the same arm are
    # different measurements and must not share a row, but they do share a dataset. Without
    # a way to scope the table (`match`), the only ways to get a readable leaderboard are to delete
    # the older runs or to read past them. Deleting paid-for results to tidy a table is how
    # 18 arms were lost once; this is the alternative.
    return _run(
        argparse.Namespace(
            dataset_id=dataset,
            sort=sort,
            asc=asc,
            desc=desc,
            match=match,
            label=label,
            round=round,
            goal=goal,
            wide=wide,
        )
    )


def _goal_read(args: argparse.Namespace, A) -> tuple[dict | None, set[str] | None]:
    """(the goal that reads the dataset, the arms it is limited to): `--goal`, else the goal naming the dataset (the
    first, when several do), else none, when the dataset is read on each arm's own headline; with `--round`, the
    round's goal and the arms the round compared, under their labels (its evidence)."""
    goals = A.goals()
    if args.round:
        from evaluation_harness._rounds import resolve  # noqa: PLC0415
        from evaluation_harness.model import rounds as model_rounds  # noqa: PLC0415

        rnd = resolve(args.round, args.goal)
        goal = next((g for g in goals if g["goal_id"] == rnd["goal"]), None)
        return goal, set(model_rounds.evidence(rnd["goal"], rnd, A)["arms"])
    named = [g for g in goals if any(d.get("dataset_id") == args.dataset_id for d in g.get("datasets") or [])]
    if args.goal:
        goal = next((g for g in goals if g["goal_id"] == args.goal), None)
        if goal is None:
            die(
                f"no goal {args.goal!r}: one of {', '.join(g['goal_id'] for g in goals) or '(none)'}",
                "not-found",
            )
        if goal not in named:
            die(f"goal {args.goal} does not name dataset {args.dataset_id!r}", "bad-argument")
        return goal, None
    if len(named) > 1:
        print(
            f"  NOTE: {len(named)} goals name this dataset; read as {named[0]['goal_id']} "
            f"(--goal: {', '.join(g['goal_id'] for g in named)})."
        )
    return (named[0] if named else None), None


def _name(row: dict, label: str | None) -> str:
    """The arm's name in a table: its system, and the label it is read under unless the table is of that label."""
    cid = row["arm"].rsplit("/", 1)[-1]
    return cid if label is not None or not row["read_as"] else f"{cid} · {row['read_as']}"


def _runs_of(A, row: dict, dataset: str) -> list:
    """The arm's runs with their records: the score directories the adapter read it from."""
    from evaluation_harness.model import runs as model_runs  # noqa: PLC0415

    dirs = getattr(A, "_dirs", None)
    if callable(dirs):
        return [(d, m) for d in dirs(row["arm"]) if (m := model_runs.record(d))]
    return runs_on(dataset, label=row["read_as"], system_id=row["arm"].rsplit("/", 1)[-1])


def _run(args: argparse.Namespace) -> int:
    # The goal view says which arms are in which table, what flags them and which leads; each arm's runs, with their
    # directories, stay what the significance test reads its per-item scores from (a PAIRED comparison throws away
    # nothing: every arm was graded on the same items).
    from evaluation_harness.catalog_adapter import load_catalog_adapter, scores_once  # noqa: PLC0415
    from evaluation_harness.model import goal_views  # noqa: PLC0415

    ds = args.dataset_id
    A = scores_once(load_catalog_adapter(None))
    goal, keep = _goal_read(args, A)
    by_ds = goal_views.by_dataset(A, {ds})
    # ONE TABLE PER REFERENCE. Runs scored against silver and against gold were averaged into
    # one row and one ranking (0.90 silver beside 0.24 gold, the table labelled silver): two
    # different measurements read as one. Each reference gets its own table and its own tests;
    # nothing is averaged across them. An arm is read against the reference of its latest run.
    groups: dict[str, dict] = {}
    for grp in goal_views.dataset_groups(A, by_ds, ds, goal):
        rows = [
            r
            for r in grp["rows"]
            if (args.label is None or r["read_as"] == args.label)
            and (not args.match or args.match in r["arm"].rsplit("/", 1)[-1])
            and (keep is None or r["arm"] in keep)
        ]
        if rows:
            groups[grp["key"]] = {**grp, "rows": rows}
    if not groups:
        arms = (by_ds.get(ds) or {}).get("arms")
        measure = ((goal or {}).get("success_criteria") or {}).get("primary", {}).get("measure")
        die(
            (
                f"no arm on dataset {ds!r} records {measure}, which goal {goal['goal_id']} reads"
                if goal and arms and args.label is None and not args.match and keep is None
                else f"no runs on dataset {ds!r}"
                + (f" matching {args.match!r}" if args.match else "")
                + (f" read as {args.label!r}" if args.label else "")
                + (f" in round {args.round}" if args.round else "")
                + ".\n  "
                + how("evh runs-list", "make runs-list")
                + "   to see what exists"
            ),
            "not-found",
        )
    rank = {"gold": 0, "silver": 1, "judge": 3}
    order = sorted(
        groups, key=lambda k: (rank.get(k.split("/")[0].split(" ")[0], 2), "" if k == "no reference" else k)
    )
    if len(order) > 1:
        what = ", ".join(_heading(r) for r in order)
        print(
            f"  NOTE: these runs are scored {len(order)} different ways ({what});\n"
            "        one table for each, never averaged across them.\n"
        )
    out = []
    for n, key in enumerate(order):
        if len(order) > 1:
            print(("\n" if n else "") + f"=== {_heading(key)} ===")
        out.append(
            {
                "reference": None if key == "no reference" else key,
                "heading": _heading(key),
                **_table(args, A, groups[key], goal),
            }
        )
    _jsonout.values({"dataset_id": ds, "goal": goal["goal_id"] if goal else None, "groups": out})
    return 0


def _judging_summary(found: list, data=None) -> None:
    """The judging pass's own checks (its summary, data/judge-summaries/<judge scorer>@<judging set>.json, named by
    the judged score's key): how far the judges agree, and how much a verdict moves with the order of the
    outputs (position) and when the same call is repeated (noise). Read them before the ranking. `data`: the
    data directory they are read from (the adapter's), else the project's."""
    seen = set()
    for d, _m in found:
        f = (data or _common.DATA) / "judge-summaries" / f"{d.name}.json"
        if f in seen or not _store.is_file(f):
            continue
        seen.add(f)
        s = read_json(f)
        print(
            f"\n  The judging pass ({d.name.split('@', 1)[0]}, {s.get('items_scored')}/{s.get('items_total')} items, "
            f"{s.get('label', '')}), from data/judge-summaries:"
        )

        def num(v: object) -> str:
            # A check that did not run (no items in its subset), or a value it could not compute.
            return f"{v:.3f}" if isinstance(v, (int, float)) else "—"

        for pair, a in (s.get("judge_agreement") or {}).items():
            print(
                f"    judges {pair.replace('~', ' and ')} agree: item tau {num(a.get('mean_item_tau'))}, "
                f"arm order spearman {num(a.get('arm_mean_spearman'))}"
            )
        for j, c in (s.get("controls") or {}).items():
            pos, noi = c.get("position") or {}, c.get("noise") or {}
            print(
                f"    {j}: reshuffled outputs tau {num(pos.get('mean_tau'))} (position), "
                f"the same call repeated tau {num(noi.get('mean_tau'))} (noise)"
            )


def _heading(ref: str | None) -> str:
    if ref and ref.startswith("judge "):
        return f"scored by {ref}"
    return f"scored against {ref or 'no reference'}"


def _warn_ambiguous(by_config: dict[str, list[dict]]) -> None:
    """Say loudly when the runs averaged into one row are not one `--repeat` set: two runs of an arm read against the
    same reference that nothing says apart (a run another reference scored is not in the row)."""
    for name, runs in by_config.items():
        ids = sorted(m["run_id"] for m in runs)
        if len(ids) > 1 and not is_repeat_set(ids):
            print(f"  WARNING: {len(ids)} runs claim system_id {name!r} — {', '.join(ids)}.")
            print(AMBIGUOUS_HOW)


def _table(args: argparse.Namespace, A, group: dict, goal: dict | None) -> dict:
    """The leaderboard over the arms of one group (the goal view's, scored against one reference); what it printed, as
    numbers."""
    view = {_name(r, args.label): r for r in group["rows"]}
    arm_runs = {n: _runs_of(A, r, args.dataset_id) for n, r in sorted(view.items())}
    by_config: dict[str, list[dict]] = {n: [m for _d, m in rs] for n, rs in arm_runs.items() if rs}
    found = [x for n, rs in arm_runs.items() if n in by_config for x in rs]
    dec = group.get("dec")
    goal_id = goal["goal_id"] if goal else ""

    _warn_ambiguous(by_config)
    if not by_config:
        die(
            f"no runs on dataset {args.dataset_id!r}"
            + (f" matching {args.match!r}" if args.match else "")
            + ".\n  "
            + how("evh runs-list", "make runs-list")
            + "   to see what exists",
            "not-found",
        )

    all_keys = sorted(
        {
            k
            for runs in by_config.values()
            for r in runs
            for k in r["scores"]
            if not k.startswith(BOOKKEEPING_PREFIXES)
        }
    )
    declared = _metric_kinds(by_config)

    kinds = classify_metrics(declared)
    quality = [k for k in all_keys if kinds.get(k, "quality") == "quality" and not k.startswith("total_")]
    descriptive = [k for k in all_keys if kinds.get(k) == "descriptive"]
    # The adapter's declared headline facet wins over alphabetical order. Explicit
    # --sort still overrides both.
    primary = next(
        (
            r.get("primary_metric")
            for runs in by_config.values()
            for r in runs
            if r.get("primary_metric") in all_keys
        ),
        None,
    )
    measure = group.get("measure") if goal else None  # what the goal reads the group on
    sort_key = (
        args.sort
        or (measure if measure in all_keys else None)
        or primary
        or (quality[0] if quality else (descriptive[0] if descriptive else all_keys[0]))
    )
    asc = direction(found, sort_key, args.asc, args.desc)
    # SAY SO when the headline metric was picked alphabetically. Runs written before
    # adapters declared PRIMARY_METRIC carry none, so this falls through to whichever
    # quality metric sorts first by name -- for one set of runs here that is `grounding`,
    # an extractiveness measure, silently promoted to the ranking metric.
    if not args.sort and not primary and measure not in all_keys:
        print(
            f"  NOTE: no run declares a primary metric, so {sort_key!r} was chosen by\n"
            f"        sort order, not by meaning. Pass --sort explicitly, or re-run with\n"
            f"        an adapter that sets PRIMARY_METRIC."
        )
    # SAY SO when the table mixes system versions. v1 and v2 of one arm are different
    # measurements -- often different scorers -- and listing them side by side reads as
    # 48 models. The fix is to scope the view, never to delete the older runs. Only an arm
    # present at two versions is a mix; different arms at different versions are not.
    # A round that holds two versions of an arm exists to compare them: no warning there.
    mixed = {} if args.round else mixed_versions({r["arm"].rsplit("/", 1)[-1] for r in view.values()})
    if mixed:
        print(
            "  NOTE: this table has more than one version of "
            + ", ".join(f"{b} ({' and '.join(v)})" for b, v in mixed.items())
            + ".\n        Those are different measurements, not repeats. Scope with --match <version>."
        )
    ranking_on_descriptive = kinds.get(sort_key) == "descriptive"
    if sort_key not in all_keys:
        die(f"no metric {sort_key!r} on these runs. Available: {', '.join(all_keys)}", "not-found")

    rows: list[dict] = []
    for system_id, runs in by_config.items():
        # EVERY run's tier, not runs[0]'s. Taking the first one meant a system whose
        # earliest run predated the reference (reference_tier: None) suppressed the
        # SILVER warning below — while the quality column on that very row came only
        # from the silver-scored runs. A model-generated number, printed as if it were
        # ground truth, which is the one thing this table must never do.
        tiers: set[str] = {r["reference_tier"] for r in runs if r.get("reference_tier")}
        row = {
            "system_id": system_id,
            "n_runs": len(runs),
            "tier": "+".join(sorted(tiers)) if tiers else "—",
            "tiers": tiers,
        }
        for k in all_keys:
            vals = [r["scores"][k] for r in runs if k in r["scores"]]
            if vals:
                row[k] = statistics.fmean(vals)
                row[f"__spread_{k}"] = max(vals) - min(vals)
        rows.append(row)

    rows.sort(key=lambda r: r.get(sort_key, float("inf") if asc else float("-inf")), reverse=not asc)

    show = quality + descriptive + [k for k in all_keys if kinds.get(k) in ("cost", "speed")]
    show = [k for k in show if k in all_keys]
    # The text table fits the terminal; the JSON table carries every column in `show`.
    text_cols = _fit_columns(show, rows, kinds, sort_key, args.wide)
    split = False
    if len(text_cols) < len(show) and any(k.endswith(UNVALIDATED) for k in show):
        tighter = _fit_columns(show, rows, kinds, sort_key, args.wide, split=True)
        if len(tighter) > len(text_cols):
            text_cols, split = tighter, True
    own = {n: view[n]["reference"] for n in by_config if view[n]["wrote"]}
    w = max(len(r["system_id"]) + (2 if r["system_id"] in own else 0) for r in rows) + 2
    print(f"dataset: {args.dataset_id}   ranked by: {sort_key} ({'lower' if asc else 'higher'} is better)\n")
    if not _jsonout.table(
        ["system_id", "n_runs", "tier", *show],
        [[r["system_id"], r["n_runs"], r["tier"], *[r.get(k) for k in show]] for r in rows],
    ):
        cells = {k: [_cell(r.get(k), kinds.get(k)) for r in rows] for k in text_cols}
        cw = {k: max(*map(len, _head(k, split)), *(len(c) for c in cells[k])) for k in text_cols}
        judged_table = any((v["read_as"] or "").startswith("judged/") for v in view.values())
        shown_runs = [
            runs_cell(
                r["n_runs"],
                len(
                    runs_on(
                        args.dataset_id, label="", system_id=view[r["system_id"]]["arm"].rsplit("/", 1)[-1]
                    )
                ),
            )
            if judged_table
            else str(r["n_runs"])
            for r in rows
        ]
        rw = max(4, *map(len, shown_runs))
        header = f"  {'arm':{w}} {'runs':>{rw}}  " + "  ".join(
            f"{_head(k, split)[0]:>{cw[k]}}" for k in text_cols
        )
        print(header)
        if split:
            print(
                (
                    f"  {'':{w}} {'':>{rw}}  "
                    + "  ".join(f"{_head(k, split)[1]:>{cw[k]}}" for k in text_cols)
                ).rstrip()
            )
        print("  " + "-" * (len(header) - 2))
        for i, r in enumerate(rows):
            line = "  ".join(f"{cells[k][i]:>{cw[k]}}" for k in text_cols)
            name = r["system_id"] + (" *" if r["system_id"] in own else "")
            print(f"  {name:{w}} {shown_runs[i]:>{rw}}  {line}")
        note = runs_note(r["read_as"] for r in view.values())
        if note:
            print("\n" + _wrap(note, 2))
        if len(text_cols) < len(show):
            left = [k for k in show if k not in text_cols]
            print(
                "\n"
                + _wrap(
                    f"Not shown ({len(left)}, the terminal is {_terminal_width()} wide): {', '.join(left)}.",
                    2,
                )
                + "\n  All of them: --wide, or --json."
            )
    if dec:
        nm = {r["arm"]: n for n, r in view.items()}
        lead, rec = dec["leader"], dec["recommended"]
        say = lambda a: nm.get(a) or a.rsplit("/", 1)[-1]  # noqa: E731
        print(
            "\n"
            + _wrap(
                f"goal {goal_id}: leader {say(lead) if lead else 'none'}"
                + (
                    f", recommended {say(rec)}"
                    if rec
                    else ", shown, not recommended"
                    if dec.get("shown_only")
                    else ""
                ),
                2,
            )
        )
        # Why, as the goal page says it: a recommendation printed under "NO detectable arm effect" read as a
        # contradiction (the 0.8.0 newcomer run) until the reasons said no contender was shown within the margin.
        for w in dec.get("why") or []:
            print(_wrap(w, 4))
    # A run scored against references for only some of its items: its quality mean is over those.
    partial = {
        cid: (r["reference_coverage"]["items_with_reference"], r["reference_coverage"]["items"])
        for cid, runs in by_config.items()
        for r in runs
        if r.get("reference_coverage")
    }
    for cid, (k, n) in sorted(partial.items()):
        print(
            f"\n  NOTE: {cid} had a reference for {k} of {n} items: its quality columns are means over {k}."
        )
    for system_id, ref in sorted(own.items()):
        print(
            f"\n  * {system_id} wrote the reference {ref}: it is graded against its own outputs,\n"
            "    so its row measures agreement with itself, not quality. Compare the others to it."
        )

    if ranking_on_descriptive:
        print(
            f"\n  RANKED ON A DESCRIPTIVE METRIC ({sort_key}) — it measures what the output\n"
            "  WAS, not whether it was good, so this ordering rewards verbosity. Author\n"
            f"  references (labels you promote: evh reference-promote) so runs carry a quality score, or pass\n"
            "  --sort <metric> explicitly."
        )

    # The arm that wrote the reference is graded against its own outputs: it is listed, but it
    # is not a contender, so the ordering test and the frontier are over the others.
    contenders = {n: rs for n, rs in arm_runs.items() if n in by_config and n not in own}
    if own:
        print(
            f"\n  The ordering test and the frontier leave out {', '.join(sorted(own))} (it wrote the reference)."
        )
    raw: list[float] = []
    matrix = {n: items for n, rs in contenders.items() if (items := per_item(rs, sort_key, raw=raw))}
    ordering = significance(matrix, sort_key, asc=asc, raw_values=raw) if matrix else None
    frontier = _frontier([r for r in rows if r["system_id"] not in own], sort_key, kinds, asc=asc)
    judged = sorted(
        {
            f"{derived_with(r, 'judge').get('scorer_id')}, {derived_with(r, 'judge').get('label')}"
            for runs in by_config.values()
            for r in runs
            if derived_with(r, "judge").get("label")
        }
    )
    if judged:
        print(
            f"\n  Scored by an LLM judge, not against references: {'; '.join(judged)}.\n"
            "  A judge's score is only as good as its validation; an unvalidated one is a\n"
            "  trial run, not a measurement."
        )
        _judging_summary(found, getattr(A, "data_dir", None))
    if any("silver" in r["tiers"] for r in rows):
        print(
            "\n  Scored against SILVER references (consistent, not correct). Good for ranking\n"
            "  these arms against each other; not a claim that any of them is correct."
        )
    if not any(kinds.get(k) == "cost" for k in show):
        print(
            "\n  No cost recorded. Add usd_per_mtok_in / usd_per_mtok_out to the systems\n"
            "  so the ranking can weigh quality against price."
        )
    return {
        "sort_by": sort_key,
        "direction": "lower" if asc else "higher",
        "ranked_on_descriptive": ranking_on_descriptive,
        "metrics": show,
        "kinds": {k: kinds.get(k) for k in show},
        "arms": [
            {
                "rank": i,
                "system_id": view[r["system_id"]]["arm"].rsplit("/", 1)[-1],
                "arm": view[r["system_id"]]["arm"],
                "n_runs": r["n_runs"],
                "tier": r["tier"],
                "flags": view[r["system_id"]]["flags"],
                "wrote_reference": own.get(r["system_id"]),
                "metrics": {k: r[k] for k in show if k in r},
                "spread": {k: r[f"__spread_{k}"] for k in show if f"__spread_{k}" in r},
            }
            for i, r in enumerate(rows, 1)
        ],
        "decision": {
            "goal": goal_id,
            **{k: dec.get(k) for k in ("leader", "contenders", "recommended")},
            "shown_only": bool(dec.get("shown_only")),
        }
        if dec
        else None,
        "ordering": ordering,
        "frontier": frontier,
        "mixed_versions": mixed,
        "partial_reference": {
            cid: {"with_reference": k, "items": n} for cid, (k, n) in sorted(partial.items())
        },
        "silver": any("silver" in r["tiers"] for r in rows),
        "judged": judged,
    }
