# Working in this project: for an agent

This project measures a system with **eval-harness** (the `evh` command): it freezes a dataset,
runs one or more versions of the system on it ("arms"), scores every output against a
reference, and tests whether one arm is really better than another. `evh init` wrote this file;
edit it to add what is particular to this project.

Everything you need runs in a shell. **You do not need the catalog** (`evh catalog`,
`evh catalog-serve`: HTML pages for a person) **or `evh mcp`** (the same read commands as MCP
tools, for an agent without a shell, or for a team). Every page and every tool is also a
command; read them with `--json`.

The procedures are skills: `evh skills-install` copies them into `.claude/skills/` (or
`--target` any agent's skill directory): `evh-evaluate-a-system` (from nothing to a decision),
`evh-compare-and-read` (which arm leads, and whether it is real), `evh-promote-with-evidence`
(recording the choice). This file holds the rules they follow.

## The rules

1. **Frozen means frozen.** Never edit or delete anything under `data/datasets/`, `data/runs/`, `data/judge-summaries/`,
   `data/labels/`, `data/references/` or `data/baselines/`. A change is a new id: a dataset
   `_v2`, a new label set, a new reference.
2. **One change, one new `system_id`.** A system is a file in `data/systems/`, named by its
   `system_id`; a run puts it on a dataset (`evh run --system S --dataset D`). To try a change (a
   prompt, a model, a setting), copy the system and give it a new `system_id`; never edit a system
   that has runs. Running the same system again is `evh run --repeat N` or `--purpose repeat --of RUN_ID`, a deliberate repeat; any
   other second run of a system on the same dataset fails `evh validate` (V8).
3. **Commit before you run.** A run records the commit it was made from; a run from a dirty tree
   is refused later (`label-from-run`, `run-promote`). Commit `data/` as the harness writes it,
   runs included: they are the evidence. `.gitignore` already keeps out what is derived.
4. **Spending is capped, and checked first.** Before any run that calls a paid model, set
   `EVAL_MAX_COST_USD` (with none, a run has no cap). `evh run --system S --dataset D --dry-run`
   estimates one call per item and is not an upper bound: a system that makes several calls per item
   costs more. Run `evh arm-smoke --system S --dataset D` (a few items), read the replies, and set the
   cap from the
   measured cost it records (the dry run then shows it as `MEASURED`) before the full run.
5. **What you may do:** run arms, make labels and
   references, and promote a baseline **when your operator asked for that task**, within the
   cap. A promotion's `--reason` says who asked and why. Closing a round, and anything past the
   cap, stay your operator's: hand over the exact command. **Name yourself and your operator**:
   `export EVH_ACTOR=agent:<your name> EVH_FOR=person:<your operator>`. Every record you write
   then says an agent made it, for whom; without them, off a terminal, a promotion is refused.
6. **Labels say who made them.** `evh label-import` records a set as **a person's**: never use it
   for labels you made. Your labels go in a sheet read back with
   `evh sheet-import --kind model`; outcomes your system's production recorded become labels
   with `evh label-from-capture` (rules over the outcomes). Gold is a person's labels: the
   harness records each set's source but does not stop you, so never promote your own labels
   at gold (silver is for those).
7. **Validate, then report with evidence.** `evh validate` checks the whole tree. A claim that
   one arm is better cites the paired test that says so (`evh pair-test`, `evh goal-list`), not a
   mean.
8. **Name the comparison before the run.** Write a `hypothesis:` into the new system
   (`against`, `measure`, `direction`, `statement`) and commit it before `evh run`. `evh pair-test`
   then reports "named in advance: yes"; a pair you chose after reading the table is a search, and
   `evh family-test` is its test.

## From nothing to a decision

```bash
evh init --store files|sqlite                   # done: folders, config.yaml, .gitignore, AGENTS.md, CLAUDE.md, data/project.yaml, prompts/judge_prompt_example.txt
# production records -> a dataset (or files: evh dataset-create --dataset-id D --source-dir data/sources/NAME)
evh capture --importer jsonl --query '{"path": "prod.jsonl"}' --capture prod_c1
evh dataset-from-capture --capture prod_c1 --dataset-id prod_v1
evh dataset-materialize --dataset-id prod_v1
# what is right for each item: a person's labels (gold), production's outcomes, or yours (model)
evh label-from-capture --dataset-id prod_v1 --capture prod_c1 --map rules.yaml --set outcomes
evh reference-promote --dataset-id prod_v1 --labels outcomes --tier silver --reason "..." --by "<who>"
# systems: one per version of what you evaluate (data/systems/<system_id>.yaml), your adapter if it is yours
git add -A && git commit -m "dataset, reference, systems"
evh run --system <system_id> --dataset prod_v1 --dry-run
evh arm-smoke --system <system_id> --dataset prod_v1
evh run --system <system_id> --dataset prod_v1  # prints the run id it wrote
git add -A && git commit -m "runs"
# compare and decide
evh leaderboard prod_v1 --json
evh pair-test prod_v1 --a <new_system_id> --b <baseline_system_id> --json
evh run-promote --run <run_id> --reason "<who asked>: <why>"
```

A goal (`data/goals/<goal_id>.yaml`) says what the evaluation is for and which measure decides; a
run names it (`evh run ... --goal <goal_id>`), and `evh goal-leaderboard <goal_id> --json` gives the leader, the baseline, the paired test
and what the goal recommends, in one answer.

Rounds are optional: a round is one line of investigation of a goal, with its hypothesis, its arms,
the ones retired and a conclusion (`evh round-open`, `evh round-retire`, `evh round-evidence G R --json`
for what the evidence suggests next). Open the round **before** its systems run: a new one runs in it
(`evh run ... --goal G --round rN`); one already run joins only through `round-open --keep SYSTEM_ID`.
Closing it is your operator's (rule 5).

## Reading results

| question | command |
| --- | --- |
| what is in the project | `evh overview-show --json`, `evh dataset-list --json`, `evh arm-list --json` |
| which arm leads, and is it significant | `evh goal-leaderboard G --json`; `evh leaderboard D --json` |
| is A better than B | `evh pair-test D --a A --b B --json` |
| one arm against several, corrected | `evh family-test D --a A --against B,C --json` (`--against`: a comma list of system ids, or one substring) |
| where two arms differ, item by item | `evh comparison-show --runs A,B --json` |
| what two runs did differently | `evh run-compare --baseline RUN_A --candidate RUN_B --json` |
| is the tree consistent | `evh validate` |

## When a command stops

Read the exit code and, on a refusal, the kind in `ERROR (<kind>): <why>`, not the wording:

| exit | what to do |
| --- | --- |
| `1` `not-found` | check the id: `evh dataset-list`, `evh arm-list`, `evh goal-list`, `evh runs-list` list them |
| `1` `not-materialized` | `evh dataset-materialize --dataset-id D`, then the same command again |
| `1` `not-configured` | `evh env-check` says which key, cap or build ref is missing |
| `1` `not-allowed` | a rule refuses it (a dirty tree: commit first; a closed round): fix that, or hand it to your operator |
| `2` | a flag is wrong: the command's own `--help` lists them |
| `4` | the cost cap stopped it; the partial results are kept: ask before raising the cap, then run the same command again |
| `6` | the checks ran and some failed: the output lists them |
| `75` | a server could not be reached: run the same command again later, it resumes |

Every kind and code: the Runbook's "Refusals" and "Exit codes".

Every command takes `--help`: it is the reference for every flag. The full documentation:
https://evals.humancopilot.eu/docs/ (start at "Getting started"; "Integration" for your own
system; "Runbook" for every command).
