"""Re-score finished runs from their stored outputs. No API calls, no money.

The outputs are the expensive part of a run; the scores are arithmetic over them. But
scores were only ever computed at run time, so every change to a metric meant re-running
the whole sweep — ~$1.45 and 80 minutes to answer "what would this look like under a
different measure". That is backwards, and it is why a scorer bug survived two sweeps:
checking it would have cost another one.

    evh rescore --dataset-id my_v1 [--match _v2]
    evh rescore --goal my_goal --round r1 --why "what changed in the scoring, and why"

A re-score is a SCORE under the run it re-reads (data/runs/<run>/scores/<scorer>@<reference>/), never over the
first one. Two reasons: that first score is the record of what was actually measured and paid for, and a re-score
read in the same arm as its source would average two different metrics into one row, so it is read under a label of
its own (default "rescored <8 characters of the scorer>", "silver" against a silver reference, --label to choose)
which the catalog, the goals and the rounds read in place of the runs it re-read. A scorer that has already scored
a run against the same reference with the same rows is not written again.

What is recomputed: everything `score()` returns. What is carried across untouched:
latency, cost, token counts and the raw provider `_meta` — those are properties of the
call that happened, not of how it was later measured, and re-deriving them would be
inventing them.
"""

from __future__ import annotations

import inspect
import json
import sys
import textwrap
from pathlib import Path
from typing import Any

from evaluation_harness import _jsonout, _outputs, _progress, _runs, _store
from evaluation_harness._adapter import load_recorded_adapter, score_wants_source
from evaluation_harness._common import (
    DATA,
    DATASETS,
    LABELS_PREFIX,
    LABELS_TIER,
    MATERIALIZED,
    REFERENCES,
    ROOT,
    adapter_search_dirs,
    dataset_id_ok,
    die,
    how,
    labels_reference,
    now,
    read_json,
    scored_against_dir,
)
from evaluation_harness._fingerprint import references_digest, seal
from evaluation_harness._record import (
    aggregate_scores,
    cut_off_items,
    derived_record,
    empty_at_cap_note,
    run_level_scores,
    run_scorer,
)
from evaluation_harness.model import datasets as _datasets
from evaluation_harness.model import runs as _model_runs
from evaluation_harness.ops import legacy

#: Carried across from the original run rather than recomputed: these describe the CALL,
#: not the measurement. A rescore that recomputed a latency would be reporting a number
#: no clock ever produced.
#:
#: This is a FLOOR, not the whole list. Anything else the original row carried that the
#: new scorer does not produce is carried too — `truncated` and `reasoning_tokens` come
#: from the adapter's `Result.extra` at call time and are unrecoverable afterwards, and a
#: fixed list silently dropped them on the first run of this script.
# `resumed` records whether the item was replayed from a stopped run, `failed` whether its call failed (A5): facts
# about the call, not scores.
CARRY = ("latency_ms", "tokens_in", "tokens_out", "cost_usd", "resumed", "failed")


def _item_sources(dataset_id: str) -> dict[str, str]:
    """{item_id: source_path} from the dataset file.

    THE DATASET KNOWS EACH ITEM'S FILENAME. PREDICTION ROWS DO NOT. `source_path` was read
    off the stored prediction row, and no prediction row has ever carried one (0 of 20,001
    rows across every committed run). `dataset_create.py` writes it into the DATASET, where
    `run`, `materialize`, `reference_promote` and `validate_tree` all read it, so
    the fallback `<item_id>.txt` fired every time, and on any dataset whose files are named
    otherwise the source text arrived as None: silently, because a scorer that wanted the
    source then measured nothing rather than failing."""
    ds_file = DATASETS / f"{dataset_id_ok(dataset_id)}.json"
    items = read_json(ds_file).get("items") or [] if _store.is_file(ds_file) else []
    return {it["item_id"]: it["source_path"] for it in items if it.get("item_id") and it.get("source_path")}


def _references_for(m: dict[str, Any], reference_id: str | None) -> tuple[Path | None, str | None]:
    """(the reference directory to score against, its tier): the run's own, or `--reference-id`.

    NEW REFERENCES, OLD OUTPUTS. The usual life of a golden dataset: runs are made against
    silver because nothing better exists, then a person writes or reviews gold. The outputs
    are the expensive part and do not change, so re-scoring them against gold is arithmetic,
    not a re-run. Without this the only way to a gold-scored leaderboard was to pay for
    every arm again."""
    if reference_id:
        tier = LABELS_TIER if reference_id.startswith(LABELS_PREFIX) else reference_id.split("/", 1)[0]
        return scored_against_dir(reference_id), tier
    recorded = ((m.get("fingerprint") or {}).get("data") or {}).get("reference_id")
    return scored_against_dir(recorded), m.get("reference_tier")


def _rescore_row(
    old: dict[str, Any],
    d: Path,
    ref_dir: Path | None,
    mat: Path,
    item_source: dict[str, str],
    score: Any,
    wants_source: bool,
    extra_keys: set[str],
    unscorable: Any = None,
) -> tuple[dict[str, Any], bool, bool]:
    """One stored prediction row, scored again from its stored output: (the new row, whether
    a reference was found for it, whether its cost was re-read from the bill)."""
    had_ref = False
    recosted = False
    item_id = old["item_id"]
    stored = _outputs.output(d, item_id)
    if stored is None:
        die(f"{_model_runs.run_of(d).name}: no stored output for {item_id} — cannot rescore", "not-enough")
    output = stored
    reference = None
    if ref_dir:
        rf = ref_dir / f"{item_id}.txt"
        if _store.is_file(rf):
            reference = _store.read_text(rf, encoding="utf-8", errors="replace")
            had_ref = True
    source_text = None
    # `source_path` is the dataset's own name for the file; it only happens to
    # equal "<item_id>.txt" here. Ignoring it means source_text is silently None
    # on any dataset that names files differently -- and a scorer that wanted the
    # source then measures nothing, quietly.
    rel = item_source.get(item_id) or old.get("source_path") or f"{item_id}.txt"
    for cand in (mat / rel, mat / f"{item_id}.txt", mat / item_id):
        if _store.is_file(cand):
            source_text = _store.read_text(cand, encoding="utf-8", errors="replace")
            break
    if unscorable is not None and unscorable(item_id, output):
        scored: dict[
            str, Any
        ] = {}  # RFC-031 L3: its label holds only under production's action, and this run's differs
    else:
        scored = score(output, reference, source_text) if wants_source else score(output, reference)
    row: dict[str, Any] = {"item_id": item_id, **scored}
    for k, v in old.items():
        if k == "item_id" or k in scored:
            continue
        # Carry ONLY things that describe the call. "Keep everything the new
        # scorer does not produce" was too generous: it carried the previous
        # scorer's metrics (`rouge2`, `rougeL`) into the rescored run, where the
        # leaderboard showed them as live quality columns beside the new ones.
        # A rescored run must not report a number the current scorer never
        # computed.
        # The row's own `_extra` names what the adapter attached at call time (any adapter's
        # extras, not only the examples' names): those describe the call too.
        if k in CARRY or k in extra_keys or k in (old.get("_extra") or {}) or k.startswith("_"):
            row[k] = v

    # ...EXCEPT THE PARTS OF `_meta` THE PARSER PRODUCED.
    #
    # The rule above is "carry only things that describe the call", and `_meta`
    # passes it on `k.startswith("_")` alone. But `_meta.predicted` is the
    # PARSER'S OUTPUT, not a property of the call, so a rescored run carried new
    # scores beside the old parse -- and `extraction_report.py` reads exactly
    # that field. §3.6's consensus analysis and the annotation bound were
    # computed on pre-fix parses for the four arms the round-4 parser fix moved:
    # `glm_l` reported 0.5269 against its own run's 0.5662, in BOTH trees,
    # because the stale field is identical in both.
    #
    # An adapter that stores parser output in `_meta` declares how to rebuild
    # it. One that does not is not asked to.
    _mod = inspect.getmodule(score)
    if _mod is not None and hasattr(_mod, "reparse_meta") and isinstance(row.get("_meta"), dict):
        try:
            fresh = _mod.reparse_meta(output)
        except Exception as exc:  # noqa: BLE001
            die(
                f"{_model_runs.run_of(d).name}: the adapter's reparse_meta() raised on item "
                f"{item_id}: {type(exc).__name__}: {exc}\n"
                f"  A rescored run must not carry a parse the current parser "
                f"did not produce, so this is a failure rather than a carry.",
                "failed",
            )
        if isinstance(fresh, dict):
            row["_meta"] = {**row["_meta"], **fresh}

    # COST IS RECOMPUTED FROM THE BILL, NOT CARRIED.
    #
    # `cost_usd` was carried verbatim, and for every run measured before the
    # adapters learned to prefer `usage.cost` that value is the PRICE TABLE --
    # tokens multiplied by the rate in the arm's yaml. The provider's actual
    # charge is sitting in the same row, in `_meta.usage.cost`, and the two
    # differ by 0.67x to 3.76x per arm and 1.25x over the whole repo
    # ($9.78 recorded against $12.28 billed). Every cost column, every
    # dollars-per-month figure and every cost-per-quality-point in the reports
    # is computed from the wrong one.
    #
    # An alias is not a price: a provider routes, discounts, caches and rounds.
    # The bill is the measurement; the price table was always the fallback for
    # when there is no bill, and it is kept as exactly that.
    billed = ((old.get("_meta") or {}).get("usage") or {}).get("cost")
    if billed is not None:
        try:
            row["cost_usd"] = round(float(billed), 10)
            if abs(float(billed) - float(old.get("cost_usd") or 0)) > 1e-9:
                recosted = True
        except (TypeError, ValueError):
            pass
    return row, had_ref, recosted


def _check_references(
    d: Path, m: dict[str, Any], ref_dir: Path | None, rows: list[dict[str, Any]], refs_found: int
) -> None:
    """Die when a declared reference set has none of its files here; warn when it has some."""
    # A MISSING REFERENCE SET MUST NOT SCORE. A missing OUTPUT calls die()
    # (_rescore_row); a missing REFERENCE used to fall through as None and the run scored
    # anyway. That asymmetry guarded the expensive artifact and left the free one
    # unchecked -- and the free one is exactly what a fresh clone lacks, because the
    # corpora are gitignored and rebuilt by each example's fetch.py.
    #
    # What that cost: rescoring fn_anthropic_l in a clone with no references produced
    # f1 = 0.1071 against the recorded 0.6798. Not an error, not a zero -- a
    # plausible number, arrived at because every prediction became a false positive
    # against an empty gold set. A reader could have published it.
    #
    # Zero found is always wrong when a reference_id is declared, so it dies. A
    # PARTIAL set is not necessarily wrong -- a reference tier may legitimately not
    # cover every item -- so it warns and says how many, rather than refusing.
    if ref_dir and rows:
        if refs_found == 0:
            die(
                f"{m['run_id']}: reference_id {m['fingerprint']['data']['reference_id']!r} "
                f"is declared but NOT ONE of its {len(rows)} reference files exists "
                f"under {ref_dir}.\n"
                f"  Scoring would silently treat every gold set as empty and report a "
                f"plausible wrong number.\n"
                f"  References are often gitignored rather than committed: put them back (in a "
                f"checkout of the harness, an example's fetcher: python examples/<example>/fetch.py),\n"
                f"  or make them again:\n"
                f"    "
                + how(
                    f"evh dataset-create --dataset-id {m.get('dataset_id')} --source-dir …",
                    f"make dataset-create DATASET_ID={m.get('dataset_id')}",
                ),
                "not-materialized",
            )
        if refs_found < len(rows):
            print(
                f"    WARNING: only {refs_found} of {len(rows)} items have a "
                f"reference under {ref_dir}; the rest scored against None",
                flush=True,
            )


def _rescored_fingerprint(
    source_fp: dict[str, Any],
    adapter_id: str,
    adapter_path: Path | None,
    reference_id: str | None,
    tier: str | None,
    run_name: str,
) -> dict[str, Any]:
    """The source run's fingerprint, made true of the rescore."""
    # The fingerprint is copied from the source run, and its `instrument.adapter`
    # identifies the scorer that produced the ORIGINAL numbers -- not these. Left
    # alone, a rescored run asserts the old scorer in the one field meant to identify
    # it, and every downstream tool (compare_runs, validate_tree, promote_baseline)
    # believes it. Overwrite it and invalidate the hash, which no longer describes
    # anything that was computed together.
    fp = json.loads(json.dumps(source_fp))
    fp.setdefault("instrument", {})["adapter"] = {
        "id": adapter_id,
        "sha256": _sha(adapter_path),
    }
    # THE REFERENCE HASH DESCRIBED THE WRONG BYTES. `data.references_sha256`
    # was copied from the source run, where it records the references as they
    # were WHEN THAT RUN EXECUTED -- while these scores were computed against
    # whatever is in data/references now. A rescored run could therefore assert
    # a hash over reference files it had never read, which is the one claim a
    # fingerprint exists to make. Recomputed here, with the source's value kept
    # beside it when the two differ, because "the gold set changed under us" is
    # a finding and not a detail. Found by external review.
    fp_data = fp.setdefault("data", {})
    moved = bool(reference_id and fp_data.get("reference_id") != reference_id)
    if moved:
        fp_data["reference_id_at_measurement"] = fp_data.get("reference_id")
        fp_data["reference_tier_at_measurement"] = fp_data.get("reference_tier")
        fp_data["reference_id"] = reference_id
        fp_data["reference_tier"] = tier
    actual_refs = references_digest(ROOT, fp_data.get("reference_id"), DATA)
    prior_refs = fp_data.get("references_sha256")
    fp_data["references_sha256"] = actual_refs
    if prior_refs and actual_refs and prior_refs != actual_refs:
        fp_data["references_sha256_at_measurement"] = prior_refs
        # Onto ANOTHER reference set the hashes always differ (other files): that is
        # the move, recorded above, not a change. Only the same set's files changing
        # under the run is (found by the GUIDE's check, 0.4.0).
        if not moved:
            fp_data["references_changed_since_measurement"] = True
            print(
                f"    WARNING: {run_name}: the reference files have CHANGED since "
                f"this run was measured; scores here are against the current ones"
            )
    # The deployment and the settings are the source run's, carried as they are; the instrument and the
    # data are re-hashed. The whole hash stays null: these parts were not measured together.
    seal(fp, whole=False)
    fp["hash_invalid_because"] = (
        "scores were recomputed by a different scorer than the one this "
        "fingerprint was built from; see derived.with"
    )
    return fp


def scorer_of(m: dict) -> str:
    """The scorer that judged a run (RFC-022), 12 characters; "" when the record names none (model.runs)."""
    return _model_runs.scorer_of(m)


def label_for(scorer: str, reference_id: str | None) -> str:
    """The label a re-score is read under when none is named: `silver` against a silver reference, `labels-<dataset>-
    <set>` against a label set, else `rescored <8 characters of the scorer>`."""
    if reference_id and reference_id.startswith("silver/"):
        return "silver"
    if reference_id and reference_id.startswith(LABELS_PREFIX):
        return _datasets.label_of(reference_id.removeprefix(LABELS_PREFIX))
    return f"rescored {scorer[:8]}"


def latest_scoring(d: Path, m: dict) -> tuple[str, Path | None]:
    """(the scorer the run is read with now, the re-score it is read from or None): the run's latest re-score (a score
    of the run read as "rescored ..."), else the run's own scorer."""
    found = []
    for sd in _model_runs.scores_of(_model_runs.run_of(d)):
        rec = _model_runs.record(sd)
        if rec and (rec.get("derived") or {}).get("kind") == "rescore" and _is_rescored(sd):
            found.append((rec.get("created_at") or "", sd.name, sd, rec))
    if not found:
        return scorer_of(m), None
    _at, _key, latest, rec = max(found, key=lambda t: t[:2])
    return scorer_of(rec), latest


def _is_rescored(sd: Path) -> bool:
    """Whether a score is a `rescore`'s own label (rescored <scorer>), not a silver, adjudicated or label-set one."""
    return str(_model_runs.meta(sd).get("label") or "").startswith("rescored ")


def current_scorer(m: dict, adapters: dict[str, Any] | None = None) -> str:
    """The scorer the run's adapter has now, in this tree (12 characters), or "" when it cannot be found."""
    adapters = {} if adapters is None else adapters
    spec = m.get("adapter")
    if not spec:
        return ""
    if spec not in adapters:
        found = load_recorded_adapter(spec)
        if found is None:
            return ""
        adapters[spec] = found
    return _sha(adapters[spec][3])[:12]


def measured_runs(dataset_id: str, configs: set[str] | None = None) -> list[tuple[Path, dict]]:
    """Every measured run on the dataset (the score it made when it ran, its record not a derived one), of the systems
    when named: what a round's or a goal's arms were first scored from."""
    out: list[tuple[Path, dict]] = []
    for rid in _model_runs.run_ids():
        run = _model_runs.run(rid)
        if not run or run.get("dataset_id") != dataset_id:
            continue
        sd = _model_runs.first_score(rid)
        rec = _model_runs.record(sd) if sd else None
        if (
            sd is None
            or rec is None
            or rec.get("derived")
            or (configs is not None and rec.get("system_id") not in configs)
        ):
            continue
        out.append((sd, rec))
    return out


def rescore_one(
    d: Path,
    m: dict,
    *,
    label_as: str | None = None,
    reference_id: str | None = None,
    adapters: dict[str, Any] | None = None,
    quiet: bool = False,
    faith: dict[str, Any] | None = None,
    preview: bool = False,
) -> tuple[Path, dict] | None:
    """Re-score one finished run (`d`: the score it is re-read from, `m` its record) from its stored outputs, writing a
    score under the run read as `label_as` (default `label_for`); (the score's directory, its record), or None when
    the run records no adapter. A score of the same scorer against the same reference that the run already has, with
    the same rows, is the same measurement: nothing is written ("already scored"); with other rows it is refused.
    A `preview` writes the run and the score, read as the plain arm, into the scratch root (the caller's to point
    somewhere throwaway) and nothing into the project."""
    adapters = {} if adapters is None else adapters
    rid = m["run_id"]
    spec = m.get("adapter")
    if not spec:
        print(f"  SKIP {rid}: the run records no adapter")
        return None
    if spec not in adapters:
        # The id the run recorded, resolved under the project (and in a checkout the
        # repository root, where the examples' ids start): _adapter.load_recorded_adapter,
        # shared with silver-calibrate.
        found = load_recorded_adapter(spec)
        if found is None:
            die(
                f"adapter not found for {rid}: {spec!r} is under none of "
                f"{', '.join(str(x) for x in adapter_search_dirs())}",
                "not-found",
            )
        adapters[spec] = found
    _call, score, adapter_id, adapter_path, _warm, _fp = adapters[spec]
    wants_source = score_wants_source(score)
    ref_dir, tier = _references_for(m, reference_id)
    mat = MATERIALIZED / m["dataset_id"]
    item_source = _item_sources(m["dataset_id"])

    rows: list[dict[str, Any]] = []
    refs_found = 0
    recosted = 0
    # Keys the ADAPTER attached at call time (Result.extra) rather than at score time:
    # `truncated`, `reasoning_tokens`. Unrecoverable afterwards, so they ride along.
    extra_keys = set(m.get("metric_kinds", {})) & {"truncated", "reasoning_tokens"}
    extra_keys |= {"truncated", "reasoning_tokens"}
    dropped: set = set()
    from evaluation_harness._adapter import same_of  # noqa: PLC0415
    from evaluation_harness._label_sets import action_bound  # noqa: PLC0415

    bound = action_bound(ref_dir)
    same = same_of(m.get("adapter"))
    not_scorable: list[str] = []

    def unscorable(iid: str, output: str) -> bool:
        if iid in bound and not same(output, bound[iid]):
            not_scorable.append(iid)
            return True
        return False

    for old in _runs.item_rows(d):
        row, had_ref, recost = _rescore_row(
            old, d, ref_dir, mat, item_source, score, wants_source, extra_keys, unscorable if bound else None
        )
        refs_found += had_ref
        recosted += recost
        # What the source scored per item and these rows no longer carry: the previous
        # scorer's metrics. It added whichever key the carry loop above ended on, so 24
        # NER runs recorded `untyped_tp` as dropped beside an `untyped_tp` score.
        dropped |= {k for k in old if k != "item_id" and not k.startswith("_") and k not in row}
        rows.append(row)

    _check_references(d, m, ref_dir, rows, refs_found)

    scores = aggregate_scores(rows)
    # The adapter's score_run(), over the stored outputs and the references read again: a run-level metric is
    # recomputed like every per-item one, never carried from the source.
    by_run = run_scorer(adapter_path)
    run_metrics: list[str] = []
    if by_run is not None and rows:
        items = []
        for row in rows:
            iid = row["item_id"]
            rf = ref_dir / f"{iid}.txt" if ref_dir else None
            items.append(
                {
                    "item_id": iid,
                    "output": _outputs.output(d, iid),
                    "reference": _store.read_text(rf, encoding="utf-8", errors="replace")
                    if rf is not None and _store.is_file(rf)
                    else None,
                    "scores": {k: v for k, v in row.items() if k != "item_id" and not k.startswith("_")},
                }
            )
        whole = run_level_scores(by_run, items, scores)
        scores.update(whole)
        run_metrics = sorted(whole)

    # Provenance of the RESCORE itself: which run it came from, and which scorer
    # produced these numbers. Without this a rescored run is indistinguishable from
    # a measured one, which is the whole risk of having this script at all.
    provenance: dict = {"adapter": adapter_id, "sha256": _sha(adapter_path)}
    # The adapter FILE's hash does not cover a scorer that lives in a shared module.
    # An adapter may expose `scorer_id()` -- no params, no network -- naming the
    # hashes that identify its scoring rule; without it, an extraction.py-only change
    # is invisible here and a rescored run cannot say what measured it.
    sid = getattr(sys.modules.get(getattr(score, "__module__", ""), None), "scorer_id", None)
    if callable(sid):
        provenance["scorer"] = sid()
    new = derived_record(
        m,
        kind="rescore",
        source_dir=rid,
        with_=provenance,
        scores=scores,
        n_items=len(rows),
        metric_kinds=_kinds(adapter_path) or m.get("metric_kinds") or {},
        primary_metric=_primary(adapter_path, m.get("params") or {}) or m.get("primary_metric"),
        metric_descriptions=_descriptions(adapter_path) or m.get("metric_descriptions"),
        metric_directions=_directions(adapter_path) or m.get("metric_directions"),
        reference_tier=tier if reference_id else None,
    )
    if faith is not None:
        new["faithfulness"] = faith  # a replay's (RFC-030), as the records stood when it was re-scored
    if not_scorable:
        new["not_scorable"] = not_scorable
        print(
            f"  note: {rid}: {len(not_scorable)} item(s) not scorable under this variant: their label holds only "
            "under production's action, and this run acted otherwise (RFC-031); left out of its scores"
        )
    else:
        new.pop("not_scorable", None)
    if run_metrics:
        new["run_metrics"] = run_metrics
    else:
        new.pop("run_metrics", None)  # the source's: this scorer computed none of them
    if isinstance(new.get("fingerprint"), dict):
        new["fingerprint"] = _rescored_fingerprint(
            new["fingerprint"], adapter_id, adapter_path, reference_id, tier, rid
        )
    if dropped:
        new["rescore_dropped_metrics"] = sorted(dropped)
    scorer = scorer_of(new)
    if not scorer:
        die(
            f"{rid}: the adapter {adapter_id} has no file to hash, so the score has no scorer to be keyed by",
            "not-found",
        )
    reference = ((new.get("fingerprint") or {}).get("data") or {}).get("reference_id")
    if preview:
        _model_runs.write_run(rid, _model_runs.run(rid) or {}, scratch=True)
        sd = _model_runs.write_score(rid, scorer, reference, new, first=True, scratch=True)
        _outputs.write_rows(sd, rows)
        return sd, new
    label_as = label_for(scorer, reference) if label_as is None else label_as
    key = _model_runs.key(scorer, reference)
    held = _model_runs.run_dir(rid) / "scores" / key
    text = _outputs.rows_as_written(held, rows)
    if _model_runs.record(held) is not None:
        if _outputs.rows_text(held) != text:
            die(
                f"{rid} is already scored by {key}, with other rows than this re-score gives (its references or "
                "outputs changed under the same scorer): a score is not written over, so nothing is. Read it as "
                "it is, or score with a scorer that differs.",
                "would-overwrite",
            )
        if not quiet:
            print(f"  {rid}  already scored by {key}: not written again")
        return held, _model_runs.record(held) or new
    sd = _model_runs.write_score(rid, scorer, reference, new, label_as=label_as)
    _outputs.write_rows(sd, rows)  # no outputs of its own: they are its run's (RFC-024)
    if not quiet:
        note = f", {recosted} re-costed from the bill" if recosted else ""
        print(f"  {rid}  -> {len(rows)} item(s){note}  ({label_as})")
    return sd, new


def rescore_runs(
    todo: list[tuple[Path, dict]],
    *,
    label_as: str | None = None,
    reference_id: str | None = None,
    quiet: bool = False,
    faith: dict[str, Any] | None = None,
) -> list[tuple[Path, dict]]:
    """Re-score each run (rescore_one); the scores written, or found already there, with their records."""
    adapters: dict[str, Any] = {}
    done = []
    ordered = sorted(todo, key=lambda t: (t[1]["run_id"], t[0].name))
    for k, (d, m) in enumerate(ordered):
        _progress.step(k, len(ordered))
        got = rescore_one(
            d,
            m,
            label_as=label_as,
            reference_id=reference_id,
            adapters=adapters,
            quiet=quiet,
            faith=(faith or {}).get(m["run_id"]),
        )
        if got is not None:
            done.append(got)
    _progress.step(len(ordered), len(ordered))
    return done


def body(**inputs: Any) -> int:
    """Re-score finished runs from their stored outputs: no API calls, no money."""
    args = legacy.namespace(inputs, "rescore", {"round": "round_id"})
    if args.labels:
        if args.reference_id or args.round_id:
            die("--labels is its own target: not with --reference-id or --round", "bad-argument")
        if not args.dataset_id:
            die("--labels needs --dataset-id", "bad-argument")
        args.reference_id = labels_reference(args.labels, args.dataset_id)
    elif args.reference_id and not _store.is_dir(REFERENCES / args.reference_id):
        die(f"no reference set at data/references/{args.reference_id}", "not-found")
    rnd = None
    if args.round_id:
        if not args.goal:
            die("--round needs --goal", "bad-argument")
        if len(args.why.split()) < 3:
            die("--round needs --why, a sentence: what changed in the scoring, and why?", "bad-argument")
        from evaluation_harness import _rounds  # noqa: PLC0415

        rnd = _rounds.find(args.goal, args.round_id)
        if rnd is None:
            die(f"no round {args.round_id} of {args.goal}", "not-found")
        args.dataset_id = rnd["dataset_id"]
        todo = measured_runs(args.dataset_id, set(_rounds.arms_of(rnd)))
    elif not args.dataset_id:
        die("--dataset-id, or --goal with --round", "bad-argument")
    else:
        todo = [
            (d, m)
            for d, m in measured_runs(args.dataset_id)
            if not args.match or args.match in m["system_id"]
        ]
    if not todo:
        die(
            f"no runs on {args.dataset_id!r}" + (f" matching {args.match!r}" if args.match else ""),
            "not-found",
        )
    # A replay is scored only once it reproduces production (RFC-030): every run checked before any is written.
    from evaluation_harness import _faith  # noqa: PLC0415

    faith = {m["run_id"]: _faith.allow_scoring(m, "re-scoring", args.unfaithful) for d, m in todo}
    print(f"rescoring {len(todo)} run(s)")
    done = rescore_runs(todo, label_as=args.label, reference_id=args.reference_id, faith=faith)
    labels = sorted({str(_model_runs.meta(d).get("label") or "") for d, _ in done})
    print(f"\n{len(done)} run(s) rescored, read as {', '.join(repr(x) for x in labels)}")
    _jsonout.values({"rescored": [str(d) for d, _ in done], "labels": labels})
    if rnd is not None and done:
        from evaluation_harness import _rounds  # noqa: PLC0415

        sha = (done[0][1].get("derived") or {}).get("with", {}).get("sha256", "")
        rnd.setdefault("scoring", []).append(
            {"at": now(), "scorer": sha[:12], "why": args.why, "written": labels, "runs": len(done)}
        )
        src_ref = {m["run_id"]: _reference_of(m) for _d, m in todo}
        _rounds.read_under_rescore(
            rnd,
            done,
            frozenset(m["system_id"] for _d, m in done if src_ref.get(m["run_id"]) != _reference_of(m)),
        )
        _rounds.save(rnd)
        print(f"  round {rnd['round_id']} of {rnd['goal']} records the scoring: {args.why}")
    for line in cut_off_lines(todo, done):
        print(line)
    next_cmd = f"evh goal-leaderboard {rnd['goal']}" if rnd else "evh goal-list"
    src_ref = {m["run_id"]: _reference_of(m) for d, m in todo}
    print(
        closing_line([(src_ref.get(m["run_id"]), _reference_of(m)) for d, m in done])
        + how(next_cmd, "make catalog")
    )
    return 0


def cut_off_lines(todo: list[tuple[Path, dict]], done: list[tuple[Path, dict]]) -> list[str]:
    """A warning for each re-scored run whose stored outputs stopped at max_tokens, as `evh run` gives it: a re-score
    reads those outputs again and scores them as if complete."""
    rescored = {m["run_id"] for _d, m in done}
    lines = []
    for d, m in sorted(todo, key=lambda t: t[1]["run_id"]):
        if m["run_id"] not in rescored:
            continue
        rows = list(_runs.item_rows(d))
        cap = (m.get("params") or {}).get("max_tokens")
        cut = cut_off_items(rows, cap)
        if cut:
            blank = [i for i in cut if not (_outputs.output(d, i) or "").strip()]
            spent_note = f"\n    {empty_at_cap_note(blank)}" if blank else ""
            lines.append(
                f"  WARNING: {m['run_id']}: {len(cut)} of {len(rows)} output(s) stopped at max_tokens"
                f"{'' if cap is None else f'={cap}'} ({', '.join(cut[:6])}{' ...' if len(cut) > 6 else ''}).{spent_note}\n"
                "    A re-score reads them as they are and scores them as if complete. Raise max_tokens "
                "(a new system_id) and run again."
            )
    return lines


def _reference_of(m: dict[str, Any]) -> str:
    return ((m.get("fingerprint") or {}).get("data") or {}).get("reference_id") or "no reference"


def closing_line(pairs: list[tuple[str | None, str]]) -> str:
    """What the goals, the rounds and the catalog do with the re-scores just written, from each one's
    (reference its run was scored on, reference it was scored on now). The goals read a re-score in place of the run
    it re-read only when both are the same reference (catalog_build._mark_superseded); a re-score on another
    reference is a table of its own beside the run's, and the run's table is as it was."""
    apart = sorted({(old, new) for old, new in pairs if old != new}, key=str)
    text = (
        "the goals, the rounds and the catalog read an arm's re-score in place of its runs when every run of the "
        "arm was re-scored against the reference it was measured on."
    )
    if not apart:
        return _wrap(text + " See it with:") + " "
    moved = "; ".join(
        f"{sum(1 for p in pairs if p == (old, new))} run(s) against {new}, measured against {old}"
        for old, new in apart
    )
    return (
        _wrap(text)
        + "\n"
        + _wrap(
            f"Not in place: {moved}. The goals show those as a table of their own, scored against the new reference; "
            "the table scored against the old one stays as it was. See them with:"
        )
        + " "
    )


def _wrap(text: str) -> str:
    """A paragraph of the closing lines, wrapped to 100 columns and indented (one run's list of references ran past
    230 on one line)."""
    return textwrap.fill(text, 100, initial_indent="  ", subsequent_indent="  ")


def _kinds(path):
    from evaluation_harness._adapter import metric_kinds  # noqa: PLC0415

    return metric_kinds(path)


def _primary(path, params=None):
    from evaluation_harness._adapter import primary_metric  # noqa: PLC0415

    return primary_metric(path, params)


def _directions(path):
    """The rescoring adapter's METRIC_DIRECTIONS, refreshed on the run like its kinds."""
    from evaluation_harness._adapter import metric_directions  # noqa: PLC0415

    return metric_directions(path)


def _descriptions(path):
    from evaluation_harness._adapter import metric_descriptions  # noqa: PLC0415

    return metric_descriptions(path)


def _sha(path):
    from evaluation_harness._codeid import file_sha256  # noqa: PLC0415

    # By behaviour: an adapter whose docstrings or METRIC_DESCRIPTIONS changed scores the same.
    return file_sha256(Path(path)) if path else None
