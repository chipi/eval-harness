"""Mutation-test a labeller (RFC-031 X1): each named change to the rules or the join must move some labels.

    evh label-mutants triage_v1 --capture decisions --map outcomes.yaml \\
        [--outcomes issues --join fp=fp --within -1m,+15m] [--mutants my_mutants.py]

Three of the triage fleet's labeller mistakes (a recurrence counted from every ledger row, "closed as duplicate" read as
noise, the input rebuilt from the wrong field) were caught only by reading results. A mutant here is the labeller with
one named change, run over the same captures as `label-coverage` runs it: the items whose class or label differ from
the unchanged labeller's are counted. A mutant that moves no label is a finding (the labelled items do not reach what
it changed), as a surviving replay mutant is (RFC-030 R5), and the command exits 6.

Built in: each rule's `min_age_days` halved and one and a half times; each pair of neighbouring rules swapped; each
`when` value replaced; the join's `--within` window moved an hour later. A project adds its own with `--mutants
FILE.py`, a module defining `mutants(rules) -> [(name, rules)]` and, optionally, `join_mutants(join) -> [(name,
join)]` (join: {"capture", "join", "within", "identity", "gone_if_missing", "as"}), called once for each
`--outcomes`, the other joins left as they are. Nothing is written.
"""

from __future__ import annotations

import copy
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from evaluation_harness import _jsonout, _outcome_join
from evaluation_harness._common import die, load_module
from evaluation_harness._outcome_rules import load_rules
from evaluation_harness.label_coverage import coverage

MUTANT_VALUE = "__mutant__"


def builtin(rules: list[dict]) -> list[tuple[str, list[dict]]]:
    """The generic mutants of a rule list."""
    out: list[tuple[str, list[dict]]] = []
    for n, r in enumerate(rules, 1):
        if "min_age_days" in r:
            for factor, said in ((0.5, "halved"), (1.5, "one and a half times")):
                m = copy.deepcopy(rules)
                m[n - 1]["min_age_days"] = r["min_age_days"] * factor
                out.append(
                    (
                        f"rule {n}: min_age_days {said} ({r['min_age_days']} -> {r['min_age_days'] * factor:g})",
                        m,
                    )
                )
        for field in sorted(r.get("when") or {}):
            m = copy.deepcopy(rules)
            m[n - 1]["when"][field] = MUTANT_VALUE
            out.append((f"rule {n}: when {field} replaced", m))
    for n in range(1, len(rules)):
        m = copy.deepcopy(rules)
        m[n - 1], m[n] = m[n], m[n - 1]
        out.append((f"rules {n} and {n + 1} swapped", m))
    return out


def _shift(within: str | None) -> str | None:
    """`--within` moved an hour later (both ends)."""
    if not within:
        return None
    from evaluation_harness._outcome_join import _span  # noqa: PLC0415

    lo, _, hi = within.partition(",")
    mins = [int(_span(x).total_seconds() // 60) + 60 for x in (lo, hi)]
    return ",".join(f"{m:+d}m" for m in mins)


def _signature(cov: dict[str, Any]) -> dict[str, tuple]:
    return {x["item_id"]: (x["class"], tuple(x.get("label") or ())) for x in cov["by_item"]}


def body(
    dataset: str,
    capture: str,
    map: str,
    mutants: str | None = None,
    outcomes: list[dict[str, Any]] | None = None,
) -> int:
    """Run every mutant of a labeller and count the labels each moves."""
    args = SimpleNamespace(
        dataset_id=dataset, capture=capture, map=Path(map), mutants=Path(mutants) if mutants else None
    )
    rules = load_rules(args.map)
    join = _outcome_join.joins_of(outcomes)
    base = _signature(coverage(args.dataset_id, args.capture, rules, join))
    labelled = sum(1 for c, _l in base.values() if c == "labelled")
    plans: list[tuple[str, list[dict], Any]] = [(name, m, join) for name, m in builtin(rules)]

    def describe(j: Any) -> dict[str, Any]:
        return {
            "capture": j.capture,
            "join": f"{j.item_field}={j.record_field}",
            "within": j.within_text,
            "identity": "=".join(j.identity) if j.identity else None,
            "gone_if_missing": j.gone_if_missing,
            "as": j.name,
        }

    def make_join(j: dict) -> Any:
        return _outcome_join.Join(
            j["capture"],
            j["join"],
            j.get("within"),
            j.get("identity"),
            j.get("gone_if_missing", False),
            j.get("as"),
        )

    # Each outside capture's join is mutated in turn, the others as they are (several: the fleet's beta).
    joins = join.joins if join else []

    def with_one(k: int, j: dict) -> Any:
        return _outcome_join.Joins([make_join(j) if n == k else o for n, o in enumerate(joins)])

    mod = None
    if args.mutants:
        from evaluation_harness import _common  # noqa: PLC0415

        mod = load_module(
            (_common.ROOT / args.mutants).resolve() if not args.mutants.is_absolute() else args.mutants,
            "evh_label_mutants",
        )
    for k, one in enumerate(joins):
        jargs = describe(one)
        which = f" ({jargs['as']})" if len(joins) > 1 else ""
        if jargs.get("within"):
            plans.append(
                (
                    f"the join's window moved an hour later{which} ({jargs['within']} -> {_shift(jargs['within'])})",
                    rules,
                    with_one(k, {**jargs, "within": _shift(jargs["within"])}),
                )
            )
        for name, j in (getattr(mod, "join_mutants", lambda j: [])(dict(jargs)) or []) if mod else []:
            # A key the join does not read would run the unchanged join and be reported SURVIVED (the
            # fleet's beta): refused, so the mutant is written in the keys that are read.
            unread = sorted(set(j) - set(jargs)) if isinstance(j, dict) else []
            if not isinstance(j, dict) or unread:
                die(
                    f"--mutants {args.mutants}: join mutant {name!r} "
                    + (
                        f"has key(s) the join does not read: {', '.join(unread)}"
                        if unread
                        else "is not a dict"
                    )
                    + f". A join mutant changes {', '.join(sorted(jargs))}; the fields joined are one "
                    "'join': 'ITEM_FIELD=RECORD_FIELD'.",
                    "bad-argument",
                )
            plans.append((f"{name}{which} (the project's)", rules, with_one(k, j)))
    if mod is not None:
        for name, m in getattr(mod, "mutants", lambda r: [])(copy.deepcopy(rules)) or []:
            plans.append((f"{name} (the project's)", m, join))
    print(
        f"{args.dataset_id}: {len(plans)} mutant(s) of the labeller over capture {args.capture}"
        + (f" and {join.capture}" if join else "")
        + f"; unchanged it labels {labelled} item(s)"
    )
    results = []
    for name, m, j in plans:
        sig = _signature(coverage(args.dataset_id, args.capture, m, j))
        moved = sorted(i for i in base if sig.get(i) != base[i])
        results.append({"mutant": name, "moved": len(moved)})
        print(f"  {'SURVIVED' if not moved else 'killed  '}  {name}: {len(moved)} label(s) moved")
    survivors = [r["mutant"] for r in results if not r["moved"]]
    print(
        f"{len(results) - len(survivors)} of {len(results)} killed"
        + (
            f"; {len(survivors)} survived: the labelled items do not reach what they change (a finding: read why)"
            if survivors
            else ""
        )
    )
    _jsonout.values({"mutants": results, "survived": survivors, "labelled": labelled})
    return 6 if survivors else 0
