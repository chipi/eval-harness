"""A sheet of a dataset's items to label (RFC-023): what production or an arm decided, a proposal, an empty label.

    evh label-sheet --dataset-id tickets_v1 --out sheet.csv
    evh label-sheet --dataset-id prod_2026_11 --items disagree --runs production_2026_11,triage_lead_v1 \\
        --propose issue_verdicts --choices file,dismiss,escalate,cleanup --out sheet.csv
    evh label-sheet --dataset-id prod_2026_11 --item a1 --item a7 --out sheet.csv

One row per item: `item_id`, `item` (the start of the item itself, when it is materialized here), one column per
run in --runs (what it decided, its output), `proposal` (a label set's label, or a run's output) and the empty
columns `label`, `also right` and `note`. Open it in Excel or any spreadsheet (it is UTF-8 CSV with the mark Excel
needs), fill `label` (or write `yes` to take the proposal) and, where more than one answer is fully right (each as
right as the label, not "unsure which"), the others in `also right` (separated by `|`); save it as CSV and run `evh
label-import`. --choices writes the allowed answers into the label column's header (`label [file|dismiss|…]`), and
label-import refuses any other. Which items: --items unlabelled (the default: no label in any set yet), all, or
disagree (the runs in --runs decided differently); or exactly those named with --item. A run is a run id or a system
id (its latest run on the dataset). Nothing is written but the sheet.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from evaluation_harness import _outputs, _store
from evaluation_harness._common import die, item_path, load_dataset
from evaluation_harness._label_sets import labels_for, sets, text_of
from evaluation_harness._runs import runs_on
from evaluation_harness._sheets import ALSO, NOTE, label_header, write_csv
from evaluation_harness.model import datasets as _datasets
from evaluation_harness.model import runs as _model_runs
from evaluation_harness.ops import legacy

VIEW = 160


def run_dir(name: str, dataset_id: str, label: str = "") -> Path:
    """The score a run id, or a system's latest run on the dataset, is read as under `label` ("": a plain run's own
    score, else that of a run scored against a label set of the dataset, where a run scored against labels lands).
    An arm id, as the catalog names it (<prefix>/<dataset>/<system>, model.runs.arm_id), is that arm's latest run."""
    scores = runs_on(dataset_id, label=None)
    if name.count("/") >= 2:
        _prefix, ds, _system_id = name.rsplit("/", 2)
        if ds != dataset_id:
            die(f"--runs {name}: not an arm on {dataset_id}", "not-found")
        found = [d for d, m in scores if _model_runs.arm_id(d, m) == name]
        if not found:
            die(f"--runs {name}: no run of that arm", "not-found")
        return found[-1]
    # In the order they are looked up: the label asked for, then (for the plain one) the label sets' own.
    own = [(d, m) for d, m in scores if _model_runs.label(d, m) == label]
    sets_ = (
        [(d, m) for d, m in scores if _datasets.is_label_of(_model_runs.label(d, m), dataset_id)]
        if not label
        else []
    )
    for group in (own, sets_):
        for d, m in group:
            if m["run_id"] == name:
                return d
    for group in (own, sets_):
        found = [d for d, m in group if m["system_id"] == name]
        if found:
            return found[-1]
    if any(m["run_id"] == name for _d, m in runs_on(label=None)) and not any(
        m["run_id"] == name and m.get("dataset_id") == dataset_id for _d, m in scores
    ):
        die(f"--runs {name}: that run is not on {dataset_id}", "mismatch")
    die(f"--runs {name}: no run with that id, and no run of that system on {dataset_id}", "not-found")


def output(d: Path, item_id: str) -> str | None:
    """A run's output for one item (what it decided), or None when it has none."""
    text = _outputs.output(d, item_id)
    return text.strip() if text is not None else None


def view(dataset_id: str, item_id: str, limit: int | None = VIEW) -> str:
    """The start of the item itself (`limit` characters; all of it for None), on one line, or "" when it is not
    materialized here."""
    p = item_path(dataset_id, item_id)
    if p is None:
        return ""
    text = _store.read_text(p, encoding="utf-8", errors="replace")
    if p.suffix == ".json":
        try:
            text = json.dumps(json.loads(text), ensure_ascii=False)
        except ValueError:
            pass
    one = " ".join(text.split())
    return one if limit is None or len(one) <= limit else one[: limit - 1] + "…"


def body(**inputs: Any) -> int:
    """Write a sheet of items to label."""
    args = legacy.namespace(inputs, "label-sheet")
    if _store.exists(args.out):
        die(f"{args.out} exists: a sheet is not overwritten (you may have filled it)", "would-overwrite")
    choices = [c.strip() for c in (args.choices or "").split(",") if c.strip()] or None
    from evaluation_harness import _seal  # noqa: PLC0415

    _seal.refuse_if_sealed(args.dataset_id, "a label sheet")
    header, rows, n = build(args.dataset_id, args.items, args.item, args.runs, args.propose, choices)
    write_csv(header, rows, args.out)
    from evaluation_harness import _exposure  # noqa: PLC0415

    at = header.index("item_id")
    _exposure.read_by_harness(
        args.dataset_id,
        [r[at] if isinstance(r, (list, tuple)) else r["item_id"] for r in rows],
        "a label sheet",
    )
    print(f"{args.out}: {len(rows)} item(s) of {n} to label")
    print(
        "  fill `label` (or `yes` for the proposal; answers just as right in `also right`, separated by |), "
        f"then: evh label-import --sheet {args.out} --dataset-id {args.dataset_id} --set <name> --by <you>"
    )
    return 0


def build(
    dataset_id: str,
    items: str = "unlabelled",
    item: list[str] | None = None,
    runs: str = "",
    propose: str | None = None,
    choices: list[str] | None = None,
) -> tuple[list[str], list[list[str]], int]:
    """The sheet's header and rows, and how many items the dataset has: `label-sheet` writes them to a file, the
    inspector serves them as a download."""
    ds = load_dataset(dataset_id)
    ids = [it["item_id"] for it in ds.get("items") or []]
    names = [x.strip() for x in runs.split(",") if x.strip()]
    dirs = {n: run_dir(n, dataset_id) for n in names}
    if items == "disagree" and len(dirs) < 2:
        die("--items disagree needs two runs or more in --runs", "bad-argument")
    proposal: dict[str, str] = {}
    if propose:
        doc = next((d for d in sets() if d["dataset_id"] == dataset_id and d["set"] == propose), None)
        if doc is not None:
            proposal = {i: t for i in ids if (t := text_of(doc, i)) is not None}
        else:
            pd = run_dir(propose, dataset_id)
            proposal = {i: t for i in ids if (t := output(pd, i)) is not None}
    if item:
        unknown = sorted(set(item) - set(ids))
        if unknown:
            die(f"--item: not in {dataset_id}: {', '.join(unknown[:8])}", "not-found")
        chosen = [i for i in ids if i in set(item)]
    elif items == "unlabelled":
        have = labels_for(dataset_id)
        chosen = [i for i in ids if i not in have]
    elif items == "disagree":
        from evaluation_harness._adapter import same_of  # noqa: PLC0415

        first = next(iter(dirs.values()))
        same = same_of((_model_runs.record(first) or {}).get("adapter"))
        chosen = []
        for i in ids:
            outs = [o for d in dirs.values() if (o := output(d, i)) is not None]
            if len(outs) > 1 and any(not same(outs[0], o) for o in outs[1:]):
                chosen.append(i)
    else:
        chosen = ids
    header = [
        "item_id",
        "item",
        *[f"decided: {n}" for n in names],
        "proposal",
        label_header(choices),
        ALSO,
        NOTE,
    ]
    rows = [
        [
            i,
            view(dataset_id, i),
            *[output(d, i) or "" for d in dirs.values()],
            proposal.get(i, ""),
            "",
            "",
            "",
        ]
        for i in chosen
    ]
    return header, rows, len(ids)
