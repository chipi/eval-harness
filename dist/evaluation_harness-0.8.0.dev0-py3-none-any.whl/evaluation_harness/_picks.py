"""Picks (RFC-023, ADR-0023): production items marked as candidates for the next version of governed datasets.

One list per project, data/picks.jsonl, append-only: each line is an action on one item of one dataset —

    {"action": "pick", "item": ..., "from": <dataset>, "sha256": ..., "capture": ..., "for": [<datasets>],
     "tags": {...}, "note": ..., "by": ..., "at": ...}
    {"action": "drop", "item": ..., "from": ..., "by": ..., "at": ...}
    {"action": "used", "item": ..., "from": ..., "into": <dataset>, "at": ...}

The latest line for an item wins: picking it again retargets or retags it; a drop or a use takes it off the waiting
list; the history stays.
"""

from __future__ import annotations

import sys as _sys
from pathlib import Path as _Path

if not __package__:  # run as a file (a checkout's python scripts/x.py, or an installed copy by path)
    _sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))  # the package's parent

import contextlib
import json
from pathlib import Path
from typing import Any

from evaluation_harness import _store
from evaluation_harness._common import jsonl_lines, now
from evaluation_harness.model import datasets as model_datasets


def picks_path(data: Path | None = None) -> Path:
    """data/picks.jsonl (the project's, or another data directory's)."""
    return model_datasets.picks_file(data)


def lines(data: Path | None = None, strict: bool = True) -> list[dict[str, Any]]:
    """Every line of the pick list, oldest first. A line that is not a JSON object raises, unless `strict` is False
    (the catalog reads a deployment's copy as it is: such a line is skipped)."""
    p = picks_path(data)
    if not _store.is_file(p):
        return []
    out = []
    for x in jsonl_lines(_store.read_text(p, encoding="utf-8")):
        if not x.strip():
            continue
        try:
            row = json.loads(x)
        except ValueError:
            if strict:
                raise
            continue
        if strict or isinstance(row, dict):
            out.append(row)
    return out


def append(rows: list[dict[str, Any]]) -> None:
    """Add lines to the pick list (it is never rewritten), under the project's `picks` lock: the list is one per
    project, and in the SQLite store an append is a read and a rewrite, so two writers at once kept 21 of 200 lines
    (2026-11-11). A job holding the lock already (EVH_LOCKS) writes under its own."""
    import os  # noqa: PLC0415

    from evaluation_harness import _jobs  # noqa: PLC0415

    p = picks_path()
    _store.mkdir(p.parent, parents=True, exist_ok=True)
    held = "picks" in (os.environ.get("EVH_LOCKS") or "").split(",")
    ctx = (
        contextlib.nullcontext()
        if held
        else _jobs.holding(
            [("picks", True)], os.environ.get("EVH_JOB") or f"pid {os.getpid()}", _jobs.say_waiting
        )
    )
    with ctx, _store.open_file(p, "a", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps({**r, "at": r.get("at") or now()}, ensure_ascii=False, sort_keys=True) + "\n")


def state(data: Path | None = None, strict: bool = True) -> dict[tuple[str, str], dict[str, Any]]:
    """{(dataset, item): its latest line}: what each item's last action left."""
    out: dict[tuple[str, str], dict[str, Any]] = {}
    for r in lines(data, strict):
        out[(r.get("from", ""), r.get("item", ""))] = r
    return out


def waiting(
    for_dataset: str | None = None,
    tags: dict[str, str] | None = None,
    data: Path | None = None,
    strict: bool = True,
) -> list[dict[str, Any]]:
    """The picks waiting: the items whose latest line is a pick, for a target dataset and tags when given."""
    out = []
    for r in state(data, strict).values():
        if r.get("action") != "pick":
            continue
        if for_dataset and for_dataset not in (r.get("for") or []):
            continue
        if tags and any((r.get("tags") or {}).get(k) != v for k, v in tags.items()):
            continue
        out.append(r)
    return sorted(out, key=lambda r: (r.get("from", ""), r.get("item", "")))
