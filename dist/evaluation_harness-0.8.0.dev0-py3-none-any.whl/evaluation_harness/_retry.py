"""Retrying transient provider failures. Generic infrastructure, not domain logic.

This lives in the CORE, not in an adapter, because of how it was learned. The bundled
demo adapter had retries and honoured `EVAL_MAX_RETRIES`, so the knob looked wired up
everywhere — and the summarisation example, which defined its own adapter, had none at
all. Two sweeps lost an arm to a single upstream 429: ~20 paid calls thrown away, and
the run reported "ARM FAILED" as though the model could not do the task.

Raising `EVAL_MAX_RETRIES` did nothing, because the adapter doing the work never read it.
That is the failure mode this module exists to prevent: an adapter author should get
retries by not thinking about it, rather than by remembering to copy twenty lines.

    attempts        EVAL_MAX_RETRIES       default 8
    delay cap       EVAL_RETRY_MAX_DELAY   default 60 seconds

Backoff doubles — 1, 2, 4, 8, 16, 32 … — and then flattens at the cap, so the wait grows
quickly while a blip is likely and then stops growing rather than running away. Jitter is
added so that N arms retrying after the same upstream hiccup do not return in lockstep
and cause the next one.
"""

from __future__ import annotations

import sys as _sys
from pathlib import Path as _Path

if not __package__:  # run as a file (a checkout's python scripts/x.py, or an installed copy by path)
    _sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))  # the package's parent

import os
import random
import re
import time
from collections.abc import Iterable, Sequence
from typing import Any, Callable

DEFAULT_MAX_RETRIES = 8  # attempts when EVAL_MAX_RETRIES is unset (env-check prints this one)
DEFAULT_RETRY_MAX_DELAY = 60  # seconds, when EVAL_RETRY_MAX_DELAY is unset

#: Substrings that mark a failure as worth retrying. Matched case-insensitively against
#: "TypeName: message", because provider SDKs disagree about everything else: some raise
#: typed errors, some raise a generic one with the status in the text, some wrap a third
#: party's exception. The status codes and these words are what they have in common.
#: Status codes, matched as WHOLE NUMBERS rather than substrings. As a substring, "500"
#: also matches "requested 15000 tokens" -- a permanent 400 that retried eight times over
#: two minutes before failing anyway.
TRANSIENT_CODES: tuple[str, ...] = ("429", "500", "502", "503", "504")

TRANSIENT: tuple[str, ...] = (
    "rate limit",
    "rate-limited",
    "ratelimit",
    "too many requests",
    "overloaded",
    "capacity",
    "temporarily",
    "try again",
    "timeout",
    "timed out",
    "connection",
    "reset by peer",
    "eof occurred",
)

#: NOT retryable, whatever else the message says. A bad key or a malformed request fails
#: identically on every attempt, so retrying only spends time — and, where a provider
#: bills rejected requests, money — to fail more slowly. Checked BEFORE `TRANSIENT`,
#: because "401 ... please try again later" should not be read as transient.
FATAL: tuple[str, ...] = (
    "401",
    "403",
    "invalid api key",
    "authentication",
    "permission denied",
    "not found",
    "404",
    "model_not_found",
    "does not exist",
    "invalid_request",
    "context length",
    "max_tokens",
)


def is_transient(exc: BaseException, extra: Iterable[str] = ()) -> bool:
    """Whether this failure is worth another attempt."""
    if (
        type(exc).__name__ == "CostCapExceeded"
    ):  # the cap (RFC-026 step 5): its dollar figures are not status codes
        return False
    msg = f"{type(exc).__name__}: {exc}".lower()
    if any(m in msg for m in FATAL):
        return False
    if any(m in msg for m in tuple(TRANSIENT) + tuple(extra)):
        return True
    return any(c in re.findall(r"\d+", msg) for c in TRANSIENT_CODES)


def _env_int(name: str, default: int) -> int:
    try:
        return int(float(os.environ.get(name, "").strip()))
    except (TypeError, ValueError):
        return default


def call_with_retries(
    fn: Callable[..., Any],
    args: Sequence[Any] = (),
    *,
    extra_transient: Iterable[str] = (),
    attempts: int | None = None,
    max_delay: float | None = None,
    label: str = "",
    sleep: Callable[[float], None] = time.sleep,
) -> Any:
    """Call `fn(*args)`, retrying transient failures with capped exponential backoff.

    `SystemExit` is never retried: the harness raises it for "your key is not set" and
    similar, and those are instructions to the operator, not weather.

    `sleep` is injectable so the behaviour can be tested without actually waiting — a
    retry policy whose tests are slow is a retry policy nobody tests.
    """
    tries = max(1, attempts if attempts is not None else _env_int("EVAL_MAX_RETRIES", DEFAULT_MAX_RETRIES))
    cap = (
        max_delay
        if max_delay is not None
        else float(_env_int("EVAL_RETRY_MAX_DELAY", DEFAULT_RETRY_MAX_DELAY))
    )
    last: BaseException | None = None
    for attempt in range(1, tries + 1):
        try:
            return fn(*args)
        except SystemExit:
            raise
        except Exception as exc:  # provider SDKs vary too much to enumerate
            if attempt == tries or not is_transient(exc, extra_transient):
                raise
            last = exc
            delay = min(cap, 2.0 ** (attempt - 1)) + random.uniform(0, 0.5)
            where = f" {label}" if label else ""
            print(
                f"      transient{where} ({type(exc).__name__}), retry {attempt}/{tries - 1} in {delay:.1f}s"
            )
            sleep(delay)
    raise last if last else RuntimeError("unreachable")
