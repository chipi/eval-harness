"""One pre-registered pair, tested on its own: sign-flip permutation on paired deltas.

    evh pair-test cnn_dailymail_200 \
        --a cnn_deepseek_m_n200_v1 --b cnn_anthropic_m_n200_v1 --metric coverage

WHY A SECOND TEST, WHEN leaderboard.py ALREADY HAS ONE
  `_significance` answers "which of all k(k-1)/2 pairs differ?" and pays the Nemenyi
  multiplicity price for every one of them. That is the right price for that question and
  the wrong question for a decision. A comparison fixed BEFORE looking -- "is the 67x
  dearer arm better?" -- is one test, and correcting it for 275 comparisons nobody made
  is throwing away power to answer a question that was never asked.

  The honesty condition is that the pair is named in advance. Six pairs picked after
  reading the table are a search, not a test; EVAL_REPORT.md section 3.1b says so about its
  own six and Holm-corrects them. A `hypothesis:` in A's system (ADR-0025) is the record: when A's run
  carries one against B on this metric, the output says whether it was committed before the run and
  whether the result agrees with it. With --round and no --a, A is the table's leader, chosen after
  reading: the test is corrected for the arms in play. --family N applies BONFERRONI (alpha/N) here, which is
  Holm's strictest step applied to every member: conservative, never the reverse. Holm's
  step-down needs every p-value in the family at once, which one pair does not have.

THE TEST
  Per item, delta = A - B (items both arms scored, means over repeats). Under the null the
  sign of each delta is a coin flip, so: flip each sign at random, recompute the mean,
  repeat. p = how often |mean| of a flipped sample reaches the observed |mean| (counted
  over every sign pattern up to 30 items, estimated above that: stats.py). No
  distributional assumption, and it keeps the pairing -- which matters here, where ~74% of
  the variance is between articles.

TWO VERSIONS OF ONE DATASET (--b-dataset)
  `--dataset-id D1 --a A --b B --b-dataset D2` tests A's runs on D1 against B's runs on D2, paired by
  item id. It is allowed only when the two datasets pair by item: every item the test uses is in both,
  the reference each arm was scored against says the same thing for each of them (compared item by item,
  by checksum), and both arms are scored on one metric in one direction. Otherwise it refuses and names
  why. What it establishes: the difference is the effect of the dataset change plus the arm's run-to-run
  noise (A and B the same arm: what the change did to it). What it does not: that the change caused it
  (no repeats, no way to separate the two), or anything about items only one version has.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import statistics
from pathlib import Path
from typing import Any, NoReturn

HERE = Path(__file__).resolve().parent

from evaluation_harness import (  # noqa: E402
    _hypothesis,
    _jsonout,
    _store,
)
from evaluation_harness._common import (  # noqa: E402
    dataset_item_ids,
    die,
    item_clusters,
    read_item_ids,
    scored_against_dir,
)
from evaluation_harness._runs import (  # noqa: E402
    default_metric,
    direction,
    per_item,
    refuse_run_level,
    repeat_agreement,
    runs_on,
    say_agreement,
    warn_on_ambiguous_runs,
)
from evaluation_harness.stats import LARGE_SAMPLE, clustered, fmt_p, p_method, sign_flip_p  # noqa: E402
from evaluation_harness.stats import noninferior as stats_noninferior  # noqa: E402


def _round_values(dataset_id: str, args: Any = None) -> Any:
    """values(system_id, metric) -> {item_id: value} as the round reads the arm: the arm the round stores for the
    system (its label says whether a re-score stands in for its runs), else the plain runs. Read from data/runs
    alone, an arm scored before a measure existed had none, and a test the round itself had run (production's run
    on triage_cost) found 0 shared items."""
    from evaluation_harness import rounds as rd  # noqa: PLC0415
    from evaluation_harness._rounds import resolve  # noqa: PLC0415
    from evaluation_harness.catalog_adapter import load_catalog_adapter  # noqa: PLC0415
    from evaluation_harness.model import rounds as model_rounds  # noqa: PLC0415

    ca = load_catalog_adapter(None)
    rnd = resolve(args.round, args.goal) if getattr(args, "round", None) else None
    if rnd:
        ca = model_rounds.round_view(ca, rnd)  # the runs the round recorded: a later run never moves its test

    def read(dataset: str, system_id: str) -> str:
        held = model_rounds.find_arm(rnd, system_id) if rnd else None
        return model_rounds.arm_id(rnd, held) if rnd and held else rd._arm(ca, dataset, system_id)

    def values(system_id: str, metric: str) -> dict:
        arm = read(dataset_id, system_id)
        sc = (ca.scores(arm).get(metric) or {}) if arm else {}
        reduce = getattr(args, "reduce", None)
        if reduce and reduce != "mean":
            from evaluation_harness.stats import reduce_repeats  # noqa: PLC0415

            per = sc.get("repeats") or {i: [v] for i, v in (sc.get("values") or {}).items()}
            return {i: reduce_repeats(v, reduce) for i, v in per.items()}
        return dict(sc.get("values") or {})

    return values


def _round_runs(runs: list, rnd: dict) -> list:
    """`runs` as the round reads them: a system with arms that recorded runs keeps only those runs, so the runs
    named, averaged and counted for an arm are the ones its test reads (`_round_values`); a system whose arms
    record none keeps all of its runs."""
    from evaluation_harness.model import rounds as model_rounds  # noqa: PLC0415

    keep: dict[str, set] = {}
    for a in model_rounds.arms(rnd):
        if a.get("runs"):
            keep.setdefault(a["system"], set()).update(a["runs"])
    return [r for r in runs if r[1]["system_id"] not in keep or r[1]["run_id"] in keep[r[1]["system_id"]]]


def _round_defaults(args: argparse.Namespace, runs: list, values: Any) -> tuple[bool, int]:
    """--round: the round's goal measure, its leader as A and the baseline it started from as B,
    and a refusal for an arm that is not in play in it. Returns (whether A was chosen here from the
    table, how many arms were in play: the candidates it was chosen from)."""
    from evaluation_harness import _common  # noqa: PLC0415
    from evaluation_harness._rounds import arms_of, resolve  # noqa: PLC0415
    from evaluation_harness.model import rounds as model_rounds  # noqa: PLC0415

    rnd = resolve(args.round, args.goal)
    if rnd["dataset_id"] != args.dataset_id:
        die(f"round {args.round} is on {rnd['dataset_id']}, not {args.dataset_id}", "mismatch")
    in_play = arms_of(rnd)
    goal = _common.load_goals().get(rnd["goal"]) or {}
    # The goal's tests flip one sign per cluster: so does this one, unless --cluster names another field.
    args.cluster = args.cluster or _common.goal_cluster(goal, args.dataset_id)
    args.reduce = args.reduce or ((goal.get("success_criteria") or {}).get("primary") or {}).get("reduce")
    prim = (goal.get("success_criteria") or {}).get("primary") or {}
    args.metric = args.metric or prim.get("measure")
    for x in (args.a, args.b):
        if x and x not in in_play:
            die(f"{x} is not in play in round {args.round} ({', '.join(in_play)})", "not-found")
    chose = not args.a
    if not args.a:
        # The round's leader as every view of the round reads it (model/rounds): the evidence's.
        leader = model_rounds.evidence(rnd["goal"], rnd).get("leader")
        if not leader:
            die(f"no arm in round {args.round} records {args.metric} yet", "not-enough")
        args.a = leader.rsplit("/", 1)[-1]
    if not args.b:
        base = rnd.get("baseline")
        args.b = next((m["system_id"] for d, m in runs if m["run_id"] == base), None)
        if not args.b:
            die(f"round {args.round} records no baseline run: name --b", "not-enough")
        if args.b == args.a:
            # The fleet's beta: a new round whose only arm is its baseline was said to record no baseline.
            # When --a named the baseline itself, that is the reason, whatever else is in play (the fleet's retest).
            if chose and not [c for c in in_play if c != args.b]:
                die(
                    f"round {args.round} has no arm besides its baseline {args.b}: run an arm in it, or name --a",
                    "not-enough",
                )
            die(
                f"{args.a} is round {args.round}'s baseline"
                + (f" and its leader on {args.metric}" if chose else "")
                + ": name another arm with --a to test it against the baseline, or --b",
                "not-enough",
            )
    print(f"  round {args.round}: {args.a}{' (its leader)' if chose else ''} against {args.b}")
    # The comparisons the leader could have been: every arm in play but B, whether or not B is in play.
    return chose, len([c for c in in_play if c != args.b])


def _hypothesis_of(args: argparse.Namespace, runs: list) -> dict | None:
    """A's hypothesis against B on the tested metric, as its runs recorded it, with whether it was named in
    advance; or, when the system now carries one its runs do not, that it was added after the run."""
    import yaml  # noqa: PLC0415
    from evaluation_harness import _hypothesis  # noqa: PLC0415

    a_runs = [m for _d, m in runs if m["system_id"] == args.a]

    def same(h: Any) -> bool:
        return isinstance(h, dict) and h.get("against") == args.b and h.get("measure") == args.metric

    # Every run of A averaged into the test must carry it (see _hypothesis.across_runs).
    found = _hypothesis.across_runs(a_runs, against=args.b, measure=args.metric)
    if found:
        return found
    path = _hypothesis.system_ids().get(args.a) if a_runs else None
    cfg = yaml.safe_load(_store.read_text(path, encoding="utf-8")) if path else None
    if same((cfg or {}).get("hypothesis")):
        return {
            **(cfg or {})["hypothesis"],
            "named": False,
            "commit": None,
            "why": "the system's hypothesis is not on the run: added after it",
        }
    return None


_ESTABLISHES = "the effect of the dataset change plus the arms' run-to-run noise"
_DOES_NOT = "tell the two apart, or speak for items only one version has"

#: How many items a refusal names: enough to find them, not a page.
_NAMED = 5


def _reference_ids(runs: list, system_id: str) -> set[str]:
    """The reference ids an arm's runs were scored against (the fingerprint's data.reference_id)."""
    return {
        str(((m.get("fingerprint") or {}).get("data") or {}).get("reference_id") or "")
        for _d, m in runs
        if m["system_id"] == system_id
    }


def _reference_hashes(reference_id: str, items: list[str]) -> dict[str, str]:
    """{item_id: sha256 of its reference text} for `items`: from the text where it is on this machine, else from
    the checksum the reference's manifest.json or label set's labels.json records. An item with neither is left
    out."""
    root = scored_against_dir(reference_id)
    if root is None:
        return {}
    recorded: dict = {}
    for name, key in (("manifest.json", "items_sha256"), ("labels.json", "items")):
        f = root / name
        if _store.is_file(f):
            try:
                recorded = json.loads(_store.read_text(f, encoding="utf-8")).get(key) or {}
            except ValueError:
                recorded = {}
            break
    out: dict[str, str] = {}
    for i in items:
        t = root / f"{i}.txt"
        if _store.is_file(t):
            out[i] = hashlib.sha256(_store.read_bytes(t)).hexdigest()
            continue
        got = recorded.get(i)
        got = got.get("sha256") if isinstance(got, dict) else got
        if isinstance(got, str) and got:
            out[i] = got
    return out


def _check_same_reference(args: argparse.Namespace, runs_a: list, runs_b: list, items: list[str]) -> str:
    """Refuse unless both arms were scored against one reference each, and those give the same answer for every
    item the test uses. Returns the two reference ids, as one line for the output."""
    ids = []
    for arm, ds, runs in ((args.a, args.dataset_id, runs_a), (args.b, args.b_dataset, runs_b)):
        got = _reference_ids(runs, arm) - {""}
        if len(got) != 1 or ".." in next(iter(got), ""):
            die(
                f"{arm} on {ds} records "
                + (f"{len(got)} different references ({', '.join(sorted(got))})" if got else "no reference")
                + ": a cross-version comparison needs the one reference each arm was scored against, to check "
                "that it says the same on both sides",
                "mismatch",
            )
        ids.append(next(iter(got)))
    ha, hb = (_reference_hashes(r, items) for r in ids)
    unread = sorted(i for i in items if i not in ha or i not in hb)
    if unread:
        die(
            f"cannot compare the references item by item: {len(unread)} item(s) have no reference text or "
            f"checksum in {ids[0]} or {ids[1]} (e.g. {', '.join(unread[:_NAMED])})",
            "not-enough",
        )
    differ = [i for i in items if ha[i] != hb[i]]
    if differ:
        die(
            f"the reference differs between {args.dataset_id} ({ids[0]}) and {args.b_dataset} ({ids[1]}) on "
            f"{len(differ)} of {len(items)} item(s), e.g. {', '.join(differ[:_NAMED])}: the score does not "
            "mean the same on both sides, so this is not a paired comparison",
            "mismatch",
        )
    return f"{ids[0]} / {ids[1]}"


class _Refuse:
    """Where `_run` says an argument is wrong: the operation's refusal, not a usage error."""

    @staticmethod
    def error(message: str) -> NoReturn:
        die(message, "bad-argument")


#: What an input the call does not give is, as its option was when the command line did not give it.
DEFAULTS = {
    "a": None,
    "b": None,
    "b_dataset": None,
    "round": None,
    "goal": None,
    "metric": None,
    "label": "",
    "exclude_dataset": None,
    "include_exposed": False,
    "items": None,
    "cluster": None,
    "reduce": None,
    "margin": None,
    "look_level": None,
    "permutations": 20000,
    "family": None,
    "seed": 20260926,
    "asc": False,
    "desc": False,
}


def body(dataset: str, **given: Any) -> int:
    """Test a pre-registered pair with sign-flip permutation."""
    args = argparse.Namespace(dataset_id=dataset, **{**DEFAULTS, **given})
    if args.items:
        args.items = Path(args.items)
    ap = _Refuse()
    if args.b_dataset and args.round:
        ap.error("b_dataset and round cannot be combined: a round is on one dataset")
    if args.b_dataset and not (args.a and args.b):
        ap.error("b_dataset needs a and b")
    if args.family is not None and args.family < 1:
        ap.error(f"family must be at least 1 (the number of pairs tested together), not {args.family}")
    return _run(args, ap)


def _run(args: argparse.Namespace, ap: Any) -> int:
    # Two runs sharing a system_id are averaged together below without
    # saying so. See _runs.warn_on_ambiguous_runs.
    warn_on_ambiguous_runs(args.label, args.dataset_id)
    runs = runs_on(args.dataset_id, label=args.label)
    if args.round:
        from evaluation_harness._rounds import resolve  # noqa: PLC0415

        runs = _round_runs(runs, resolve(args.round, args.goal))
    cross = bool(args.b_dataset)
    runs_b = []
    if cross:
        if args.b_dataset == args.dataset_id:
            die(
                f"--b-dataset is {args.dataset_id} itself: drop it, both arms are on one dataset",
                "bad-argument",
            )
        ids_a, ids_b = dataset_item_ids(args.dataset_id), dataset_item_ids(args.b_dataset)
        warn_on_ambiguous_runs(args.label, args.b_dataset)
        runs_b = runs_on(args.b_dataset, label=args.label)
    values = _round_values(args.dataset_id, args) if args.round else None
    chose, candidates = False, None
    if args.round:
        chose, candidates = _round_defaults(args, runs, values)
        if args.family is None and chose:
            args.family = max(candidates, 1)
    elif not (args.a and args.b):
        ap.error("a and b are required (or round, which defaults them)")
    if args.family is None:
        args.family = 1
    _named_metric = bool(args.metric)
    args.metric = args.metric or default_metric(args.dataset_id, label=args.label)
    refuse_run_level([*runs, *runs_b], args.metric, "pair-test")
    if cross and not _named_metric:
        other = default_metric(args.b_dataset, label=args.label)
        if other != args.metric:
            die(
                f"the two datasets' runs record different primary metrics ({args.dataset_id}: {args.metric}, "
                f"{args.b_dataset}: {other}): name the one to test with --metric",
                "mismatch",
            )
    if cross:
        arm_a = [r for r in runs if r[1]["system_id"] == args.a]
        arm_b = [r for r in runs_b if r[1]["system_id"] == args.b]
        lower = direction(arm_a, args.metric, args.asc, args.desc)
        lower_b = direction(arm_b, args.metric, args.asc, args.desc)
        if lower != lower_b:
            die(
                f"{args.metric} is {'lower' if lower else 'higher'}-is-better for {args.a} on {args.dataset_id} "
                f"but {'lower' if lower_b else 'higher'}-is-better for {args.b} on {args.b_dataset}: not one "
                "metric (pass --asc or --desc to decide)",
                "mismatch",
            )

        def scores_now() -> tuple[dict, dict]:
            return (
                per_item(arm_a, args.metric, reduce=args.reduce or "mean"),
                per_item(arm_b, args.metric, reduce=args.reduce or "mean"),
            )

        A, B = scores_now()
        # A measure that is not stored per item (the goal computes it at re-score) is a missing metric, not an
        # item mismatch: say which side, what is stored, and how to get it (2026-11-04, the first real use).
        for arm, ds, got, rs in ((args.a, args.dataset_id, A, arm_a), (args.b, args.b_dataset, B, arm_b)):
            if rs and not got:
                stored = sorted({k for _d, m in rs for k in (m.get("scores") or {})})
                die(
                    f"{args.metric} is not stored per item in {arm}'s runs on {ds} (stored: {', '.join(stored)}). "
                    "A measure computed at re-score is stored only in the re-scored runs (`evh rescore`): "
                    "read them with --label (the re-score's label, `evh runs-list`).",
                    "not-enough",
                )
    else:
        lower = direction(runs, args.metric, args.asc, args.desc)

        def scores_now() -> tuple[dict, dict]:
            if values is not None:
                return values(args.a, args.metric), values(args.b, args.metric)
            return (
                per_item(
                    [r for r in runs if r[1]["system_id"] == args.a],
                    args.metric,
                    reduce=args.reduce or "mean",
                ),
                per_item(
                    [r for r in runs if r[1]["system_id"] == args.b],
                    args.metric,
                    reduce=args.reduce or "mean",
                ),
            )

        A, B = scores_now()
    items = sorted(set(A) & set(B))
    if args.exclude_dataset:
        prior = dataset_item_ids(args.exclude_dataset)
        items = [i for i in items if i not in prior]
    # AN EXPLICIT ITEM SET, because some strata are not datasets. The one this was added
    # for: the 154 articles that fitted inside BART's 1024-token encoder. On the other 46
    # the local arm summarised two thirds of an article and was scored against a reference
    # written from all of it, so "bart vs an LLM over all 200" averages two different
    # tasks. The stratum is a property of a RUN, not of a dataset, so --exclude-dataset
    # cannot express it. Passing the ids in a file rather than recomputing them inside each
    # script means the leaderboard, the pair tests and the report all use provably the same
    # set -- and a reader can diff it.
    if args.items:
        keep = read_item_ids(args.items)
        items = [i for i in items if i in keep]
    cross_note: list[str] = []
    if cross:
        shared = ids_a & ids_b
        if not shared:
            die(
                f"{args.dataset_id} and {args.b_dataset} share no item id: they do not pair by item",
                "mismatch",
            )
        items = [i for i in items if i in shared]
        if len(items) < 3:
            die(
                f"only {len(items)} item(s) exist in both {args.dataset_id} ({len(ids_a)} items) and "
                f"{args.b_dataset} ({len(ids_b)} items; {len(shared)} ids shared) and are scored for both arms: "
                "nothing to test",
                "not-enough",
            )
        refs = _check_same_reference(args, arm_a, arm_b, items)
        ids_run_a = sorted({m["run_id"] for _d, m in arm_a})
        ids_run_b = sorted({m["run_id"] for _d, m in arm_b})
        n_a, n_b = len(ids_run_a), len(ids_run_b)
        cross_note = [
            f"  CROSS-VERSION comparison: {args.a} on {args.dataset_id}  vs  {args.b} on {args.b_dataset}",
            f"    item ids shared    {len(shared)} of {len(ids_a)} / {len(ids_b)}; {len(items)} used",
            f"    same reference     {refs}: the same text for each of the {len(items)} items",
            f"    runs averaged      {args.a}: {n_a}, {args.b}: {n_b}; an arm's repeats are averaged per item",
            # Which runs stand for an arm decides the verdict: name them, and where they were read from.
            f"    runs of A          {', '.join(ids_run_a)}",
            f"    runs of B          {', '.join(ids_run_b)}",
            (
                f"    read as            {args.label or 'runs'} (another set of an arm's runs, e.g. a repeat set: "
                "--label)"
            ),
            f"    establishes        {_ESTABLISHES}",
            f"    does not           {_DOES_NOT}",
        ]
    elif len(items) < 3:
        die(f"only {len(items)} shared item(s): nothing to test", "not-enough")

    deltas = [A[i] - B[i] for i in items]
    obs = statistics.fmean(deltas)
    wins = sum(1 for d in deltas if (d < 0 if lower else d > 0))
    ties = sum(1 for d in deltas if d == 0)

    units, n_units = deltas, len(deltas)
    if args.cluster:
        units, _sizes = clustered(
            dict(zip(items, deltas, strict=True)), item_clusters(args.dataset_id, args.cluster)
        )
        n_units = len(units)
        if n_units < 2:
            die(
                f"--cluster {args.cluster}: the {len(items)} items are {n_units} cluster: nothing to test",
                "not-enough",
            )
    p = sign_flip_p(units, permutations=args.permutations, seed=args.seed)
    # BONFERRONI, not Holm. One pair cannot do Holm: the step-down procedure compares the
    # smallest p to alpha/m, the next to alpha/(m-1), and so on, which needs the whole
    # family's p-values at once. alpha/m applied to every member is the strictest step
    # applied throughout -- always conservative relative to Holm, never anti-conservative,
    # so a pair that clears this has cleared Holm too. A pair that does NOT clear it may
    # still clear Holm; run the family's p-values through the step-down to find out.
    thresh = 0.05 / args.family

    for ln in cross_note:
        print(ln)
    print(f"  {args.a}  vs  {args.b}    metric={args.metric}  N={len(items)}")
    # THE ITEM IS THE UNIT. An arm's runs are averaged per item, so N counts items, never item-runs; runs that
    # agree on nearly every item (a temperature-0 model) are near-copies, and counting their item-runs would
    # multiply one observation (the fleet's feedback 33).
    agree = {}
    for label, cid, pool in (
        (args.a, args.a, arm_a if cross else runs),
        (args.b, args.b, arm_b if cross else runs),
    ):
        ag = repeat_agreement([r for r in pool if r[1]["system_id"] == cid], args.metric, items)
        if ag:
            agree[label] = ag
    if agree:
        print(
            "    repeats            "
            + "; ".join(say_agreement(k, v) for k, v in agree.items())
            + f". Each item counts once (N={len(items)}), not each item-run ("
            + ", ".join(f"{k}: {v['item_runs']}" for k, v in agree.items())
            + ")"
        )
    print(f"    delta (A - B)      {obs:+.4f}")
    print(
        f"    items A wins       {wins}/{len(items)}"
        + (" (lower is better)" if lower else "")
        + (f" ({ties} exact tie(s))" if ties else "")
    )
    method = p_method(n_units)
    how = {
        "exact": f"exact, all 2^{n_units} sign patterns",
        "sampled": f"{args.permutations} permutations",
        "normal limit": f"the normal limit, from {LARGE_SAMPLE:,} units (ADR-0028)",
    }[method]
    if args.cluster:
        print(f"    clusters           {n_units} by {args.cluster}: items that share a value count as one")
    print(f"    sign-flip p        {fmt_p(p)}  ({how})")
    ni = None
    if args.margin is not None:
        ni = stats_noninferior(
            {i: A[i] for i in items},
            {i: B[i] for i in items},
            args.margin,
            higher_is_better=not lower,
            clusters=item_clusters(args.dataset_id, args.cluster) if args.cluster else None,
        )
        said = (
            f"p {fmt_p(ni['p'])} at one-sided {ni['level']:g} ({ni['method']})"
            if ni.get("p") is not None
            else ni["method"] or ""
        )
        label = f"within {args.margin:g} of B"
        print(f"    {label:<19}{ni['verdict']}" + (f", {said}" if said else ""))
    look: dict | None = None
    if args.look_level is not None:
        # A look (RFC-029): one-sided, A better than B, at the look's level; the differences in the better direction.
        from evaluation_harness.stats import min_attainable_p_one_sided, sign_flip_p_one_sided  # noqa: PLC0415

        better = [-u for u in units] if lower else list(units)
        p1 = sign_flip_p_one_sided(better, permutations=args.permutations, seed=args.seed)
        reach = min_attainable_p_one_sided(better)
        look = {
            "level": args.look_level,
            "p_one_sided": p1,
            "attainable_p": reach,
            "verdict": "SIGNIFICANT" if p1 <= args.look_level else "NOT-SIGNIFICANT",
            "can_reach": reach is not None and reach <= args.look_level,
        }
        if args.margin is not None:
            ni_look = stats_noninferior(
                {i: A[i] for i in items},
                {i: B[i] for i in items},
                args.margin,
                higher_is_better=not lower,
                clusters=item_clusters(args.dataset_id, args.cluster) if args.cluster else None,
                level=args.look_level,
            )
            look["noninferior"] = ni_look
        print(
            f"    as a look          one-sided p {fmt_p(p1)} at {args.look_level:.4%} -> {look['verdict']}"
            + ("" if look["can_reach"] else f" (these items reach {reach:.4g} at best: they cannot show it)")
        )
    else:
        from evaluation_harness import _looks  # noqa: PLC0415

        if not cross and _looks.is_test_set(args.dataset_id):
            nxt, _ = _looks.next_number(args.dataset_id)
            print(
                f"    test set           nominal, not a look: a decision here is look {nxt} of {args.dataset_id}, "
                f"tested one-sided at {_looks.level(nxt):.4%} (evh looks)"
            )
    hyp = None if cross else _hypothesis_of(args, runs)
    in_advance = bool(hyp and hyp["named"] is True)
    chosen_note = (
        f"    (A was chosen from the table: corrected for the {candidates} comparisons it could have been)"
        if chose and args.family > 1
        else "    (A was chosen from the table: one comparison it could have been: nothing to correct)"
        if chose
        else None
    )
    if args.family > 1:
        # The same rule as Holm and the inspector: p at or below the threshold is significant.
        verdict = "SIGNIFICANT" if p <= thresh else "NOT-SIGNIFICANT"
        print(f"    Bonferroni/{args.family}     threshold {thresh:.4f} -> {verdict}")
        if chosen_note:
            print(chosen_note)
        if p > thresh:
            print("    (conservative: Holm's later steps are looser — check the family)")
    else:
        verdict = "SIGNIFICANT" if p <= 0.05 else "NOT-SIGNIFICANT"
        print(f"    verdict            {verdict} at 0.05")
        print(
            chosen_note
            or (
                "    (uncorrected: valid because the hypothesis was committed before the run)"
                if in_advance
                else "    (uncorrected: valid only if this pair was named before the table was read)"
            )
        )
    if hyp:
        agrees = _hypothesis.agreement(hyp["direction"], obs, lower, p <= thresh)
        shown = {"better": "better than", "worse": "worse than", "no-worse": "no worse than"}[
            hyp["direction"]
        ]
        print(f"    hypothesis         {args.a} {shown} {args.b} on {args.metric}: {hyp['statement']}")
        print(f"    named in advance   {_hypothesis.said(hyp)}")
        print(
            f"    result agrees      {agrees}"
            + (" (no proof of equivalence)" if hyp["direction"] == "no-worse" else "")
        )
    _jsonout.values(
        {
            **(
                {
                    "cross_version": True,
                    "b_dataset_id": args.b_dataset,
                    "items_shared": len(shared),
                    "items_in_a_dataset": len(ids_a),
                    "items_in_b_dataset": len(ids_b),
                    "reference_checked": True,
                    "runs_a": n_a,
                    "run_ids_a": ids_run_a,
                    "run_ids_b": ids_run_b,
                    "runs_b": n_b,
                    "averaged": "per item over each arm's repeats",
                    "establishes": _ESTABLISHES,
                    "does_not_establish": _DOES_NOT,
                }
                if cross
                else {}
            ),
            "a": args.a,
            "b": args.b,
            "metric": args.metric,
            "dataset_id": args.dataset_id,
            "n": len(items),
            # What the answer was computed on, so a promotion that freezes it (RFC-027 D3) can say: the items
            # compared, the runs pooled for each arm, how repeats were reduced.
            "items_sha256": hashlib.sha256("\n".join(sorted(items)).encode()).hexdigest(),
            "reduce": args.reduce or "mean",
            **(
                {}
                if cross
                else {
                    "run_ids_a": sorted(m["run_id"] for _d, m in runs if m.get("system_id") == args.a),
                    "run_ids_b": sorted(m["run_id"] for _d, m in runs if m.get("system_id") == args.b),
                }
            ),
            "repeats": agree or None,
            "cluster": args.cluster or None,
            "clusters": n_units if args.cluster else None,
            "direction": "lower" if lower else "higher",
            "delta": obs,
            "wins": wins,
            "ties": ties,
            "p": p,
            "method": method,
            "permutations": args.permutations if method == "sampled" else None,
            "seed": args.seed,
            "correction": "bonferroni" if args.family > 1 else "none",
            "family": args.family,
            "alpha": 0.05,
            "threshold": thresh,
            "verdict": verdict,
            "selection": "leader" if chose else "named",
            "noninferior": ni,
            "look": look,
            "candidates": candidates if chose else None,
            "hypothesis": {
                "against": hyp["against"],
                "measure": hyp["measure"],
                "direction": hyp["direction"],
                "statement": hyp["statement"],
                "named_in_advance": _hypothesis.YES
                if hyp["named"]
                else _hypothesis.NO
                if hyp["named"] is False
                else _hypothesis.UNDETERMINED,
                "commit": hyp["commit"],
                "why": hyp["why"],
                "agrees": agrees,
            }
            if hyp
            else None,
        }
    )
    if args.include_exposed:
        _with_exposed(scores_now, items_all=set(A) | set(B), lower=lower)
    return 0


def _with_exposed(scores_now, items_all: set, lower: bool) -> None:
    """--include-exposed: the mean difference with the held-out side's read items kept, beside the result, marked. No
    test is run on it (a test set's look is spent on the number that counts)."""
    from evaluation_harness import _exposure  # noqa: PLC0415

    if not _exposure.left():
        print("  with exposed items: none were left out")
        return
    with _exposure.including():
        A, B = scores_now()
    shared = sorted(set(A) & set(B))
    if not shared:
        return
    d = statistics.fmean(A[i] - B[i] for i in shared)
    n_more = len(shared) - len(set(shared) & items_all)
    print(
        f"  with the exposed items kept (NOT the number that counts): n {len(shared)} (+{n_more}), "
        f"delta (A - B) {d:+.4f}{' (lower is better)' if lower else ''}"
    )
    _jsonout.value("with_exposed", {"n": len(shared), "delta": d})
