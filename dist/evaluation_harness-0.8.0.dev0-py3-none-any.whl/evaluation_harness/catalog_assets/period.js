/* The catalog's period, shared by every page that has one (#period): the chips, the line saying
   what trends compare with, the period in the link (page.html#p30d), and, on tables marked
   data-period-rows, the new badge, the in-period columns and the all / new / active chips.
   Periods are counted from today, the viewer's date; scripts/catalog_periods.py computes the
   same for evh. window.PERIOD (periods.js) holds the periods; window.PERIOD_ROWS each row's
   dated runs and spend. Without this script a page shows all time. */
(function(){const P=window.PERIOD,pick=document.querySelector('.period-switch > .chips');/* not by id: the home page's section is #period too */if(!P||!pick)return;
const DAY=864e5,iso=t=>new Date(t).toISOString().slice(0,10),at=s=>Date.parse(s+'T00:00:00Z');
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"})[c]);
const today=(()=>{const d=new Date();return Date.UTC(d.getFullYear(),d.getMonth(),d.getDate());})();
const mStart=(t,back)=>{const d=new Date(t);return Date.UTC(d.getUTCFullYear(),d.getUTCMonth()-(back||0),1);};
const mEnd=t=>mStart(t,-1)-DAY;
const sameDay=(first,day)=>Math.min(first+(day-1)*DAY,mEnd(first));
function bounds(key,t,first){const m=/^(\d+)d$/.exec(key);
if(m){const n=+m[1],s=t-(n-1)*DAY;return {since:iso(s),until:iso(t),prev:[iso(s-n*DAY),iso(s-DAY)]};}
const wd=(new Date(t).getUTCDay()+6)%7;
if(key==='week'){const s=t-wd*DAY;return {since:iso(s),until:iso(t),prev:[iso(s-7*DAY),iso(t-7*DAY)]};}
if(key==='lastweek'){const s=t-(wd+7)*DAY;return {since:iso(s),until:iso(s+6*DAY),prev:[iso(s-7*DAY),iso(s-DAY)]};}
if(key==='month'){const p=mStart(t,1);return {since:iso(mStart(t)),until:iso(t),prev:[iso(p),iso(sameDay(p,new Date(t).getUTCDate()))]};}
if(key==='lastmonth'){const s=mStart(t,1),p=mStart(t,2);return {since:iso(s),until:iso(mEnd(s)),prev:[iso(p),iso(mEnd(p))]};}
if(key==='year'){const d=new Date(t),y=d.getUTCFullYear(),mo=d.getUTCMonth(),da=d.getUTCDate();
const last=Date.UTC(y-1,mo,(mo===1&&da===29)?28:da);return {since:iso(Date.UTC(y,0,1)),until:iso(t),prev:[iso(Date.UTC(y-1,0,1)),iso(last)]};}
return {since:(first||iso(t)).slice(0,10),until:iso(t),prev:null};}
const within=(d,s)=>!!d&&s[0]<=d&&d<=s[1];
function trend(now,before){if(before===null)return '';if(!before)return now?'new: nothing in the previous period':'none in either period';
const pct=(now-before)/before*100;
/* past doubling, a multiple: "▲ 3089%" says less than "▲ ×32" */
if(pct>100){const x=now/before;return '▲ ×'+(x<10?x.toFixed(1):x.toFixed(0));}
return (pct>0?'▲':pct<0?'▼':'=')+' '+Math.abs(pct).toFixed(0)+'%';}
/* short form for a badge: ▲ 12%, ▲ ×32, ▲ from 0 (nothing the period before), none */
const short=t=>/%$|×/.test(t)?t:t.startsWith('new')?'▲ from 0':t?'none':'';
const daysOf=(a,b)=>{const out=[];for(let t=at(a);t<=at(b);t+=DAY)out.push(iso(t));return out;};
const amount=(v,unit)=>unit==='tokens'?Math.round(v).toLocaleString('en-US')+' tokens':v<1?'$'+v.toFixed(4):'$'+v.toFixed(2);
const label=Object.fromEntries(P.periods.map(([k,l,c])=>[k,[l,c]]));
const keys=P.periods.map(p=>p[0]);
const listeners=[];let key=P.default;
/* the period lives in the address beside a page's other state (?period=); an older link's #p<key> still reads */
const fromHash=()=>{const q=new URLSearchParams(location.search).get('period');if(q&&keys.includes(q))return q;
const m=/^#p([a-z0-9]+)$/.exec(location.hash);return m&&keys.includes(m[1])?m[1]:null;};
/* rows: [data-key] rows of a table[data-period-rows], their runs [[day, arm]], spend [[day, usd]] and
   events [[day, html]] (the build writes that html, its names already escaped and linked) */
const R=window.PERIOD_ROWS||{};
const runsIn=(k,s)=>(R[k]&&R[k].runs||[]).filter(x=>within(x[0],s));
const evIn=(k,s)=>(R[k]&&R[k].events||[]).filter(x=>within(x[0],s)).sort((a,b)=>a[0]<b[0]?1:-1);
const usdIn=(k,s)=>(R[k]&&R[k].usd||[]).filter(x=>within(x[0],s)).reduce((a,x)=>a+x[1],0);
const tokIn=(k,s)=>(R[k]&&R[k].tokens||[]).filter(x=>within(x[0],s)).reduce((a,x)=>a+x[1],0);
function cell(el,now,before,fmt){const t=before===null?'':short(trend(now,before));
el.dataset.v=now;if(before===null)delete el.dataset.prev;else el.dataset.prev=before;/* the number never splits; its badge may take the next line, so a narrow column still fits */
el.innerHTML='<span class="nowrap">'+esc(fmt(now))+'</span>'+(t&&t!=='none'?` <small class="trend">${esc(t)}</small>`:'');}
/* a row's runs per day over the period, in its table's colour; nothing when it had none */
function line(xs){if(xs.length<2||!xs.some(Boolean))return '';const top=Math.max(...xs),step=100/(xs.length-1);
const pts=xs.map((v,i)=>`${(i*step).toFixed(1)},${(17-15*v/top).toFixed(1)}`).join(' ');
return `<svg class="rowline" viewBox="0 0 100 18" preserveAspectRatio="none" aria-hidden="true"><polygon points="0,18 ${pts} 100,18" fill="var(--c)" fill-opacity="0.16"/><polyline points="${pts}" fill="none" stroke="var(--c)" stroke-width="1.5" vector-effect="non-scaling-stroke"/></svg>`;}
let rowShow='all';
function rows(b){const s=[b.since,b.until];
document.querySelectorAll('table[data-period-rows]').forEach(t=>{let nNew=0,nAct=0;
[...t.tBodies[0].rows].forEach(r=>{const k=r.dataset.key,made=r.dataset.made||'',isNew=within(made,s);
/* the badge is tied to the name's last word by a no-break space: a long name still wraps, the badge never lands alone */
const first=r.cells[0];r.querySelectorAll('.new,.newgap').forEach(x=>x.remove());
if(isNew){const a=first.querySelector('a')||r.querySelector('td a');const html='<span class="newgap">\u00a0</span><span class="new">new</span>';if(a)a.insertAdjacentHTML('afterend',html);else first.insertAdjacentHTML('beforeend',html);}
const rs=runsIn(k,s),ev=evIn(k,s),act=rs.length>0||usdIn(k,s)>0||tokIn(k,s)>0||ev.length>0;nNew+=isNew;nAct+=act;r.classList.toggle('active',act);r.classList.toggle('isnew',isNew);
r.querySelectorAll('[data-flow]').forEach(c=>{const f=c.dataset.flow,pv=b.prev;
if(f==='runs'){cell(c,rs.length,pv?runsIn(k,pv).length:null,v=>String(v));
/* data-line: the runs per day under the number, as the datasets table draws them in a column */
if(c.hasAttribute('data-line'))c.insertAdjacentHTML('beforeend',line(daysOf(b.since,b.until).map(d=>runsIn(k,[d,d]).length)));}
else if(f==='arms'){cell(c,new Set(rs.map(x=>x[1])).size,pv?new Set(runsIn(k,pv).map(x=>x[1])).size:null,v=>String(v));
if(c.hasAttribute('data-line'))c.insertAdjacentHTML('beforeend',line(daysOf(b.since,b.until).map(d=>runsIn(k,[d,d]).length)));}
else if(f==='usd'){cell(c,usdIn(k,s),pv?usdIn(k,pv):null,v=>v?amount(v,'usd'):'—');
/* a judge's calls are spend but no run of the row's: "0 runs" beside "$13.09" says which */
const j=(R[k]&&R[k].usd||[]).filter(x=>x[2]&&within(x[0],s)).reduce((a,x)=>a+x[1],0);
if(j>0)c.insertAdjacentHTML('beforeend',`<br><small class="muted">${j>=usdIn(k,s)-1e-9?'all':esc(amount(j,'usd'))} judging</small>`);}
else if(f==='line')c.innerHTML=line(daysOf(b.since,b.until).map(d=>runsIn(k,[d,d]).length))||'<span class="muted">—</span>';
else if(f==='events')cell(c,ev.length,pv?evIn(k,pv).length:null,v=>String(v));
else if(f==='tokens')cell(c,tokIn(k,s),pv?tokIn(k,pv):null,v=>v?Math.round(v).toLocaleString('en-US'):'—');});
r.classList.toggle('pout',rowShow==='new'?!isNew:rowShow==='active'?!act:false);});
/* data-period-sort: what moved most against the period before first (up or down), then the busiest;
   with no period before (all time), the busiest */
const by=t.dataset.periodSort;if(by){const ds=r=>((r.querySelector(`[data-flow="${by}"]`)||{}).dataset||{});
const val=r=>+ds(r).v||0,moved=r=>ds(r).prev===undefined?0:Math.abs(val(r)-(+ds(r).prev||0));
[...t.tBodies[0].rows].sort((x,y)=>moved(y)-moved(x)||val(y)-val(x)).forEach(r=>t.tBodies[0].appendChild(r));}
const bar=document.querySelector(`.row-chips[data-for="${t.id}"] [data-rows]`)?.closest('.row-chips');
if(bar){bar.querySelector('[data-rows="new"] b').textContent=nNew;bar.querySelector('[data-rows="active"] b').textContent=nAct;
/* new and active the same: one chip says both */
const same=nNew===nAct,nb=bar.querySelector('[data-rows="new"]');bar.querySelector('[data-rows="active"]').hidden=same;
nb.firstChild.textContent=same?'new and active in period ':'new in period ';}
/* a filter that leaves nothing says so, in words, where the table was */
const box=t.closest('.scroll-x'),none=rowShow==='new'?!nNew:rowShow==='active'?!nAct:false;
let msg=box.nextElementSibling&&box.nextElementSibling.classList.contains('pempty')?box.nextElementSibling:null;
if(!msg){msg=document.createElement('p');msg.className='pempty muted';box.after(msg);}
msg.textContent=none?`Nothing ${rowShow==="new"?"new":"active"} in ${/^last \d/.test(label[key][0])?"the ":""}${label[key][0]}.`:'';msg.hidden=!none;box.hidden=none;
/* the text filter keeps its own rows hidden; a row out of the period's filter is hidden too */
const f=document.querySelector(`input[data-filter="${t.id}"]`);
if(f)f.dispatchEvent(new Event('input'));else{[...t.tBodies[0].rows].forEach(r=>{r.hidden=r.classList.contains('pout');});if(t._repage)t._repage();}});}
document.addEventListener('click',ev=>{const c=ev.target.closest('.row-chips button[data-rows]');if(!c)return;rowShow=c.dataset.rows;
document.querySelectorAll('.row-chips button[data-rows]').forEach(x=>x.setAttribute('aria-pressed',String(x.dataset.rows===rowShow)));show(key,false);});
/* links to the other period pages carry the period */
/* a feed table (data-period-feed) keeps the rows of the period's days */
function feeds(b){const s=[b.since,b.until];document.querySelectorAll("table[data-period-feed]").forEach(t=>{let n=0;[...t.tBodies[0].rows].forEach(r=>{const ok=within(r.dataset.made||"",s);r.hidden=!ok;n+=ok;});const none=document.querySelector(`[data-feed-empty="${t.id}"]`);if(none)none.hidden=n>0;t.closest(".scroll-x").hidden=!n;if(t._repage)t._repage();});}
function links(){document.querySelectorAll('a[data-period-link]').forEach(a=>{a.href=a.getAttribute('href').replace(/#.*$/,'')+'#p'+key;});}
function show(k,push){key=k;const b=bounds(key,today,P.first);
pick.querySelectorAll('button.chip').forEach(c=>c.setAttribute('aria-pressed',String(c.dataset.period===key)));
const more=pick.querySelector('select.more');if(more){const inMore=[...more.options].some(o=>o.value===key);more.value=inMore?key:'';more.classList.toggle('on',inMore);}
const sp=document.getElementById('period-span');if(sp){sp.textContent=b.prev?`▲▼ compared with ${label[key][1]}`:`since ${b.since}`;
sp.title=`${label[key][0]}: ${b.since} to ${b.until}`+(b.prev?`; compared with ${b.prev[0]} to ${b.prev[1]}`:'');}
if(push!==false&&history.replaceState){const q=new URLSearchParams(location.search);q.set('period',key);
history.replaceState(null,'',location.pathname+'?'+q+(/^#p[a-z0-9]+$/.test(location.hash)?'':location.hash));}
rows(b);feeds(b);links();listeners.forEach(fn=>fn(key,b));}
window.Period={DAY,iso,at,esc,today,bounds,within,trend,short,daysOf,amount,label,on:fn=>{listeners.push(fn);fn(key,bounds(key,today,P.first));},get key(){return key;}};
pick.hidden=false;pick.addEventListener('click',ev=>{const c=ev.target.closest('button.chip');if(c)show(c.dataset.period);});
pick.querySelector('select.more')?.addEventListener('change',ev=>{if(ev.target.value)show(ev.target.value);});
/* a link to the same page with another period (#p30d) changes only the hash: follow it */
addEventListener("hashchange",()=>{const k=fromHash();if(k&&k!==key)show(k,false);});
show(fromHash()||P.default,false);})();
