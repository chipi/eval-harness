/* eval catalog: the run inspector. Reads ?runs=&baseline=&metric=&rescore= and asks the local
   server (catalog_serve.py) for per-item scores, verdicts and item outputs. What an item is
   called comes from <body data-item>, the command that starts the server from <body data-serve>. */
(function () {
  // The least and the greatest of a list, by a loop: Math.min(...xs) passes every value as an argument, and at
  // 10,000 items and 40 arms (400,000 values) that overflows the call stack and the page never draws.
  // The per-item table offers "show all" up to this many items (each a row of every arm's cell).
  const SHOW_ALL = 1000;
  const minOf = xs => { let m = Infinity; for (const v of xs) if (v < m) m = v; return m; };
  const maxOf = xs => { let m = -Infinity; for (const v of xs) if (v > m) m = v; return m; };
  // Where the API answers: the page says (catalog_build --api), /api/ under evh catalog-serve.
  const API = document.body.dataset.api || '/api/';
  const ITEM = document.body.dataset.item || 'item', ITEMS = ITEM + 's';
  const SERVE = document.body.dataset.serve || 'evh catalog-serve';
  const app = document.getElementById('app'), pick = document.getElementById('pick');
  const P = new URLSearchParams(location.search);
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
  const fmt = v => v == null ? '—' : (Math.abs(v) >= 10 ? v.toFixed(1) : v.toFixed(3));
  // As every command prints a p (stats.fmt_p): four decimals, and "<0.0001" below that.
  const fmtp = p => p == null ? '—' : (p.toFixed(4) === '0.0000' ? '<0.0001' : p.toFixed(4));
  const runs = () => (P.get('runs') || '').split(',').filter(Boolean);
  const go = () => { location.search = P.toString(); };
  const short = a => a.replace(/^runs\//, '');
  const ARMS = window.RUNS || {};

  // The footer's "this page elsewhere" (catalog_build.elsewhere_line): the comparison picked (or the sheet), as the
  // operation's command and, when the deployment names its MCP server, as the tool call.
  (function elsewhere() {
    const t = document.querySelector('[data-elsewhere=term]'), m = document.querySelector('[data-elsewhere=mcp]');
    const sheet = !!P.get('sheet');
    const args = {};
    if (sheet) {
      // The sheet: the flags that filter are the signals ticked (a flag always filters in the terminal).
      args.dataset = P.get('dataset');
      const only = P.getAll('only');
      for (const k of ['runs', 'metric', 'by']) if (P.get(k)) args[k] = P.get(k);
      if (P.get('wrong') && only.includes('wrong')) args.wrong_against = P.get('wrong');
      if (P.get('new') && only.includes('new')) args.new_vs = P.get('new');
      for (const k of ['disagree', 'split', 'unlabelled']) if (only.includes(k)) args[k] = true;
      if (P.get('scores') === 'only') args.scores_only = true;
    } else {
      for (const k of ['runs', 'baseline', 'metric', 'by']) if (P.get(k)) args[k] = P.get(k);
      if (P.get('rescore') === '0') args.rescore = '0';
    }
    if (P.getAll('where').length) args.where = P.getAll('where');
    const flag = k => '--' + k.replace(/_/g, '-');
    const { dataset, ...rest } = args;  // the sheet's dataset is a word of the command, not a flag
    const opts = Object.entries(sheet ? rest : args).flatMap(([k, v]) =>
      v === true ? [flag(k)] : (Array.isArray(v) ? v : [v]).map(x => `${flag(k)} ${x}`));
    const cmd = sheet ? ['evh sheet-show', dataset, ...opts] : ['evh comparison-show', ...opts];
    if (t) t.innerHTML = `<code>${esc(cmd.filter(Boolean).join(' '))}</code>`;
    if (m) m.innerHTML = `<code>${sheet ? 'sheet-show' : 'comparison-show'}</code>` + (Object.keys(args).length ? ` with <code>${esc(JSON.stringify(args))}</code>` : '');
  })();

  // The picker. With pick.js (catalog_build.write_pick): a goal narrows the datasets, a dataset
  // lists its arms with filters and suggestions, and ticked arms open together. Without it, the
  // plain list of arm names below.
  const PK = window.PICK;
  const pk = { goal: '', ds: '', q: '', dsq: '', f: {}, ticked: new Set(runs()) };
  const armOf = r => PK.arms[r] || PK.arms[r.split('#')[0]];
  // what an arm is beside its system's others, without the particulars: "judged by X" is judged
  const howKind = h => /^judged/.test(h) ? 'judged' : /^rescored/.test(h) ? 'rescored' : String(h).split(' (')[0];
  const FACETS = [['w', 'where', a => a.w], ['h', 'how', a => howKind(a.h)], ['s', 'scored against', a => a.s]];
  function picker() { return PK ? pickerFull() : pickerPlain(); }

  function pickerFull() {
    if (!pk.ds) { const d = new Set(runs().map(r => (armOf(r) || {}).d).filter(Boolean)); if (d.size === 1) pk.ds = [...d][0]; }
    const open = !runs().length || pick.dataset.open === '1';
    const nOn = runs().length, onDs = nOn ? [...new Set(runs().map(r => (armOf(r) || {}).d || ARMS[r] || '?'))].join(', ') : '';
    pick.innerHTML = `<details class="pk"${open ? ' open' : ''}><summary>${nOn
      ? `<b>${nOn} arm${nOn > 1 ? 's' : ''}</b> on <code>${esc(onDs)}</code><span class="muted"> · change</span>`
      : '<b>Choose the arms to compare</b>'}</summary><div class="pk-body">
      <div class="pk-step"><span class="pk-n">1</span><div class="pk-main"><h3>A goal or a dataset</h3>
        <div class="pk-row"><select id="pk-goal" aria-label="goal"><option value="">every goal</option>${PK.goals.map(g =>
          `<option value="${esc(g.id)}"${g.id === pk.goal ? ' selected' : ''}>${esc(g.t)}</option>`).join('')}</select>
        <input id="pk-dsq" type="search" autocomplete="off" placeholder="filter datasets" value="${esc(pk.dsq)}" aria-label="filter datasets"></div>
        <div class="pk-ds" id="pk-ds"></div></div></div>
      <div class="pk-step" id="pk-arms"></div>
      <div class="pk-go"><span id="pk-count"></span><button class="btn" type="button" id="pk-clear">Clear</button>
        <button class="btn primary" type="button" id="pk-open">Inspect</button></div></div></details>`;
    const det = pick.querySelector('details');
    det.addEventListener('toggle', () => { pick.dataset.open = det.open ? '1' : ''; });
    document.getElementById('pk-goal').onchange = ev => { pk.goal = ev.target.value;
      const g = PK.goals.find(x => x.id === pk.goal); if (g && g.ds.length === 1) setDs(g.ds[0]); else drawDs(); };
    document.getElementById('pk-dsq').oninput = ev => { pk.dsq = ev.target.value; drawDs(); };
    document.getElementById('pk-clear').onclick = () => { pk.ticked.clear(); drawArms(); };
    document.getElementById('pk-open').onclick = () => {
      const t = [...pk.ticked]; if (!t.length) return;
      P.set('runs', t.join(','));
      // the baseline: kept when still ticked, else the dataset's promoted baseline when ticked
      const base = t.find(r => ((armOf(r) || {}).ro || []).includes('baseline'));
      if (!t.includes(P.get('baseline'))) { if (base) P.set('baseline', base); else P.delete('baseline'); }
      P.delete('sheet'); go(); };
    drawDs(); drawArms();
  }

  function setDs(ds) {
    if (ds !== pk.ds) { pk.ticked = new Set([...pk.ticked].filter(r => (armOf(r) || {}).d === ds)); pk.f = {}; pk.q = ''; }
    pk.ds = ds; drawDs(); drawArms();
  }

  function drawDs() {
    const box = document.getElementById('pk-ds'); if (!box) return;
    const g = PK.goals.find(x => x.id === pk.goal), words = pk.dsq.toLowerCase().split(/\s+/).filter(Boolean);
    const gt = id => (PK.goals.find(x => x.id === id) || {}).t || id;
    const all = Object.entries(PK.datasets).filter(([d, v]) => (!g || g.ds.includes(d))
      && words.every(w => (d + ' ' + v.g.map(gt).join(' ')).toLowerCase().includes(w)));
    const shown = all.slice(0, 60);
    box.innerHTML = shown.map(([d, v]) => `<button type="button" class="pk-dsb" data-ds="${esc(d)}" aria-pressed="${d === pk.ds}"${v.n ? '' : ' disabled'}>
      <b>${esc(d)}</b><small>${v.n} arm${v.n === 1 ? '' : 's'}${v.g.length ? ' · ' + esc(v.g.map(gt).join(', ')) : ''}</small></button>`).join('')
      + (all.length > shown.length ? `<p class="muted small">${all.length - shown.length} more: type to narrow.</p>` : '')
      + (!all.length ? '<p class="muted small">No dataset matches.</p>' : '');
    box.querySelectorAll('[data-ds]').forEach(b => b.onclick = () => setDs(b.dataset.ds));
  }

  function drawArms() {
    const box = document.getElementById('pk-arms'); if (!box) return;
    const cnt = document.getElementById('pk-count'), openb = document.getElementById('pk-open');
    const n = pk.ticked.size, over = n > PK.max;
    // what is ticked, by name, so a filter that hides a ticked arm never hides that it is ticked
    const named = [...pk.ticked].slice(0, 8).map(r => { const a = armOf(r);
      return `<span class="chip pickchip" title="${esc(r)}">${esc(a ? a.c + (a.h === 'measured' ? '' : ' · ' + howKind(a.h)) : short(r))}<button type="button" data-untick="${esc(r)}" aria-label="untick">×</button></span>`; }).join('');
    cnt.innerHTML = n ? `<b>${n} ticked</b>${over ? ` <span class="muted">(the inspector opens at most ${PK.max})</span>` : ''} ${named}${n > 8 ? ` <span class="muted">+${n - 8}</span>` : ''}` : 'nothing ticked';
    cnt.querySelectorAll('[data-untick]').forEach(b => b.onclick = () => { pk.ticked.delete(b.dataset.untick); drawArms(); });
    openb.textContent = n ? `Inspect ${n} arm${n > 1 ? 's' : ''}` : 'Inspect';
    openb.disabled = !n || over;
    if (!pk.ds) { box.innerHTML = '<span class="pk-n">2</span><div class="pk-main"><h3>Its arms</h3><p class="muted">Pick a dataset above: the inspector compares arms on one dataset.</p></div>'; return; }
    const mine = Object.entries(PK.arms).filter(([, a]) => a.d === pk.ds);
    const words = pk.q.toLowerCase().split(/\s+/).filter(Boolean);
    const pass = ([r, a]) => words.every(w => [r, a.c, a.m, a.r, a.h].join(' ').toLowerCase().includes(w))
      && FACETS.every(([k, , get]) => !(pk.f[k] && pk.f[k].size) || pk.f[k].has(get(a)));
    const shown = mine.filter(pass);
    const chips = FACETS.map(([k, name, get]) => { const vs = [...new Set(mine.map(([, a]) => get(a)))].filter(Boolean).sort();
      return vs.length < 2 ? '' : `<span class="pk-facet"><span class="muted small">${name}</span>${vs.map(v =>
        `<button type="button" class="chip" data-f="${k}" data-v="${esc(v)}" aria-pressed="${!!(pk.f[k] && pk.f[k].has(v))}">${esc(v)}</button>`).join('')}</span>`; }).join('');
    // Suggestions: the dataset's roles, then what the ticked arms point to.
    const sug = [];
    for (const role of ['baseline', 'leader', 'recommended']) {
      const hit = mine.filter(([r, a]) => a.ro.includes(role) && !pk.ticked.has(r));
      if (hit.length) sug.push([`the ${role}${hit.length > 1 ? 's' : ''}: ${hit.map(([, a]) => a.c).join(', ')}`, hit.map(([r]) => r)]);
    }
    const t = [...pk.ticked].map(r => armOf(r)).filter(Boolean);
    const cfgs = new Set(t.map(a => a.c)), models = new Set(t.map(a => a.m).filter(Boolean));
    const same = mine.filter(([r, a]) => !pk.ticked.has(r) && cfgs.has(a.c));
    if (same.length) sug.push([`the same system${cfgs.size > 1 ? 's' : ''}, scored other ways (${same.length})`, same.map(([r]) => r)]);
    const sib = mine.filter(([r, a]) => !pk.ticked.has(r) && a.m && models.has(a.m) && !cfgs.has(a.c));
    if (sib.length) sug.push([`the same model${models.size > 1 ? 's' : ''} in other systems (${sib.length})`, sib.map(([r]) => r)]);
    const cap = shown.slice(0, 400), was = box.querySelector('.pk-list'), top = was ? was.scrollTop : 0;
    box.innerHTML =`<span class="pk-n">2</span><div class="pk-main"><h3>Its arms <span class="muted">on <code>${esc(pk.ds)}</code>, ${mine.length}</span></h3>
      <div class="pk-row"><input id="pk-q" type="search" autocomplete="off" placeholder="filter: system, model, how" value="${esc(pk.q)}" aria-label="filter arms">
      <button class="btn small" type="button" id="pk-all">${shown.length > PK.max ? `Tick the first ${PK.max} of ${shown.length} shown` : `Tick the ${shown.length} shown`}</button></div>
      ${chips ? `<div class="pk-facets">${chips}</div>` : ''}
      ${sug.length ? `<div class="pk-sug"><span class="muted small">add</span>${sug.map(([l], i) => `<button type="button" class="chip pk-add" data-sug="${i}">+ ${esc(l)}</button>`).join('')}</div>` : ''}
      <div class="pk-list" role="group" aria-label="arms">${cap.map(([r, a]) => `<label class="pk-arm"><input type="checkbox" value="${esc(r)}"${pk.ticked.has(r) ? ' checked' : ''}>
        <span class="pk-c">${esc(a.c)}${a.ro.length ? `<em>${esc(a.ro.join(', '))}</em>` : ''}</span><span class="pk-m">${esc(a.m || '—')} · ${esc(a.w)}</span>
        <span class="pk-h">${esc(a.h)}</span><span class="pk-v">${a.v == null ? '' : esc(a.ms) + ' ' + fmt(a.v)}</span></label>`).join('')
        || '<p class="muted small">No arm matches.</p>'}${shown.length > cap.length ? `<p class="muted small">${shown.length - cap.length} more: filter to narrow.</p>` : ''}</div></div>`;
    box.querySelector('.pk-list').scrollTop = top;
    const q = document.getElementById('pk-q');
    q.oninput = ev => { pk.q = ev.target.value; drawArms(); const i = document.getElementById('pk-q'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); };
    document.getElementById('pk-all').onclick = () => { shown.slice(0, PK.max).forEach(([r]) => pk.ticked.add(r)); drawArms(); };
    box.querySelectorAll('[data-f]').forEach(b => b.onclick = () => { const s = pk.f[b.dataset.f] = pk.f[b.dataset.f] || new Set();
      s.has(b.dataset.v) ? s.delete(b.dataset.v) : s.add(b.dataset.v); drawArms(); });
    box.querySelectorAll('[data-sug]').forEach(b => b.onclick = () => { sug[+b.dataset.sug][1].forEach(r => pk.ticked.add(r)); drawArms(); });
    box.querySelectorAll('.pk-list input').forEach(c => c.onchange = () => { c.checked ? pk.ticked.add(c.value) : pk.ticked.delete(c.value); drawArms(); });
  }

  function pickerPlain() {
    const chips = runs().map(r => `<span class="chip pickchip">${esc(short(r))}<button data-rm="${esc(r)}" aria-label="remove">×</button></span>`).join('');
    // Only offer runs that can be compared with what is selected: same dataset_id, or none recorded.
    const all = ARMS, ds = new Set(runs().map(r => all[r] || all[r.split('#')[0]]).filter(Boolean));
    const on = ds.size === 1 ? [...ds][0] : '';
    const opts = Object.entries(all).filter(([r, d]) => !on || !d || d === on)
      .map(([r, d]) => `<option value="${esc(r)}" label="${esc(d || 'no dataset id')}">`).join('');
    const hint = on ? `add a run on ${on}` : 'add a run: type part of its name';
    pick.innerHTML = `<div class="chips">${chips || '<span class="muted">No runs selected.</span>'}</div>
      <form id="add" class="filter"><input list="allruns" id="addrun" placeholder="${esc(hint)}" autocomplete="off">
      <datalist id="allruns">${opts}</datalist><button class="btn" type="submit">Add</button></form>`;
    pick.querySelectorAll('[data-rm]').forEach(b => b.onclick = () => {
      P.set('runs', runs().filter(r => r !== b.dataset.rm).join(',')); P.delete('baseline'); go(); });
    document.getElementById('add').onsubmit = ev => { ev.preventDefault();
      const v = document.getElementById('addrun').value.trim(); if (!v) return;
      P.set('runs', [...new Set([...runs(), v])].join(',')); go(); };
  }

  // Strip what every selected run's label shares, at a _ / · boundary; the full name stays in a tooltip.
  function shorten(full) {
    const ids = Object.keys(full), names = ids.map(i => full[i]);
    if (names.length < 2) return full;
    const cut = (a, b) => { let i = 0; while (i < a.length && i < b.length && a[i] === b[i]) i++; return i; };
    let pre = names.reduce((n, x) => Math.min(n, cut(names[0], x)), Infinity);
    pre = names[0].slice(0, pre).search(/[_\/·][^_\/·]*$/) + 1;
    const rev = names.map(x => [...x].reverse().join(''));
    let suf = rev.reduce((n, x) => Math.min(n, cut(rev[0], x)), Infinity);
    // A shared tail is cut only at a " · " (what they are scored by), never inside the system
    // id: "_v1" is the arm's version, and it stays when every arm happens to share it.
    const tail = suf ? names[0].slice(names[0].length - suf) : '';
    const at = tail.indexOf(' · ');
    suf = at >= 0 ? tail.length - at : 0;
    const out = {};
    ids.forEach((id, k) => { const s = names[k].slice(Math.max(pre, 0), names[k].length - suf) || names[k]; out[id] = s; });
    return out;
  }
  const tip = (full, id) => `title="${esc(full[id] || id)}"`;
  // The catalog's own pages, as catalog_build.slug names them: an arm's and a metric's.
  const slug = s => String(s).replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'x';
  const UP = document.body.dataset.up || '';
  const armName = (id, text) => window.CATALOG_PAGES
    ? `<a class="cell-link" href="${UP}a/${slug(id)}.html" title="${esc(id)}">${esc(text)}</a>` : esc(text);

  function verdictChip(v) {
    const cls = v.startsWith('significant: better') ? 'v-better' : v.startsWith('significant: worse') ? 'v-worse' : 'v-none';
    const sym = cls === 'v-better' ? '▲ ' : cls === 'v-worse' ? '▼ ' : '';
    return `<span class="chip ${cls}">${sym}${esc(v)}</span>`;
  }

  async function load() {
    if (P.get('sheet') && P.get('dataset')) return sheetView();
    picker();
    if (!runs().length) { app.innerHTML = '<p class="muted">' + (PK ? 'Choose arms above, ' : 'Add runs above, ') + 'or open them from a goal, dataset or arm page in the catalog ("Inspect it", "test vs leader").</p>'; return; }
    let d;
    try {
      const r = await fetch(API + 'compare?' + P.toString());
      d = await r.json();
    } catch (e) {
      app.innerHTML = `<p class="note"><b>No inspector server.</b> Start it with <code>${esc(SERVE)}</code> and open this page from the address it prints.</p>`;
      return;
    }
    if (d.error) { app.innerHTML = `<p class="note"><b>${esc(d.error)}</b></p>`; return; }
    const label = shorten(Object.fromEntries((d.arms || []).map(a => [a.id, a.label])));
    const warn = (d.warnings || []).map(w => `<p class="note">${esc(w)}</p>`).join('');
    if (!d.metrics || !d.metrics.length || d.state === 'not scorable') {
      const pickable = (d.metrics || []).map(m => `<a class="btn" href="?${new URLSearchParams({...Object.fromEntries(P), metric: m.name})}">compare ${esc(m.name)}</a>`).join('');
      const on = new URLSearchParams(P); on.delete('rescore');
      const again = !d.can_rescore || P.get('rescore') !== '0' ? '' : `<a class="btn" href="?${on}">Re-score with the project's scorers</a>`;
      app.innerHTML = `<p class="eyebrow"><span class="num">—</span>not scorable</p>` + warn + `<div class="btns">${again}${pickable}</div>`;
      return;
    }
    const arrow = d.higher_is_better ? '↑ higher is better' : '↓ lower is better';
    const mopts = d.metrics.map(m => `<option value="${esc(m.name)}" ${m.name === d.metric ? 'selected' : ''}>${esc(m.name)}${m.format ? ' (' + esc(m.format) + ')' : ''}${m.archived ? ' (archived reference)' : ''} ${m.lower_is_better ? '↓' : '↑'} · ${m.arms} arm(s)</option>`).join('');
    const bopts = Object.keys(d.series).map(a => `<option value="${esc(a)}" ${a === d.baseline ? 'selected' : ''}>${esc(label[a] || a)}</option>`).join('');
    const resc = P.get('rescore') !== '0';
    const controls = `<div class="controls">
      <label>metric <select id="metric">${mopts}</select></label>
      <label>baseline <select id="baseline">${bopts}</select></label>
      ${d.can_rescore ? `<label class="tick"><input type="checkbox" id="rescore" ${resc ? 'checked' : ''}> re-score what is not on record</label>` : ''}
      <label class="tick"><input type="checkbox" id="disagree" ${P.get('disagree') ? 'checked' : ''}> only where they disagree</label></div>`
      + scoredAgainst(d) + fieldControls(d);

    const rows = [...d.rows].sort((a, b) => (a.p ?? 9) - (b.p ?? 9));
    // A row's tint says what its scores are measured against, as on the catalog's pages.
    const kind = id => { const a = (d.arms || []).find(x => x.id === id) || {};
      return a.wrote_reference ? 't-author' : a.judge ? 't-judged' : (a.reference || '').startsWith('silver/') ? 't-silver' : ''; };
    // The verdict is the second column, so a phone sees it without scrolling.
    const author = id => ((d.arms || []).find(x => x.id === id) || {}).wrote_reference ? ' <small class="muted">wrote the reference</small>' : '';
    const vt = rows.map(r => `<tr class="${kind(r.arm)}"><td class="mono">${armName(r.arm, label[r.arm] || r.arm)}${author(r.arm)}</td>
      <td>${verdictChip(r.verdict)}${r.n && r.min_p > 0.05 ? ' <small class="muted">' + r.n + ' ' + ITEMS + ' cannot reach 0.05</small>' : ''}</td>
      <td class="num">${r.n}</td><td class="num">${fmt(r.mean)}</td><td class="num">${fmt(r.delta)}</td>
      <td class="num">${r.ci ? (r.ci[0] >= 0 ? '+' : '') + r.ci[0].toFixed(3) + ' to ' + (r.ci[1] >= 0 ? '+' : '') + r.ci[1].toFixed(3) : '—'}</td>
      <td class="num">${r.wins}–${r.losses}${r.ties ? ' (' + r.ties + ' ties)' : ''}</td>
      <td class="num">${fmtp(r.p)}</td><td class="num">${r.threshold ? r.threshold.toFixed(4) : '—'}</td></tr>`).join('');
    const baseMean = d.items.length ? (() => { const v = Object.values(d.series[d.baseline]); return v.reduce((a, b) => a + b, 0) / v.length; })() : null;
    const verdicts = `<div class="scroll-x"><table class="data" data-nopage><thead><tr><th>run vs baseline</th><th>verdict</th><th>${ITEMS}</th><th>mean</th><th>Δ vs baseline</th><th>95% CI of Δ</th><th>wins–losses</th><th>p (exact ≤30)</th><th>Holm threshold</th></tr></thead>
      <tbody>${vt || '<tr><td colspan="9" class="muted">Only the baseline has this metric.</td></tr>'}</tbody></table></div>
      <p class="small muted">Baseline ${armName(d.baseline, label[d.baseline] || d.baseline)}: mean ${fmt(baseMean)}. Holm across ${d.family_size} comparison(s)${P.get('threshold') ? ' (this row\'s threshold carried from the page you came from, so the verdict matches it)' : P.get('family') ? ' (family carried from the page you came from)' : ''}; ${esc(arrow)}. Scores come from: ${esc([...new Set(d.arms.map(a => a.source).filter(Boolean))].join('; '))}.</p>`;

    const arms = Object.keys(d.series), better = d.higher_is_better ? 1 : -1;
    const head = arms.map(a => `<th class="${a === d.baseline ? 'isbase' : ''}">${esc(label[a] || a)}${a === d.baseline ? '<br><small>baseline</small>' : ''}</th>`).join('');
    const rowOf = ep => `<tr data-ep="${esc(ep)}" class="eprow" tabindex="0" aria-label="open ${ITEM} ${esc(ep)}"><td class="mono" title="${esc(ep)}">${esc(ep)}</td>${arms.map(a => {
      const v = d.series[a][ep], b = d.series[d.baseline][ep];
      if (v == null) return '<td class="num muted">—</td>';
      let mark = '';
      if (a !== d.baseline && b != null && v !== b) mark = (v - b) * better > 0 ? ' <span class="up">▲</span>' : ' <span class="down">▼</span>';
      return `<td class="num">${fmt(v)}${mark}</td>`; }).join('')}</tr>`;
    // Only the rows shown are drawn (10 at first, as the catalog's pager shows them): at 10,000 items and 40 arms the
    // whole table was 3.2 million elements. "show all" is offered up to SHOW_ALL items; past that, a thousand more.
    const eps = `<div class="scroll-x"><table class="data eps" data-nopage><thead><tr><th>${ITEM}</th>${head}</tr></thead><tbody></tbody></table></div>
      <p class="pager small muted" id="eps-pager"></p>
      <p class="small muted">▲ better / ▼ worse than the baseline on that ${ITEM}. Click a row to see the outputs.</p><div id="drill"></div>`;

    // Runs that recorded only a run-level average: listed, never tested.
    const avgs = Object.entries(d.averages || {}).sort((a, b) => (d.higher_is_better ? b[1] - a[1] : a[1] - b[1]));
    const avgTable = !avgs.length ? '' : `<h3 class="sub">Average only · ${avgs.length}: no per-${ITEM} scores, so no test</h3>
      <div class="scroll-x"><table class="data"><thead><tr><th>run</th><th>recorded average</th><th>vs the baseline's mean</th></tr></thead><tbody>${avgs.map(([a, v]) =>
        `<tr><td class="mono">${armName(a, label[a] || a)}</td><td class="num">${fmt(v)}</td><td class="num">${baseMean == null ? '—' : (v - baseMean >= 0 ? '+' : '') + fmt(v - baseMean)}</td></tr>`).join('')}</tbody></table></div>`;
    const mslug = slug(d.metric.split(' vs ')[0]);
    // The metric's own page where the catalog has one; else its row on a metrics page; else plain.
    const mlink = window.CATALOG_PAGES ? `<a class="cell-link" href="${UP}m/${mslug}.html">${esc(d.metric)}</a>`
      : document.querySelector('nav.nav a[href$="metrics.html"]')
      ? `<a class="cell-link" href="${UP}metrics.html#m-${mslug}">${esc(d.metric)}</a>` : esc(d.metric);
    app.innerHTML = controls + warn + `<p class="eyebrow"><span class="num">01</span>verdicts · ${mlink}</p>` + verdicts + conditions(d, label) + avgTable
      + breakdown(d, label)
      + `<p class="eyebrow gap"><span class="num">02</span>analysis</p>` + charts(d, label)
      + `<p class="eyebrow gap"><span class="num">03</span>per ${ITEM} · ${d.items.length}</p>` + eps;
    wireCharts(d, label);
    wireFields(d);
    // Long tables (the per-item one) page 10 at a time; the verdict tables stay whole (data-nopage).
    if (window.paginate) app.querySelectorAll('table.data').forEach(t => window.paginate(t));
    document.getElementById('metric').onchange = ev => { P.set('metric', ev.target.value); go(); };
    document.getElementById('baseline').onchange = ev => { P.set('baseline', ev.target.value); go(); };
    document.getElementById('disagree').onchange = ev => { ev.target.checked ? P.set('disagree', '1') : P.delete('disagree'); go(); };
    const rs = document.getElementById('rescore');
    if (rs) rs.onchange = ev => { ev.target.checked ? P.delete('rescore') : P.set('rescore', '0'); go(); };
    // The reference the metric names ("<metric> vs <reference>"), else the one the baseline was scored against.
    const ref = (d.metric.split(' vs ')[1] || '').trim() || ((d.arms || []).find(a => a.id === d.baseline) || {}).reference || '';
    const tb = app.querySelector('table.eps tbody'), pager = document.getElementById('eps-pager');
    let drawn = 0;
    const draw = upto => {
      upto = Math.min(upto, d.items.length);
      if (upto > drawn) {
        tb.insertAdjacentHTML('beforeend', d.items.slice(drawn, upto).map(rowOf).join(''));
        [...tb.rows].slice(drawn).forEach(tr => {
          tr.onclick = () => drill(tr.dataset.ep, arms, d.baseline, label, ref, tr, {metric: d.metric, series: d.series});
          tr.onkeydown = ev => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); tr.onclick(); } };
        });
        drawn = upto;
      }
      const n = d.items.length, more = n <= SHOW_ALL ? n - drawn : Math.min(1000, n - drawn);
      pager.hidden = n <= 10;
      pager.innerHTML = `Showing ${drawn} of ${n}` + (drawn < n ? ` <button type="button" class="btn small" data-more>show ${Math.min(10, n - drawn)} more</button>`
        + `<button type="button" class="btn small" data-bulk>${n <= SHOW_ALL ? 'show all' : 'show ' + more + ' more'}</button>` : '');
    };
    pager.onclick = ev => { const b = ev.target.closest('button'); if (!b) return;
      draw('more' in b.dataset ? drawn + 10 : n_bulk()); };
    const n_bulk = () => d.items.length <= SHOW_ALL ? d.items.length : drawn + 1000;
    // ?item=<id>: a dataset page's "inspect" link opens that item (when the arms share it): drawn down to it.
    const want = P.get('item');
    const at = want ? d.items.indexOf(want) : -1;
    draw(Math.max(10, at + 1));
    const hit = at >= 0 && [...tb.rows].find(tr => tr.dataset.ep === want);
    if (hit) hit.onclick();
    else if (want) document.getElementById('drill').innerHTML = `<p class="note">${esc(ITEM)} ${esc(want)} is not among the ${ITEMS} these arms share.</p>`;
  }


  // What the chosen arms' scores are read against (RFC-023): a reference with its tier pill, a label set with its
  // source chip. Arms against different ones are set aside by the server, as for two references.
  const pill = t => (t === 'gold' || t === 'silver') ? `<span class="pill tier-${t}">${t}</span>` : esc(t || '');
  const chip = k => `<span class="src src-${['person', 'model', 'rule'].includes(k) ? k : 'unknown'}">${esc(k || 'unknown')}</span>`;
  function against(a) {
    const r = a.reference || '';
    if (a.judge) return `judge <code>${esc(a.judge)}</code>`;
    const by = a.reference_author ? ` <span class="muted">written by <code>${esc(a.reference_author)}</code>; that arm is graded against its own output</span>` : '';
    if (r.startsWith('labels/')) return `${chip(a.labels_source)} <code>${esc(r.slice(7).split('/').pop())}</code>${by}`;
    return r ? `<code>${esc(r)}</code> ${pill(r.split('/')[0])}${by}` : 'nothing';
  }
  function scoredAgainst(d) {
    const seen = [...new Map((d.arms || []).map(a => [a.judge || a.reference || '', a])).values()];
    return seen.length ? `<p class="small">scored against: ${seen.map(against).join(' · ')}</p>` : '';
  }

  // ── item fields (ADR-0003): filter the comparison, break it down by a choice or yes/no field ─
  function fieldControls(d) {
    const fs = d.fields || [];
    if (!fs.length) return '';
    const chips = P.getAll('where').map(w => { const [n, v] = [w.slice(0, w.indexOf(':')), w.slice(w.indexOf(':') + 1)];
      const f = fs.find(x => x.name === n) || {};
      return `<span class="chip pickchip">${esc(f.label || n)} = ${esc(v)}<button data-unwhere="${esc(w)}" aria-label="remove filter">×</button></span>`; }).join('');
    const fopts = fs.map(f => `<option value="${esc(f.name)}">${esc(f.label)}</option>`).join('');
    const bopts = '<option value="">none</option>' + fs.filter(f => f.groupable).map(f =>
      `<option value="${esc(f.name)}" ${P.get('by') === f.name ? 'selected' : ''}>${esc(f.label)}</option>`).join('');
    return `<div class="controls">
      <form id="addwhere" class="filter"><label>filter ${ITEMS} by <select id="wfield">${fopts}</select></label>
        <span id="wvalue"></span><button class="btn small" type="submit">Filter</button></form>
      ${fs.some(f => f.groupable) ? `<label>break down by <select id="by">${bopts}</select></label>` : ''}</div>`
      + (chips ? `<div class="chips">${chips}</div>` : '');
  }

  function valueInput(f) {
    if (f.type === 'choice') return `<select id="wv">${(f.values || []).map(v => `<option>${esc(v)}</option>`).join('')}</select>`;
    if (f.type === 'boolean') return '<select id="wv"><option value="true">yes</option><option value="false">no</option></select>';
    const hint = ['number', 'integer', 'duration'].includes(f.type)
      ? (f.type === 'duration' ? 'seconds: 600..  or  ..1800' : 'min..max, or one value') : 'exact value';
    return `<input id="wv" placeholder="${esc(hint)}" autocomplete="off">`;
  }

  function wireFields(d) {
    const fs = d.fields || [], sel = document.getElementById('wfield');
    if (!sel) return;
    const show = () => { document.getElementById('wvalue').innerHTML = valueInput(fs.find(f => f.name === sel.value) || {}); };
    sel.onchange = show; show();
    document.getElementById('addwhere').onsubmit = ev => { ev.preventDefault();
      const v = (document.getElementById('wv').value || '').trim(); if (!v) return;
      P.append('where', sel.value + ':' + v); go(); };
    app.querySelectorAll('[data-unwhere]').forEach(b => b.onclick = () => {
      const keep = P.getAll('where').filter(w => w !== b.dataset.unwhere); P.delete('where'); keep.forEach(w => P.append('where', w)); go(); });
    const by = document.getElementById('by');
    if (by) by.onchange = () => { by.value ? P.set('by', by.value) : P.delete('by'); go(); };
  }

  // What the compared runs were measured under, from their fingerprints: one line when it all
  // matches, else the fields that differ, arm by arm, and what that does to the comparison.
  function conditions(d, label) {
    const c = d.conditions;
    if (!c || !c.fields) return '';
    const what = 'machine, library versions, harness, scorer, items, reference bytes';
    if (!c.differ.length) return `<p class="small muted conds">Same conditions: all ${c.fields} recorded fields match across these runs (${what}).</p>`;
    const arms = Object.keys(d.series);
    const short = v => v == null ? '—' : /^[0-9a-f]{40,}$/.test(v) ? v.slice(0, 12) + '…' : v;
    const head = arms.map(a => `<th>${esc(label[a] || a)}${a === d.baseline ? '<br><small>baseline</small>' : ''}</th>`).join('');
    const body = c.differ.map(f => {
      const base = f.values[d.baseline];
      return `<tr><td class="mono">${esc(f.name)}</td>${arms.map(a => `<td class="mono${a !== d.baseline && f.values[a] !== base ? ' diff' : ''}" title="${esc(f.values[a] ?? '')}">${esc(short(f.values[a]))}</td>`).join('')}</tr>`;
    }).join('');
    const warns = (c.warnings || []).map(w => `<p class="note">${esc(w)}</p>`).join('');
    return `<h3 class="sub">Conditions · ${c.differ.length} of ${c.fields} fields differ <small>(${what})</small></h3>`
      + warns
      + `<div class="scroll-x"><table class="data conds"><thead><tr><th>field</th>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
  }

  function breakdown(d, label) {
    const b = d.breakdown;
    if (!b) return '';
    const f = (d.fields || []).find(x => x.name === d.by) || {label: d.by};
    const name = g => f.type === 'boolean' ? (g === 'true' ? 'yes' : 'no') : g;
    const rows = b.groups.flatMap(g => g.rows.map(r => `<tr><td>${esc(name(g.group))} <small class="muted">${g.items} ${ITEMS}</small></td>
      <td class="mono">${armName(r.arm, label[r.arm] || r.arm)}</td><td>${verdictChip(r.verdict)}${r.n && r.min_p > 0.05 ? ' <small class="muted">' + r.n + ' ' + ITEMS + ' cannot reach 0.05</small>' : ''}</td><td class="num">${r.n}</td>
      <td class="num">${fmt(r.delta)}</td><td class="num">${r.wins}–${r.losses}</td><td class="num">${fmtp(r.p)}</td>
      <td class="num">${r.threshold ? r.threshold.toFixed(4) : '—'}</td></tr>`)).join('');
    return `<h3 class="sub">By ${esc(f.label)} · ${b.groups.length} group(s)</h3>
      <div class="scroll-x"><table class="data" data-nopage><thead><tr><th>${esc(f.label)}</th><th>run vs baseline</th><th>verdict</th><th>${ITEMS}</th><th>Δ vs baseline</th><th>wins–losses</th><th>p</th><th>Holm threshold</th></tr></thead>
      <tbody>${rows || '<tr><td colspan="8" class="muted">No group has two arms to test.</td></tr>'}</tbody></table></div>
      <p class="small muted">The same paired test within each group, Holm-corrected over all ${b.family_size} tests together: each extra group is another chance of a false "significant", so the thresholds are stricter than for one group alone.</p>`;
  }

  function fieldsTable(fs) {
    if (!fs || !fs.length) return '';
    // Returns HTML: every value escaped; a link only for an http(s) URL (an adapter's own data
    // could carry any scheme, and a javascript: href would run on click).
    const clock = v => { const s = Math.round(v); return `${Math.floor(s / 3600)}:${String(Math.floor(s % 3600 / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };
    const show = f => f.type === 'boolean' ? (f.value ? 'yes' : 'no')
      : f.type === 'duration' && typeof f.value === 'number' ? clock(f.value)
      : f.type === 'url' && /^https?:\/\//i.test(String(f.value)) ? `<a href="${esc(f.value)}" rel="noopener noreferrer" target="_blank">${esc(f.value)}</a>`
      : esc(f.value) + (f.unit ? ' ' + esc(f.unit) : '');
    return `<table class="data fields"><tbody>${fs.map(f => `<tr><th>${esc(f.label)}</th><td>${show(f)}</td></tr>`).join('')}</tbody></table>`;
  }

  // ── charts: inline SVG, the catalog's tokens; colours follow the run, never its rank ─────────
  const SLOTS = 8;
  function colorOf(d) {
    const out = {}; let i = 0;
    Object.keys(d.series).forEach(a => {
      if (a === d.baseline) out[a] = 'var(--baseline)';
      else out[a] = i < SLOTS ? `var(--s${++i})` : 'var(--muted)';
    });
    return out;
  }
  // Below 700px the charts use a narrow layout: labels sit above each row and values at its end.
  const NARROW = window.matchMedia('(max-width: 700px)').matches;
  const W = NARROW ? 420 : 1000, LEFT = NARROW ? 8 : 250, RIGHT = NARROW ? 8 : 30;
  const ROW = NARROW ? 46 : 34;
  // A value printed at the end of a row: right of the plot when wide, on the label line when narrow.
  const rowValue = (y, xWide, text) => NARROW
    ? `<text class="rv" x="${W - RIGHT}" y="${y - 13}" text-anchor="end">${text}</text>`
    : `<text class="rv" x="${xWide}" y="${y + 4}">${text}</text>`;
  function scale(lo, hi, a, b) { const span = hi - lo || 1; return v => a + (v - lo) / span * (b - a); }
  function ticks(lo, hi, n = 5) {
    const raw = (hi - lo) / n || 1, mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const step = [1, 2, 2.5, 5, 10].map(m => m * mag).find(s => s >= raw);
    const out = []; for (let t = Math.ceil(lo / step) * step; t <= hi + 1e-12; t += step) out.push(+t.toFixed(10));
    return out;
  }
  const tfmt = v => Math.abs(v) >= 100 ? v.toFixed(0) : Math.abs(v) >= 10 ? v.toFixed(1) : +v.toFixed(3) + '';
  function axis(x, lo, hi, top, bottom) {
    return ticks(lo, hi).map(t => `<line class="grid" x1="${x(t)}" x2="${x(t)}" y1="${top}" y2="${bottom}"/>
      <text class="tick" x="${x(t)}" y="${bottom + 16}" text-anchor="middle">${tfmt(t)}</text>`).join('');
  }
  function rowLabel(y, text, full, color) {
    const max = NARROW ? 40 : 34, t = text.length > max ? text.slice(0, max - 1) + '…' : text;
    const ly = NARROW ? y - 13 : y + 4, cy = NARROW ? y - 17 : y;
    return `<g><title>${esc(full)}</title><circle cx="${NARROW ? 5 : 12}" cy="${cy}" r="5" fill="${color}"/>
      <text class="rl" x="${NARROW ? 14 : 24}" y="${ly}">${esc(t)}</text></g>`;
  }
  const dot = (cx, cy, color, tip, r = 4.5) =>
    `<circle class="dot" cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="${r}" fill="${color}" data-tip="${esc(tip)}"><title>${esc(tip)}</title></circle>`;
  const mean = xs => xs.reduce((a, b) => a + b, 0) / xs.length;
  // Past DOTS_MAX values a row draws BINS shaded bins instead of a dot each (PLAN_0.8.0 S3, charts from bins): at
  // 10,000 items and 40 arms the three charts were 1.2 million dots, each with its tooltip.
  const DOTS_MAX = 500, BINS = 60;
  function binRow(values, x, lo, hi, y, color, what) {
    const w = (hi - lo) / BINS, counts = new Array(BINS).fill(0);
    for (const v of values) counts[Math.min(BINS - 1, Math.max(0, Math.floor((v - lo) / w)))]++;
    const most = maxOf(counts) || 1;
    return counts.map((c, i) => !c ? '' : `<rect class="bin" x="${x(lo + i * w).toFixed(1)}" y="${(y - 9).toFixed(1)}" `
      + `width="${Math.max(1, x(lo + (i + 1) * w) - x(lo + i * w)).toFixed(1)}" height="18" fill="${color}" `
      + `fill-opacity="${(0.12 + 0.88 * c / most).toFixed(2)}"><title>${esc(what)}: ${c} ${c === 1 ? ITEM : ITEMS} `
      + `from ${tfmt(lo + i * w)} to ${tfmt(lo + (i + 1) * w)}</title></rect>`).join('');
  }
  const binNote = `; past ${DOTS_MAX} ${ITEMS} a run, shaded bins instead of dots: the darker, the more ${ITEMS}`;
  // deterministic vertical jitter so tied scores stay visible
  const jit = (ep, k) => { let h = 0; for (const c of ep + k) h = (h * 31 + c.charCodeAt(0)) % 997; return (h / 997 - 0.5) * 12; };

  // A time per item (latency_ms, seconds): its median and 95th percentile are marked on the spread (RFC-034).
  const LATENCY = /latency|_ms$|seconds/i;
  function spread(d, label, col) {
    const mu = a => mean(Object.values(d.series[a]));
    const dirn = d.higher_is_better || d.neutral ? -1 : 1;
    const others = Object.keys(d.series).filter(a => a !== d.baseline).sort((a, b) => dirn * (mu(a) - mu(b)));
    const arms = [d.baseline, ...others];
    const vals = arms.flatMap(a => Object.values(d.series[a]));
    if (!vals.length) return '';
    let lo = minOf(vals), hi = maxOf(vals); const pad = (hi - lo) * 0.06 || 0.05; lo -= pad; hi += pad;
    const RH = ROW, top = NARROW ? 30 : 14, H = top + arms.length * RH + 30, x = scale(lo, hi, LEFT, W - RIGHT - (NARROW ? 0 : 80));
    const bm = mean(Object.values(d.series[d.baseline]));
    let g = axis(x, lo, hi, top - 6, top + arms.length * RH);
    g += `<line class="basemean" x1="${x(bm)}" x2="${x(bm)}" y1="${top - 6}" y2="${top + arms.length * RH}"/>`;
    arms.forEach((a, i) => {
      const y = top + i * RH + RH / 2, v = d.series[a], ys = Object.values(v);
      g += rowLabel(y, label[a] || a, a, col[a]);
      g += ys.length > DOTS_MAX ? binRow(ys, x, lo, hi, y, col[a], label[a] || a)
        : Object.entries(v).map(([ep, s]) => dot(x(s), y + jit(ep, a), col[a], `${label[a] || a} · ${ep}: ${tfmt(s)}`)).join('');
      if (ys.length && LATENCY.test(d.metric)) {
        // linear between the closest ranks, as the leaderboard's speed column and `evh chart latency` (axes.percentile)
        const sorted = [...ys].sort((p, q) => p - q), at = f => { const pos = f * (sorted.length - 1), lo = Math.floor(pos), hi = Math.ceil(pos); return sorted[lo] + (sorted[hi] - sorted[lo]) * (pos - lo); };
        for (const [f, nm] of [[0.5, 'p50'], [0.95, 'p95']]) g += `<line class="ci" x1="${x(at(f))}" x2="${x(at(f))}" y1="${y - 8}" y2="${y + 8}" stroke="var(--ink)" stroke-width="2" data-tip="${esc((label[a] || a) + ' ' + nm + ' ' + tfmt(at(f)))}"/><text class="tick" x="${x(at(f))}" y="${y - 10}" text-anchor="middle" font-size="10">${nm}</text>`;
      }
      if (ys.length) g += `<line class="meanmark" x1="${x(mean(ys))}" x2="${x(mean(ys))}" y1="${y - 11}" y2="${y + 11}" data-tip="${esc((label[a] || a) + ' mean ' + tfmt(mean(ys)))}"/>`
        + rowValue(y, W - RIGHT - 66, tfmt(mean(ys)));
    });
    return `<figure class="chart"><figcaption><b>Spread per run</b> · every ${ITEM}'s ${esc(d.metric)}, one row per run, baseline first, then best mean first; the bar and the number are the run's mean, the dashed line the baseline's mean${binNote}.</figcaption>
      <div class="scroll-x"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Spread of per-${ITEM} scores per run">${g}</svg></div></figure>`;
  }

  function deltas(d, label, col) {
    const base = d.series[d.baseline], arms = Object.keys(d.series).filter(a => a !== d.baseline);
    const rows = arms.map(a => [a, Object.entries(d.series[a]).filter(([ep]) => ep in base).map(([ep, s]) => [ep, s - base[ep]])]).filter(r => r[1].length);
    if (!rows.length) return '';
    const md = r => mean(r[1].map(z => z[1]));
    rows.sort((p, q) => (d.higher_is_better || d.neutral ? md(q) - md(p) : md(p) - md(q)));
    // The scale holds every item's difference and every interval (RFC-034): an interval drawn past the edge would lie.
    const ciOf = a => (Object.fromEntries(d.rows.map(r => [r.arm, r]))[a] || {}).ci;
    const m = maxOf([...rows.flatMap(r => r[1].map(x => Math.abs(x[1]))), ...rows.flatMap(([a]) => (ciOf(a) || []).map(Math.abs))]) * 1.08 || 1;
    const RH = ROW, top = NARROW ? 30 : 14, H = top + rows.length * RH + 30, x = scale(-m, m, LEFT, W - RIGHT - (NARROW ? 0 : 160));
    const verdict = Object.fromEntries(d.rows.map(r => [r.arm, r]));
    let g = axis(x, -m, m, top - 6, top + rows.length * RH);
    g += `<line class="zero" x1="${x(0)}" x2="${x(0)}" y1="${top - 6}" y2="${top + rows.length * RH}"/>`;
    rows.forEach(([a, ds], i) => {
      const y = top + i * RH + RH / 2, mu = mean(ds.map(z => z[1])), r = verdict[a] || {};
      g += rowLabel(y, label[a] || a, a, col[a]);
      g += ds.length > DOTS_MAX ? binRow(ds.map(z => z[1]), x, -m, m, y, col[a], `${label[a] || a} vs baseline`)
        : ds.map(([ep, z]) => dot(x(z), y + jit(ep, a), col[a], `${label[a] || a} · ${ep}: ${z >= 0 ? '+' : ''}${tfmt(z)} vs baseline`)).join('');
      g += `<line class="meanmark" x1="${x(mu)}" x2="${x(mu)}" y1="${y - 11}" y2="${y + 11}"/>`;
      const ci = r.ci;
      if (ci) g += `<line class="ci" x1="${x(ci[0])}" x2="${x(ci[1])}" y1="${y + 14}" y2="${y + 14}" stroke="var(--ink)" stroke-width="2" data-tip="${esc((label[a] || a) + ': 95% interval ' + tfmt(ci[0]) + ' to ' + tfmt(ci[1]) + ' (before Holm)')}"/>`;
      // Words, not arrows: for a lower-is-better metric an up-arrow beside a negative number reads wrong.
      const v = r.verdict || '';
      const word = !v.startsWith('significant') ? '·' : d.neutral ? (mu > 0 ? 'higher' : 'lower') : v.includes('better') ? '✓ better' : '✗ worse';
      g += rowValue(y, W - RIGHT - 150, `${mu >= 0 ? '+' : ''}${tfmt(mu)} ${r.wins != null ? r.wins + '–' + r.losses : ''} ${word}`);
    });
    const side = d.neutral ? '← lower · higher →' : d.higher_is_better ? '← worse · better →' : '← better · worse →';
    return `<figure class="chart"><figcaption><b>Difference from the baseline</b> · each ${ITEM}'s ${esc(d.metric)} minus the baseline's (${esc(label[d.baseline] || d.baseline)}); bar = mean difference; the line under it, its 95% interval from the paired test (before Holm); right column: mean difference, wins–losses, and ✓ better / ✗ worse when significant after Holm${binNote}. <span class="muted">${side}</span></figcaption>
      <div class="scroll-x"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Per-${ITEM} difference from the baseline">${g}</svg></div></figure>`;
  }

  function scatter(d, label, col, xm) {
    const xs = d.shape[xm]; if (!xs) return '';
    const pts = []; Object.keys(d.series).forEach(a => Object.entries(d.series[a]).forEach(([ep, y]) => { const v = (xs[a] || {})[ep]; if (v != null) pts.push([a, ep, v, y]); }));
    if (pts.length < 3) return '';
    const H = NARROW ? 330 : 420, top = 14, bottom = H - 40, L = NARROW ? 46 : 70;
    let x0 = minOf(pts.map(p => p[2])), x1 = maxOf(pts.map(p => p[2])), y0 = minOf(pts.map(p => p[3])), y1 = maxOf(pts.map(p => p[3]));
    const px = (x1 - x0) * 0.05 || 1, py = (y1 - y0) * 0.06 || 0.05; x0 = Math.max(0, x0 - px); x1 += px; y0 -= py; y1 += py;
    const x = scale(x0, x1, L, W - RIGHT), y = scale(y0, y1, bottom, top);
    let g = ticks(x0, x1).map(t => `<line class="grid" x1="${x(t)}" x2="${x(t)}" y1="${top}" y2="${bottom}"/><text class="tick" x="${x(t)}" y="${bottom + 16}" text-anchor="middle">${tfmt(t)}</text>`).join('');
    g += ticks(y0, y1).map(t => `<line class="grid" x1="${L}" x2="${W - RIGHT}" y1="${y(t)}" y2="${y(t)}"/><text class="tick" x="${L - 8}" y="${y(t) + 4}" text-anchor="end">${tfmt(t)}</text>`).join('');
    if (pts.length > DOTS_MAX * 4) {
      // Too many to draw one by one: a grid of cells, shaded by how many items of all the runs fall in each.
      const GX = 60, GY = 30, cw = (x1 - x0) / GX, ch = (y1 - y0) / GY, grid = new Map();
      for (const p of pts) { const k = Math.min(GX - 1, Math.floor((p[2] - x0) / cw)) * GY + Math.min(GY - 1, Math.floor((p[3] - y0) / ch)); grid.set(k, (grid.get(k) || 0) + 1); }
      const most = maxOf(grid.values()) || 1;
      g += '<g class="faded">' + [...grid].map(([k, c]) => { const i = Math.floor(k / GY), j = k % GY;
        return `<rect class="bin" x="${x(x0 + i * cw).toFixed(1)}" y="${y(y0 + (j + 1) * ch).toFixed(1)}" width="${(x(x0 + (i + 1) * cw) - x(x0 + i * cw)).toFixed(1)}" `
          + `height="${(y(y0 + j * ch) - y(y0 + (j + 1) * ch)).toFixed(1)}" fill="${col[d.baseline]}" fill-opacity="${(0.12 + 0.88 * c / most).toFixed(2)}">`
          + `<title>${c} ${c === 1 ? ITEM : ITEMS} of all runs</title></rect>`; }).join('') + '</g>';
    } else g += '<g class="faded">' + pts.map(([a, ep, xv, yv]) => dot(x(xv), y(yv), col[a], `${label[a] || a} · ${ep}: ${tfmt(yv)} at ${tfmt(xv)} ${esc(xm)}`, 5)).join('') + '</g>';
    // Each run's average position: its trade-off (length, speed, cost) against the score.
    Object.keys(d.series).forEach(a => {
      const mine = pts.filter(p => p[0] === a); if (!mine.length) return;
      const cx = x(mean(mine.map(p => p[2]))), cy = y(mean(mine.map(p => p[3])));
      g += `<g class="centroid" data-tip="${esc((label[a] || a) + ' average: ' + tfmt(mean(mine.map(p => p[3]))) + ' at ' + tfmt(mean(mine.map(p => p[2]))))}">`
        + `<path d="M${cx - 9} ${cy}H${cx + 9}M${cx} ${cy - 9}V${cy + 9}" stroke="${col[a]}"/>`
        + `<text class="cl" x="${cx + 11}" y="${cy - 6}">${esc((label[a] || a).slice(0, 24))}</text></g>`;
    });
    g += `<text class="axl" x="${(L + W - RIGHT) / 2}" y="${H - 6}" text-anchor="middle">${esc(xm)} (per ${ITEM})</text>`;
    return `<div class="scroll-x"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Score against ${esc(xm)}">${g}</svg></div>`;
  }

  function legend(d, label, col) {
    // The swatch colour is set after rendering (wireCharts), never as a style="" attribute,
    // which a Content-Security-Policy without 'unsafe-inline' refuses.
    return '<p class="legend">' + Object.keys(d.series).map(a => `<span title="${esc(a)}"><i data-swatch="${esc(col[a])}"></i>${esc(label[a] || a)}${a === d.baseline ? ' <small>baseline</small>' : ''}</span>`).join('') + '</p>';
  }

  function charts(d, label) {
    const col = colorOf(d), keys = Object.keys(d.shape || {});
    const xm = keys[0];
    const sc = xm ? `<figure class="chart"><figcaption><b>${esc(d.metric)} against <select id="xmetric">${keys.map(k => `<option ${k === xm ? 'selected' : ''}>${esc(k)}</option>`).join('')}</select></b> · faded dots: one per run per ${ITEM} (past ${DOTS_MAX * 4} in all, shaded cells: the darker, the more); cross: each run's average, its trade-off between the two.</figcaption><div id="scatterbox">${scatter(d, label, col, xm)}</div></figure>` : '';
    return legend(d, label, col) + spread(d, label, col) + deltas(d, label, col) + sc;
  }

  function wireCharts(d, label) {
    app.querySelectorAll('i[data-swatch]').forEach(i => { i.style.background = i.dataset.swatch; });
    const tip = document.getElementById('ctip') || Object.assign(document.body.appendChild(document.createElement('div')), {id: 'ctip'});
    // Every mark with a tooltip also has an SVG <title>: a screen reader names it, not only the pointer.
    app.querySelectorAll('svg [data-tip]').forEach(el => {
      if (!el.querySelector(':scope > title')) { const t = document.createElementNS('http://www.w3.org/2000/svg', 'title'); t.textContent = el.dataset.tip; el.prepend(t); }
    });
    app.querySelectorAll('svg').forEach(svg => {
      svg.addEventListener('pointermove', ev => { const t = ev.target.closest('[data-tip]'); if (!t) { tip.classList.remove('on'); return; }
        tip.textContent = t.dataset.tip; tip.classList.add('on');
        tip.style.left = Math.min(ev.clientX + 14, innerWidth - tip.offsetWidth - 8) + 'px'; tip.style.top = (ev.clientY + 14) + 'px'; });
      svg.addEventListener('pointerleave', () => tip.classList.remove('on'));
    });
    const sel = document.getElementById('xmetric');
    if (sel) sel.onchange = () => { document.getElementById('scatterbox').innerHTML = scatter(d, label, colorOf(d), sel.value); wireCharts(d, label); };
  }

  function words(t) { return String(t || '').split(/(\s+)/); }
  function diff(a, b) {  // word-level LCS: what b adds (ins) and drops (del) relative to a
    const A = words(a), B = words(b), n = A.length, m = B.length;
    if (n * m > 4e6) return esc(b);
    const L = Array.from({length: n + 1}, () => new Uint16Array(m + 1));
    for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i][j] = A[i] === B[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
    let i = 0, j = 0, out = '';
    while (i < n && j < m) {
      if (A[i] === B[j]) { out += esc(B[j]); i++; j++; }
      else if (L[i + 1][j] >= L[i][j + 1]) { if (A[i].trim()) out += `<del>${esc(A[i])}</del>`; i++; }
      else { out += B[j].trim() ? `<ins>${esc(B[j])}</ins>` : esc(B[j]); j++; }
    }
    while (i < n) { if (A[i].trim()) out += `<del>${esc(A[i])}</del>`; i++; }
    while (j < m) { out += B[j].trim() ? `<ins>${esc(B[j])}</ins>` : esc(B[j]); j++; }
    return out;
  }

  function view(v, base) {
    if (!v || v.kind === 'none') return `<p class="muted">${esc((v && v.note) || 'No stored output.')}</p>`;
    const show = x => typeof x === 'number' ? (x >= 100 ? x.toFixed(0) : x.toFixed(1)) : x;
    const info = v.info && Object.keys(v.info).length ? `<p class="small muted">${esc(Object.entries(v.info).map(([k, x]) => k.replace(/_/g, ' ') + ' ' + show(x)).join(' · '))}</p>` : '';
    if (v.kind === 'text') {
      const t = DIFF && base && base.kind === 'text' && base !== v ? diff(base.text, v.text) : esc(v.text);
      return info + `<div class="outtext">${t}</div><p class="small muted">${String(v.text || '').split(/\s+/).filter(Boolean).length} words</p>`;
    }
    if (v.kind === 'insights') return info + `<p class="small muted">${v.items.length} insights · ${v.quotes} quotes</p><ol class="outlist">${v.items.map(x => `<li>${x.grounded ? '<span title="grounded" class="up">●</span> ' : '<span title="not grounded" class="muted">○</span> '}${esc(x.text)}</li>`).join('')}</ol>`;
    if (v.kind === 'nodes') return info + Object.entries(v.groups).map(([k, xs]) => `<p class="small"><b>${esc(k)}</b> · ${xs.length}</p><p class="chips">${xs.map(x => `<span class="chip">${esc(x)}</span>`).join('')}</p>`).join('');
    if (v.kind === 'entities') return info + `<p class="small muted">${v.items.length} entities</p><p class="chips">${v.items.map(x => `<span class="chip">${esc(x)}</span>`).join('')}</p>`;
    return '';
  }

  let DIFF = false;
  async function drill(ep, arms, baseline, label, ref, tr, scores) {
    document.querySelectorAll('tr.eprow.on').forEach(x => x.classList.remove('on')); tr.classList.add('on');
    const box = document.getElementById('drill');
    box.innerHTML = '<p class="muted">Loading outputs…</p>';
    const q = new URLSearchParams({arms: arms.join(','), item: ep});
    if (!arms.length) { q.delete('arms'); q.set('dataset', P.get('dataset') || ''); }
    if (ref) q.set('ref', ref);
    const d = await (await fetch(API + 'item?' + q)).json();
    if (d.error) { box.innerHTML = `<p class="note">${esc(d.error)}</p>`; return; }
    const base = d.views[baseline];
    const rec = d.recorded || {};
    const score = (a, v) => { const s = scores && scores.series[a] && scores.series[a][ep];
      return s == null ? "" : `<p class="itemscore"><b class="num">${fmt(s)}</b> <small class="muted">${esc(scores.metric)} on this ${ITEM}</small></p>`; };
    const cols = Object.entries(d.views).map(([a, v]) => `<div class="outcol"><h3>${rec[a] ? 'production, recorded <small class="muted">capture ' + esc(rec[a]) + '</small> · ' : ''}${esc(label[a] || a)}${a === baseline ? ' <small class="muted">baseline</small>' : ''}</h3>${score(a, v)}${view(v, a === baseline ? null : base)}</div>`).join('');
    const labs = (d.labels || []).length ? `<h3 class="sub">labels · ${d.labels.length}</h3><ul class="labels">${d.labels.map(l =>
      `<li>${chip(l.kind)} <code>${esc(l.set.split('/').pop())}</code>${l.by ? ' <small class="muted">' + esc(l.by) + '</small>' : ''}${l.note ? ' <small>' + esc(l.note) + '</small>' : ''}<div class="outtext">${l.text == null ? '<span class="muted">(its text is not here)</span>' : esc(l.text)}</div></li>`).join('')}</ul>`
      : (d.labels ? `<p class="small muted">No label for this ${ITEM} yet.</p>` : '');
    // What the judges said of this item and why (RFC-034): the local inspector only.
    const said = x => typeof x.said === 'number' ? fmt(x.said) : esc(x.said == null ? '—' : x.said);
    const whyOf = x => x.why ? esc(x.why) : `<span class="muted">${x.why_status === 'withheld' ? 'withheld: it repeated the source' : esc(x.why_status)}</span>`;
    const judged = (d.verdicts || []).length ? `<h3 class="sub">what the judges said · ${d.verdicts.length}</h3><div class="scroll-x"><table class="data why"><thead><tr><th>scorer</th><th>judge</th><th>arm</th><th class="num">said</th><th>why</th></tr></thead><tbody>${d.verdicts.map(x =>
      `<tr><td><code>${esc(x.scorer)}</code></td><td><code>${esc(x.judge)}</code></td><td><code>${esc(x.arm)}</code></td><td class="num">${said(x)}</td><td>${whyOf(x)}</td></tr>`).join('')}</tbody></table></div>` : '';
    const refcol = d.reference && d.reference.view && d.reference.view.kind !== 'none' ? `<div class="outcol refcol"><h3>${esc(d.reference.id)} <small class="muted">reference</small></h3>${view(d.reference.view, null)}</div>` : '';
    const hasText = Object.values(d.views).some(v => v && v.kind === 'text');
    const toggle = hasText ? `<label class="tick small"><input type="checkbox" id="difft" ${DIFF ? 'checked' : ''}> mark what each run <ins>adds</ins> and <del>drops</del> against the baseline (useful between near-identical outputs, noisy between independent ones)</label>` : '';
    // The item itself, what every arm read (the local inspector only); folded when it is long.
    const src = d.source && d.source.kind !== 'none' && d.source.text
      ? `<details class="srcbox"${d.source.text.length <= 1500 ? ' open' : ''}><summary>the ${ITEM} itself <small class="muted">${d.source.text.length.toLocaleString()} characters, what every arm read</small></summary><div class="outtext">${esc(d.source.text)}</div></details>` : '';
    box.innerHTML = `<p class="eyebrow gap"><span class="num">04</span>${ITEM} · ${esc(ep)}</p>${fieldsTable(d.fields)}${src}${labs}${judged}${toggle}<div class="outgrid">${refcol}${cols}</div>`;
    const t = document.getElementById('difft');
    if (t) t.onchange = () => { DIFF = t.checked; drill(ep, arms, baseline, label, ref, tr, scores); };
    box.scrollIntoView({behavior: 'smooth', block: 'start'});
  }

  // ── 05 sheet (RFC-023): one dataset's items down, a column per arm across: what it wrote, its scores, the labels, the winner ──
  // The page writes nothing: the rows ticked give the evh pick and evh label-sheet commands to copy; the CSV is a read.
  const SIGNALS = ['wrong', 'disagree', 'split', 'new', 'unlabelled'];
  async function sheetView() {
    const ds = P.get('dataset');
    picker();
    let d;
    const params = () => {
      const q = new URLSearchParams({dataset: ds, runs: runs().join(',')});
      for (const k of ['wrong', 'new', 'metric']) if (P.get(k)) q.set(k, P.get(k));
      for (const w of P.getAll('where')) q.append('where', w);
      for (const o of P.getAll('only')) q.append('only', o);
      return q;
    };
    try {
      d = await (await fetch(API + 'sheet?' + params())).json();
    } catch (e) {
      app.innerHTML = `<p class="note"><b>No inspector server.</b> Start it with <code>${esc(SERVE)}</code> and open this page from the address it prints.</p>`;
      return;
    }
    if (d.error) { app.innerHTML = `<p class="note"><b>${esc(d.error)}</b></p>`; return; }
    const only = P.getAll('only');
    const scoresOnly = P.get('scores') === 'only';
    const counts = `${d.total} ${ITEMS}` + SIGNALS.filter(s => d.counts[s]).map(s => ` · ${d.counts[s]} ${s}`).join('');
    const opt = (xs, cur, none) => `<option value="">${none}</option>` + xs.map(x => `<option value="${esc(x)}" ${x === cur ? 'selected' : ''}>${esc(x)}</option>`).join('');
    const mopts = d.metrics.map(m => `<option value="${esc(m)}" ${m === d.metric ? 'selected' : ''}>${esc(m)}</option>`).join('');
    const controls = `<div class="controls">
      ${d.metric ? `<label>read on <select id="smetric">${mopts}</select></label>` : ''}
      <label>wrong against <select id="swrong">${opt(d.sets, d.wrong, 'no label set')}</select></label>
      <label>new against <select id="snew">${opt(d.datasets, d.new, 'no dataset')}</select></label>
      ${SIGNALS.map(s => `<label class="tick"><input type="checkbox" class="sonly" value="${s}" ${only.includes(s) ? 'checked' : ''}> only ${s}</label>`).join('')}
      <label class="tick"><input type="checkbox" id="sscores" ${scoresOnly ? 'checked' : ''}> scores only</label></div>`
      + fieldControls(d);
    const first = d.runs[0];
    // The terminal's order: the signals next to the item (they are why a row matters), each arm's output and scores,
    // the labels, the winners, and the fields last.
    const arms = d.arms;
    const heads = [['sel', '<input type="checkbox" id="sall" aria-label="select all shown">'], ['item', ITEM], ['start', 'the start'], ['', 'signals']];
    // An arm by what sets it apart from the others shown (shorten: "baseline_pro_v1", not
    // "rescored-5f2c057c/orrery_triage_v1_labelled/triage_baseline_pro_v1"), the whole id in its title.
    // A break is offered after each '/' of what is left.
    const named = shorten(Object.fromEntries(arms.map(a => [a.token, short(a.token)])));
    const armHead = t => `<span title="${esc(t)}">${esc(named[t] || short(t)).replace(/\//g, '/<wbr>')}</span>`;
    arms.forEach((a, i) => {
      heads.push(['outc', armHead(a.token) + '<br><small>' + (i === 0 ? 'first: production' : 'output') + '</small>']);
      // The arm heads its output column; its score columns, right after, name only the metric (the arm's whole path
      // over each was the sheet's widest clutter). With the outputs hidden (scores only) the arm heads its scores.
      a.scores.forEach(ref => heads.push(['scc', (scoresOnly ? armHead(a.token) + '<br>' : '')
        + `<small title="${esc(a.token)}">${esc(ref)}</small>`]));
    });
    d.label_cols.forEach(c => heads.push(['', `label ${chip(c.kind)} ${esc(c.name)}`]));
    d.ref_cols.forEach(c => heads.push(['', 'reference<br><small>' + esc(c.key) + '</small>']));
    d.winner_cols.forEach(w => heads.push(['', esc(w.header)]));
    heads.push(['', 'picked'], ['', 'fields']);
    const fieldsOf = r => Object.entries(r.fields).map(([k, v]) => `${k}=${v}`).join(', ');
    const win = (r, t, ref) => ref === d.metric && (r.winners['winner: ' + d.metric] || []).includes(t) ? ' win' : '';
    // Each column as [its cell, the text a sort reads], in the order of `heads`: the sort works on the data, so only the
    // rows shown are drawn (at 10,000 items and 40 arms the whole sheet was 940,000 elements and a 262 MB heap).
    const dash = v => v == null ? '<span class="muted">—</span>' : esc(v);
    const cols = [
      [r => `<td class="sel"><input type="checkbox" class="ssel" value="${esc(r.item)}" aria-label="select ${esc(r.item)}"${picked.has(r.item) ? ' checked' : ''}></td>`, () => ''],
      [r => `<td class="item mono" title="${esc(r.item)}">${esc(r.item.length > 28 ? r.item.slice(0, 27) + '…' : r.item)}</td>`, r => r.item],
      [r => `<td class="small start" title="${esc(r.text)}">${esc(r.text.length > 60 ? r.text.slice(0, 59) + '…' : r.text)}</td>`, r => r.text],
      [r => `<td>${Object.entries(r.signals).map(([s, x]) => `<span class="chip sig sig-${s}" title="${esc(x)}">${s}</span>`).join(' ')}</td>`, r => Object.keys(r.signals).join(' ')],
      ...arms.flatMap(a => [
        [r => `<td class="small outc">${dash(r.cells[a.token].output)}</td>`, r => r.cells[a.token].output ?? ''],
        ...a.scores.map(ref => [r => `<td class="num scc${win(r, a.token, ref)}">${fmt(r.cells[a.token].scores[ref])}</td>`, r => fmt(r.cells[a.token].scores[ref])]),
      ]),
      ...d.label_cols.map(c => [r => `<td class="small">${dash(r.labels[c.key])}</td>`, r => r.labels[c.key] ?? '']),
      ...d.ref_cols.map(c => [r => `<td class="small">${dash(r.references[c.key])}</td>`, r => r.references[c.key] ?? '']),
      ...d.winner_cols.map(w => { const who = r => (r.winners[w.key] || []).map(t => named[t] || short(t)).join(' = '); return [r => `<td class="small">${esc(who(r))}</td>`, who]; }),
      [r => `<td class="small">${esc(r.picked.join(', '))}</td>`, r => r.picked.join(', ')],
      [r => `<td class="small"><div class="clamp2" title="${esc(fieldsOf(r))}">${esc(fieldsOf(r))}</div></td>`, fieldsOf],
    ];
    const picked = new Set(), order = [...d.rows];
    const body = rs => rs.map(r => `<tr class="eprow" data-ep="${esc(r.item)}" tabindex="0">${cols.map(c => c[0](r)).join('')}</tr>`).join('');
    // The footer, per arm: under the arm's columns. Its cells span the arm's columns (the output's too, unless hidden).
    const f = d.footer, before = 4, after = d.label_cols.length + d.ref_cols.length + d.winner_cols.length + 2;
    const line = (label, cell) => `<tr><th colspan="${before}" class="small">${label}</th>${arms.map(a =>
      `<td class="small foot" data-n="${a.scores.length}">${cell(a.token)}</td>`).join('')}<td colspan="${after}"></td></tr>`;
    const way = d.lower_is_better ? 'lower' : 'higher';
    const pct = v => v == null ? '—' : (100 * v).toFixed(0) + '%';
    const foot = !d.metric ? '' : '<tfoot>'
      + line(`mean ${esc(f.metric)} <small>(${way} is better)</small>`, t => fmt(f.mean[t]))
      + d.winner_cols.map(w => line(`win rate · ${esc(w.header)}`, t => pct(f.win_rate[w.key][t]))).join('')
      + line('verdict' + (f.decided ? ` <small>(${esc(f.decided)})</small>` : ''), t => verdictCell(f.verdict[t]))
      + '</tfoot>';
    const table = `<div class="scroll-x"><table class="data sheet${scoresOnly ? ' scores-only' : ''}" id="sheettable"><thead><tr>${heads.map(([c, h], i) => `<th class="${c}" data-col="${i}">${h}</th>`).join('')}</tr></thead><tbody></tbody>${foot}</table></div><p class="pager small muted" id="sheet-pager"></p>`;
    const panel = `<div class="cmdpanel" id="spanel" hidden><p class="small"><b><span id="sn">0</span> selected.</b> The page writes nothing; run these.</p>
      <div class="controls"><label>for <input id="sfor" placeholder="a governed dataset" list="sdsl"></label><datalist id="sdsl">${d.datasets.map(x => `<option value="${esc(x)}">`).join('')}</datalist>
      <label>tags <input id="stags" placeholder="case=oom kind=missed"></label><label>note <input id="snote" placeholder="why it is worth keeping"></label></div>
      <p><code class="cmd" id="spick"></code> <button type="button" class="btn small copy" data-copy="">copy</button></p>
      <p><code class="cmd" id="ssheet"></code> <button type="button" class="btn small copy" data-copy="">copy</button>
      <a class="btn small" id="ssheetdl" href="#" download>download these rows (CSV)</a></p></div>`;
    let by = '';
    const bf = P.get('by');
    if (bf) {
      const g = {};
      for (const r of d.rows) { const k = String(r.fields[bf] ?? '—'); (g[k] = g[k] || []).push(r); }
      by = `<h3 class="sub">by ${esc(bf)}</h3><div class="scroll-x"><table class="data" data-nopage><thead><tr><th>${esc(bf)}</th><th>rows</th>${SIGNALS.map(s => `<th>${s}</th>`).join('')}</tr></thead><tbody>${Object.entries(g).map(([k, rs]) =>
        `<tr><td>${esc(k)}</td><td class="num">${rs.length}</td>${SIGNALS.map(s => `<td class="num">${rs.filter(r => s in r.signals).length}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
    }
    app.innerHTML = `<p class="eyebrow"><span class="num">05</span>sheet · ${esc(ds)}</p><p class="small" id="scounts">${esc(counts)}${only.length ? ' · ' + d.rows.length + ' shown' : ''}${d.metric ? ' · read on ' + esc(d.metric) + ' (' + way + ' is better)' : ''}</p>`
      + controls + `<p><a class="btn small" id="sheetdl" href="#" download>download (CSV)</a> <label class="tick small"><input type="checkbox" id="sfill"> with empty label columns to fill</label></p>`
      + panel + by + table + `<p class="small muted">Tick rows to pick or label them; click a row to open the ${ITEM}.</p><div id="drill"></div>`;
    wireFields(d);
    const t = document.getElementById('sheettable');
    // The footer's cells span their arm's columns: the output's too, unless "scores only" hides it.
    const span = () => t.querySelectorAll('td.foot').forEach(c => { c.colSpan = Math.max(1, +c.dataset.n + (t.classList.contains('scores-only') ? 0 : 1)); });
    span();
    t.dataset.nopage = '';  // drawn on demand below, not paged by hiding rows
    document.getElementById('swrong').onchange = ev => { ev.target.value ? P.set('wrong', ev.target.value) : P.delete('wrong'); go(); };
    document.getElementById('snew').onchange = ev => { ev.target.value ? P.set('new', ev.target.value) : P.delete('new'); go(); };
    const sm = document.getElementById('smetric');
    if (sm) sm.onchange = () => { P.set('metric', sm.value); go(); };
    app.querySelectorAll('input.sonly').forEach(c => c.onchange = () => {
      P.delete('only'); app.querySelectorAll('input.sonly:checked').forEach(x => P.append('only', x.value)); go(); });
    const q = s => s.includes(' ') || s.includes('"') ? '"' + s.replace(/"/g, '\\"') + '"' : s;
    // The CSV the server builds as the command does (a read: nothing is written): every row shown, or the ticked ones.
    const csv = items => {
      const qs = params(); qs.set('format', 'csv');
      if (document.getElementById('sscores').checked) qs.set('scores_only', '1');
      if (document.getElementById('sfill').checked) qs.set('fill', 'label');
      items.forEach(i => qs.append('item', i));
      return API + 'sheet?' + qs;
    };
    const upd = () => {
      const sel = order.map(r => r.item).filter(i => picked.has(i));
      document.getElementById('spanel').hidden = !sel.length;
      document.getElementById('sn').textContent = sel.length;
      const items = sel.map(i => '--item ' + i).join(' ');
      const fr = document.getElementById('sfor').value.trim(), tg = document.getElementById('stags').value.trim().split(/\s+/).filter(Boolean);
      const note = document.getElementById('snote').value.trim();
      const pk = `evh pick --dataset-id ${ds} ${items}` + (fr ? ` --for ${fr}` : '') + tg.map(x => ` --tag ${x}`).join('') + (note ? ` --note ${q(note)}` : '');
      const sh = `evh label-sheet --dataset-id ${ds} ${items} --out sheet.csv` + (d.runs.length ? ` --runs ${d.runs.join(',')}` : '');
      const [a, b] = app.querySelectorAll('#spanel button.copy');
      document.getElementById('spick').textContent = pk; a.dataset.copy = pk;
      document.getElementById('ssheet').textContent = sh; b.dataset.copy = sh;
      const dl = document.getElementById('ssheetdl');
      dl.href = csv(sel); dl.download = `sheet-${ds}.csv`;
      const all = document.getElementById('sheetdl');
      all.href = csv([]); all.download = `sheet-${ds}.csv`;
    };
    document.getElementById('sscores').onchange = ev => {
      t.classList.toggle('scores-only', ev.target.checked);
      ev.target.checked ? P.set('scores', 'only') : P.delete('scores');
      history.replaceState(null, '', '?' + P);
      span(); upd(); };
    document.getElementById('sfill').onchange = upd;
    for (const id of ['sfor', 'stags', 'snote']) document.getElementById(id).oninput = upd;
    upd();
    const label = Object.fromEntries(d.runs.map(r => [r, short(r)]));
    const tb = t.tBodies[0], pager = document.getElementById('sheet-pager');
    let drawn = 0;
    const draw = upto => {
      upto = Math.min(upto, order.length);
      if (upto > drawn) {
        tb.insertAdjacentHTML('beforeend', body(order.slice(drawn, upto)));
        [...tb.rows].slice(drawn).forEach(tr => {
          tr.onclick = ev => { if (ev.target.closest('input')) return; drill(tr.dataset.ep, d.runs, first, label, '', tr); };
          tr.onkeydown = ev => { if (ev.key === 'Enter') tr.onclick(ev); };
          const box = tr.querySelector('input.ssel');
          box.onchange = () => { box.checked ? picked.add(box.value) : picked.delete(box.value); upd(); };
        });
        drawn = upto;
      }
      const n = order.length, more = n <= SHOW_ALL ? n - drawn : Math.min(1000, n - drawn);
      pager.hidden = n <= 10;
      pager.innerHTML = `Showing ${drawn} of ${n}` + (drawn < n ? ` <button type="button" class="btn small" data-more>show ${Math.min(10, n - drawn)} more</button>`
        + `<button type="button" class="btn small" data-bulk>${n <= SHOW_ALL ? 'show all' : 'show ' + more + ' more'}</button>` : '');
    };
    pager.onclick = ev => { const b = ev.target.closest('button'); if (!b) return;
      draw('more' in b.dataset ? drawn + 10 : order.length <= SHOW_ALL ? order.length : drawn + 1000); };
    // Select all: every row of this sheet (the signals' "only" boxes already chose them), drawn or not.
    document.getElementById('sall').onchange = ev => {
      order.forEach(r => ev.target.checked ? picked.add(r.item) : picked.delete(r.item));
      tb.querySelectorAll('input.ssel').forEach(c => { c.checked = ev.target.checked; });
      upd(); };
    // A sort by any column (a header that is not the select-all box): numbers as numbers, text as shown.
    t.tHead.querySelectorAll('th').forEach(th => th.onclick = ev => {
      if (ev.target.closest('input')) return;
      const i = th.cellIndex, dir = th.dataset.dir === 'asc' ? 'desc' : 'asc';
      t.querySelectorAll('th').forEach(x => delete x.dataset.dir); th.dataset.dir = dir;
      const key = cols[i][1];
      order.sort((a, b) => String(key(a)).trim().localeCompare(String(key(b)).trim(), undefined, {numeric: true}) * (dir === 'asc' ? 1 : -1));
      const had = drawn; tb.innerHTML = ''; drawn = 0; draw(Math.max(10, had)); });
    const want = P.get('item');
    const at = want ? order.findIndex(r => r.item === want) : -1;
    draw(Math.max(10, at + 1));
    const hit = at >= 0 && [...tb.rows].find(tr => tr.dataset.ep === want);
    if (hit) drill(want, d.runs, first, label, '', hit);
  }

  // A footer verdict, as the comparison page tints one: better and worse by their words, else plain.
  function verdictCell(v) {
    if (!v) return '<span class="muted">—</span>';
    const cls = v.startsWith('leader') ? 'v-better' : v.startsWith('out') || v.includes('significant: worse') ? 'v-worse' : 'v-none';
    return `<span class="chip ${cls}">${esc(v)}</span>`;
  }

  load();
})();
